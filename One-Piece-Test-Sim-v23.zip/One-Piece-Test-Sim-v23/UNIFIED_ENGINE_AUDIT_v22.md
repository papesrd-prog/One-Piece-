# Unified Engine Audit — v22

## Implemented in this build

- `src/unified-game-engine.mjs` is a single action facade over the `rules-runtime` state model.
- Supported action families include turn lifecycle, drawing, DON!! payment/attachment, power modifiers, effect queue processing, the compiled draw-effect path, DSL effects, and battle procedure.
- A thrown action/validation error restores the canonical root state snapshot. Valid rule outcomes such as deck-out are committed.
- `src/card-effect-engine.mjs` now has `resolveCompiledCardEffectInState`, which routes explicitly registered draw effects through `drawCards` and the shared rule-processing checkpoint.
- `payDon` is available in the runtime and moves DON!! from active to rested only during the current player's Main Phase.
- `beginTurn` now rejects attempts to start another turn while a turn is already active.
- `rules-runtime` state explicitly carries `turn`, `turnNumber`, `gameResult`, and `battle` fields.

## Validation performed

- JavaScript suite: 95 tests passed.
- Python suite: 15 tests passed.
- `node --check` passed for every `src/*.mjs` and `tests/*.mjs` file.

## Known integration boundary

`src/rules-engine.mjs` now creates its games through `createRuntimeState`; its public `startTurn` and `payDon` functions delegate to the canonical runtime, and its registered handler names share the runtime's effect-handler registry. Battle procedure already uses the same `battle-engine.mjs`. A compatibility `startTurn` shorthand closes the previous Main Phase through End Phase cleanup before starting the opponent's turn.

The web pages have not yet been wired to call `executeUnifiedAction` directly, and the heuristic opponent policy still has a simplified zone adapter for its standalone policy tests. The UI/AI integration is therefore incomplete. Do not describe v22 as a fully migrated application or a complete judge-accurate simulator.

## Next migration step

Connect the UI and opponent policy to the same action facade, then add end-to-end tests for a full match. Card effects remain explicitly compiled; the engine does not infer arbitrary effects from printed text.
