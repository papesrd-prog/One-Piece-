# One Piece Test Sim — Rules Validation Report

**Audit date:** 2026-10-23  
**Scope:** Current One Piece Test Sim rules-engine/runtime code, test suite, rules coverage matrix, and accessible One Piece Card Game official rules materials.

## Verdict

**NOT JUDGE-ACCURATE.** The repository contains a useful experimental kernel, but the current tests are not broad enough to validate the Comprehensive Rules or all printed card effects. Passing unit tests establishes only that the tested functions behave as those tests specify; it does not establish tournament-ruling accuracy.

## Source hierarchy used

1. Bandai official English Comprehensive Rules, **v1.2.1, updated 2026-08-28**: https://en.onepiece-cardgame.com/pdf/rule_comprehensive.pdf?20260828=
2. Bandai official rules index, including official rule updates, errata, and ban/restricted notices: https://en.onepiece-cardgame.com/rules/
3. Bandai Tournament Rules Manual PDF linked from the official rules index. Its PDF text states last updated 2025-10-17, despite the index link label showing 2026-01-16; record the document's own version/date and recheck for updates.
4. Official card FAQs / Q&A and card-specific errata must be reconciled per card and set.
5. OnePiece.gg is a useful searchable mirror and cross-check, not a substitute for Bandai's current official files.

The official Judge Program page describes the program and directs applicants to its Organized Play Discord/Read Me; I did not find a single public downloadable document titled “Judge Handbook.” The Tournament Rules Manual, Comprehensive Rules, FAQ/Q&A, official errata, and Judge Program resources are separate sources and must not be conflated.

## Section-by-section audit

| Comprehensive Rules section | Status in current code | Findings / required validation |
|---|---|---|
| 1. Game overview and fundamental principles | **Fail / partial** | Two-player model exists. `drawCards()` and `applyLifeDamage()` assign a winner immediately, whereas CR 1-2-2 defers defeat judgment to the next rule-processing checkpoint. Concession, card-caused wins/losses, prohibition precedence, impossible actions, simultaneous choices, and zero/negative “up to” handling are not implemented as a unified rules layer. |
| 2. Card information | **Partial** | Basic fields exist, but dynamic names/types/attributes, multiple attributes, block symbols, card identity and full modified-value semantics are not complete. No full verified English database is currently present. |
| 3. Game areas | **Fail / partial** | Basic zones exist. Missing robust new-object identity on zone changes, DON!! effect reset on movement, face-up Life exceptions, hidden-information permissions, 5-character field limit and forced rule-processing trash, and one-Stage limit/replacement. |
| 4. Basic terminology | **Fail / partial** | Basic actions exist, but “draw,” damage processing, play vs. activate, “up to,” “base,” “if/then,” remove, and impossible/partially possible multi-action effects are not unified in a rules interpreter. |
| 5. Game setup | **Partial** | Opening hand/Life/mulligan are represented. Leader-specific Life setup, official starting-player selection, simultaneous “start of game” effects and their ordering, deck shuffling after setup effects, and strict legality for all formats/cards are not comprehensively tested. |
| 6. Turn progression | **Partial** | Phase names and first-player first-draw exception exist. Refresh-phase start-of-turn effects and exact timing are not resolved; effect durations such as “until end of turn” are not generally expired; effect windows and end-phase timing need explicit tests. |
| 7. Attacks and battles | **Partial** | The explicit battle state machine covers turn-player attack validation, first-turn restriction, target legality including effect-granted active-Character targeting, selected attack prohibitions, Rush exceptions, Blocker redirect/limit, Unblockable, Counter power, battle power comparison, selected battle K.O., Double Attack, Banish and Trigger callbacks. Card-specific timing/effects, Event Counter costs/effects, all keyword interactions and exhaustive official scenarios remain incomplete. |
| 8. Activating/resolving effects | **Partial** | Explicit handlers and a sequential DSL exist. There is no complete effect parser/compiler. Activation conditions/costs, optional choices, target legality, nested resolution, replacement/prevention effects, and player-chosen ordering of simultaneous effects are not complete. Queue sorting by controller/timestamp alone is not a complete rules implementation. |
| 9. Rule processing | **Partial** | A centralized checkpoint handles deck-out and Leader damage at zero Life, including simultaneous defeat; draw effects check after each card. It is not yet integrated with every state-changing effect or all replacement, prevention, and effect-based win/loss rules. |
| 10. Keyword effects / keywords | **Fail** | Only selected helpers exist (including limited Double Attack/Banish handling). All keyword definitions and interactions are not implemented or tested card-by-card. |
| 11. Other | **Fail** | Infinite loops, revealing cards, viewing secret areas, and returning hidden information to its previous state are not fully implemented. |
| Official general FAQ / card-specific Q&A | **Not validated** | No versioned, complete FAQ corpus or executable ruling fixtures is present. |
| Errata / revised card text | **Not validated** | Official errata must be imported with effective dates and before/after text, then connected to the applicable card printing and regression tests. The official index lists a new EB-05 errata notice dated 2026-10-23 and a ban/restricted notice dated 2026-10-12. |
| Tournament / floor policy | **Out of engine scope; reference required** | The Tournament Rules Manual covers event procedures, judge roles, appeals, penalties, deck legality at events, communication, and tournament conduct. These are not the same as in-game Comprehensive Rules; add a separate policy reference layer if Brook Lab will model judge calls or event procedure. |
| Full English card pool and every card effect | **Not validated** | No complete, reconciled live import is available in this runtime. Every unique card number, printing, text variant, Trigger, erratum, and FAQ interaction must be accounted for before this gate can pass. |

## Code-level defects confirmed by inspection

1. **Defeat timing:** The new shared checkpoint corrects several deck-out and zero-Life battle paths, but legacy paths and all effect handlers have not yet been proven to route every defeat condition through it. Continue auditing every state mutation and checkpoint boundary.
2. **Battle resolution:** Legacy exports now delegate to the explicit battle engine, but full card-specific Trigger resolution, Event Counter validation/payment, replacement effects and every interaction are still incomplete. Do not use it as a judge-accurate battle resolver.
3. **Attack validation:** The battle core now enforces a turn-player check, selected attack prohibitions, first-turn restriction and same-turn Rush exceptions. These semantics still need to be checked against the full current rules/FAQ corpus and every card-specific permission.
4. **Effect scheduling:** `enqueueTriggeredEffect()` sorts queued effects by turn-player controller and timestamp, but lacks the complete timing-window, optional-activation, and player-choice rules needed for all simultaneous effects.
5. **Duration handling:** the runtime only filters a specific `until-start-of-your-next-turn` modifier. It does not yet generally process all duration boundaries, including end-of-turn effects.
6. **Database/legality:** the old validator can warn on unknown IDs rather than proving legality. The newer runtime validator is stricter, but without a complete current card pool and current format-specific ban/restriction data it still cannot certify real decks.

## Test results and what they mean

Current local validation (2026-10-23 update): **44/44 JavaScript tests passed; 8/8 Python tests passed.** These tests cover a small set of setup, phase, deck validation, helper, DSL, and importer behaviors. They do **not** cover all rule sections, all keywords, every timing window, or every card effect. No claim of full correctness should be inferred from the pass count.

## Required acceptance gate before calling Brook Lab judge-accurate

For every rule and card effect, track the exact source/version and create: (1) positive case, (2) negative/illegal-action case, (3) boundary/impossible-action case, (4) interaction case, (5) simultaneous/timing case where relevant, and (6) regression fixture. The full test suite must compare the engine's state transitions against manually resolved official scenarios. Unsupported effects must halt or explicitly mark a simulation incomplete; they must never silently approximate a judge ruling.

## Primary links

- Official Comprehensive Rules PDF: https://en.onepiece-cardgame.com/pdf/rule_comprehensive.pdf?20260828=
- Official rules index and current updates: https://en.onepiece-cardgame.com/rules/
- Official Judge Program page: https://en.onepiece-cardgame.com/topics/003.php
- Searchable Comprehensive Rules mirror: https://onepiece.gg/rules/comprehensive-rules/

## 2026-10-23 focused engine hardening

Implemented a new generic battle state machine (`src/battle-engine.mjs`) and defeat rule checkpoint (`src/rule-processing.mjs`). The legacy rules-core battle exports now delegate to the state machine. Added regression coverage for Blocker, Unblockable, Counter power, equal-power battles, Double Attack, Trigger handling, Banish, first-turn attack prohibition, character K.O., deck-out at the moment the deck becomes empty, and simultaneous defeat.

Verification after this change: `npm test` passes 35/35 JavaScript tests and `python -m pytest -q` passes 8/8 Python tests. This is a meaningful improvement but not a claim of full Comprehensive Rules coverage. Effect timing callbacks and printed-card effect resolution remain caller-supplied, and the complete official FAQ/errata/card interaction suite has not been run.


## 2026-10-23 additional hardening

Added `tests/official-rule-cases.test.mjs` with regression cases keyed to Comprehensive Rules sections for turn-player-only attacks, first-turn restriction, active Character targeting permissions, attack prohibitions, power comparison, Blocker limit/redirection, Counter power, deck-out/simultaneous defeat, and Banish/Trigger bypass. The cases are derived from rules text; they are not official Bandai-published ruling examples. The engine now rejects attacks by the non-turn player and supports explicit `canAttackActiveCharacters` / `canAttackActiveCharactersThisTurn` permission flags. The package is branded **One Piece Test Sim** with intended domain `www.OnePieceTestSim.com`; domain registration, DNS, hosting, and public deployment are not included.
