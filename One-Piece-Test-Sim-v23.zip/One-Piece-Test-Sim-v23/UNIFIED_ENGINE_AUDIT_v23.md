# Unified Engine Audit — v23

## Verified in this release

- Canonical runtime is used to initialize match state and manage turn phases.
- The unified action facade now supports `play-character` with pre-mutation checks for phase, turn ownership, hand membership, card type, cost, DON!!, and Character-area capacity.
- Rejected Character plays are tested to leave the full state unchanged.
- Match setup uses seeded shuffle, initial five-card hands and five Life cards, and ten DON!! cards per player.
- A bounded basic match loop uses `executeUnifiedAction` for turns, Character plays, attacks, battle steps, and battle damage.
- Match series report sample size and categories for wins, draws, turn limits, and invalid matches; first player alternates.
- Unsupported compiled On Play effects are recorded rather than guessed.

## Test results

- JavaScript: 103 passed, 0 failed.
- Python: 15 passed, 0 failed.
- `node --check` passed for all source modules and JavaScript tests.
- A 10-game synthetic smoke series completed with no invalid matches. Those fixture results are a harness check only, not competitive deck data.

## Known limitations

- The match policy is greedy and incomplete; it plays Characters and attacks the opposing Leader but does not model all legal choices.
- Event play, full counter selection, comprehensive Trigger/On Play/On Attack resolution, all keywords, and exact timing interactions are not implemented generally.
- Unsupported card effects can materially distort match outcomes.
- Existing rule-processing and card-database coverage gaps remain. This is not a judge-accurate One Piece TCG simulator and must not be used to claim reliable Brook-vs-meta win rates.
