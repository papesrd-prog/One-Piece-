# Punk Records English Dataset Audit

**Audit date:** 2026-10-23  
**Source snapshot:** `buhbbl/punk-records` ZIP uploaded by the project owner  
**Source manifest generation time:** 2026-10-23 11:10:18 UTC  
**Source:** https://github.com/buhbbl/punk-records  
**Source description:** generated from card and pack data fetched from the official One Piece Card Game website using `vegapull`.

## Import result

- English pack entries in `english/packs.json`: **61**
- Grouped English pack JSON files read: **61**
- Parse/import errors: **0**
- Records read: **4,911**
- Unique card IDs in the source index: **4,910**
- Duplicate ID across source pack files: **`OP07-091_p1`** (appears twice; card text/stats match, but `pack_id` differs)
- Unique IDs that are base IDs after removing a trailing `_pN` variant suffix: **3,262**
- IDs with a `_pN` variant suffix: **1,648**
- Records with non-empty effect field: **4,911**, including **430** records whose effect is just `-` (not an ability implementation)
- Records with non-empty trigger text: **840**
- Records missing ID: **0**
- Records missing name: **0**

## What these numbers mean

This snapshot provides a useful structured English card-data foundation. The import preserved the original record in `sourceRecord`, as well as effect and trigger text, card stats, colors, types, rarity, set/pack ID, image URL, and source file provenance.

The snapshot has **4,910 unique English card IDs**, not 5,603. If 5,603 is the target count under the same definition of a unique card ID, this snapshot is short by **693 IDs**. The target may use a different counting convention (e.g. other languages, product printings, or variant handling), so the figures should not be treated as directly comparable until that target list is defined.

The `_pN` suffixes represent variant/printing-specific IDs in this dataset. Removing those suffixes yields 3,262 base IDs; this is a diagnostic count, not a claim that all printings or gameplay identities have been reconciled.

## Important limitations

- This is a third-party generated snapshot, not an official Bandai ruling database.
- `recordsOfficiallyVerified` remains **0**.
- `effectsImplemented` remains **0**: importing effect text does not implement card behavior.
- Errata and official FAQs/rulings have not been reconciled.
- A card with effect text `-` is not necessarily missing data; some cards have no printed effect.
- The dataset contains English card records only in the simulator import. Other language folders are not merged into the English card pool.
- The duplicate `OP07-091_p1` is retained in the raw import output for provenance; consumers should key gameplay lookup by card ID and use a deterministic unique-ID index.

## Generated artifacts

- `punk_records_cards.normalized.jsonl` — one normalized record per source record, preserving duplicate source rows.
- `punk_records_cards.normalized.csv` — tabular normalized records.
- `punk_records_import_status.json` — machine-readable import counts, errors, duplicate IDs, and checksums.

Do not describe the simulator as fully judge-accurate based on this import alone. Next steps are to reconcile coverage against the intended 5,603-card list, verify official text/errata, and implement/test each effect and rules interaction.
