The canonical opponent deck list data is data/opponent-decks.json. This directory is reserved for generated audits/reports and does not duplicate the deck pool.
