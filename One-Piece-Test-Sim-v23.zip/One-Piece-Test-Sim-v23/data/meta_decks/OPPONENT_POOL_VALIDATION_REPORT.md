# Opponent Deck Pool Validation Report

Generated 2026-10-23 from local imported card database and legality snapshot effective 2026-10-12. This is a local validator report, not an official event-legality certification.

| Deck | Date / placement | Main deck | Unknown IDs | Local check | Provisional source quantities |
|---|---|---:|---:|---|---:|
| Red/Black Sabo — Akita (1st, Extra Grand Battle) | 2026-10-04 / 1st | 50/50 | 0 | PASS (0 errors) | Yes |
| Blue Rocks.D.Xebec — Tuna (1st, Flagship) | 2026-10-04 / 1st | 50/50 | 0 | PASS (0 errors) | Yes |
| Purple/Yellow Nico Robin — Kanzawa (1st, Standard Battle) | 2026-10-02 / 1st | 50/50 | 0 | PASS (0 errors) | No |
| Purple Enel — Xixo (2nd, London Regionals) | 2026-10-04 / 2nd | 50/50 | 0 | PASS (0 errors) | Yes |
| Black Monkey.D.Luffy — Standard Battle (1st) | 2026-09-30 / 1st | 50/50 | 0 | PASS (0 errors) | No |

## Heuristic profile derivation (not match win rates)

| Deck | Mean cost | Mean power | Low-cost ratio | Counter ratio | Removal-text density | Hit proxy | Removal proxy |
|---|---:|---:|---:|---:|---:|---:|---:|
| Red/Black Sabo — Akita (1st, Extra Grand Battle) | 3 | 3660 | 66.0% | 62.0% | 56.0% | 0.6096 | 0.72 |
| Blue Rocks.D.Xebec — Tuna (1st, Flagship) | 3.8 | 4920 | 34.0% | 8.0% | 22.0% | 0.5084 | 0.461 |
| Purple/Yellow Nico Robin — Kanzawa (1st, Standard Battle) | 3.92 | 4400 | 32.0% | 76.0% | 0.0% | 0.4872 | 0.088 |
| Purple Enel — Xixo (2nd, London Regionals) | 1.54 | 1940 | 74.0% | 46.0% | 10.0% | 0.6152 | 0.291 |
| Black Monkey.D.Luffy — Standard Battle (1st) | 3 | 3440 | 72.0% | 58.0% | 64.0% | 0.6264 | 0.72 |

## Provenance and limitations

- **Red/Black Sabo — Akita (1st, Extra Grand Battle):** [source list](https://opmetagame.com/decks/oo-op17-red-black-sabo-7ja2gw/). Transcribed from published 50-card list. One copy of Gerd is inferred from the displayed category total (48 Characters + 2 Events) because the text view omits its quantity marker; must be treated as provisional pending source recheck.
- **Blue Rocks.D.Xebec — Tuna (1st, Flagship):** [source list](https://opmetagame.com/decks/oo-op17-blue-rocks-d-xebec-gaxk19/). Transcribed from published 50-card list. Count of And That’s When Somebody Makes Fun of Their Friend’s Dream!!!! is inferred as 1 from the displayed category total (41 Characters + 9 Events); provisional pending source recheck.
- **Purple/Yellow Nico Robin — Kanzawa (1st, Standard Battle):** [source list](https://opmetagame.com/decks/oo-op17-purple-yellow-nico-robin-bnucc1/). Transcribed from published 50-card list.
- **Purple Enel — Xixo (2nd, London Regionals):** [source list](https://opmetagame.com/decks/oo-op17-purple-enel-1dva4w5/). Transcribed from published 50-card list. One copy each of Divine Departure and Gum-Gum Lightning is inferred from the displayed event total (23 Events); provisional pending source recheck.
- **Black Monkey.D.Luffy — Standard Battle (1st):** [source list](https://opmetagame.com/decks/oo-op17-black-monkey-d-luffy-1wfdvgl/). Transcribed from published 50-card list.

All five lists pass the local checks against the dated snapshot, and Green Dracule Mihawk is excluded. The list pages are from early OP-17 tournament entries (Oct 2–4, 2026), so this is a starter pool, not a continuously refreshed or complete current meta pool. Three lists have four total quantities inferred from source-page category totals; recheck those before treating lists as exact. Opponents are not simulated card-by-card; profile numbers are transparent heuristics only.
