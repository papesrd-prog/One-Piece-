#!/usr/bin/env python3
"""Import a locally downloaded buhbbl/punk-records English dataset into One Piece Test Sim.

Download/extract https://github.com/buhbbl/punk-records, then point --source at its
root folder. Supports english/data/*.json (cards grouped by pack) and english/cards/**/*.json
(split-per-card). This tool is offline and does not fetch GitHub itself.
"""
from __future__ import annotations
import argparse, csv, hashlib, json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
REPO_URL = 'https://github.com/buhbbl/punk-records'

def now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')
def load_json(path: Path):
    with path.open('r', encoding='utf-8') as f: return json.load(f)
def find_card_files(source: Path) -> list[Path]:
    english = source / 'english' if (source / 'english').is_dir() else source
    grouped = english / 'data'
    if grouped.is_dir():
        return sorted(p for p in grouped.glob('*.json') if p.name not in {'packs.json','manifest.json'})
    split = english / 'cards'
    if split.is_dir(): return sorted(split.rglob('*.json'))
    raise FileNotFoundError(f'Could not find english/data/*.json or english/cards/**/*.json under {source}')
def normalize(card: dict[str, Any], source_file: Path, source_root: Path, retrieved: str) -> dict[str, Any]:
    effect = str(card.get('effect') or '')
    trigger = str(card.get('trigger') or '')
    cid = str(card.get('id') or '')
    return {
        'cardId': cid, 'name': str(card.get('name') or ''),
        'category': card.get('category') or 'Character', 'colors': card.get('colors') or [],
        'cost': card.get('cost'), 'power': card.get('power'), 'counter': card.get('counter'),
        'attributes': card.get('attributes') or [], 'traits': card.get('types') or [],
        'keywords': [], 'effectText': effect, 'triggerText': trigger,
        'setCode': card.get('pack_id'), 'rarity': card.get('rarity'),
        'language': 'English', 'imageUrl': card.get('img_full_url') or card.get('img_url'),
        'source': 'Punk Records / vegapull; derived from official One Piece Card Game website',
        'sourceUrl': REPO_URL, 'sourceFile': str(source_file.relative_to(source_root)),
        'sourceRecord': card, 'retrievedAt': retrieved,
        'verificationStatus': 'unverified', 'errataStatus': 'not_reconciled',
        'implementedEffectStatus': 'not-started', 'effectHandlerIds': [],
        'notes': 'Imported card data is not official-ruling verification; check current errata and rules.'
    }
def import_dataset(source: Path, out: Path) -> dict[str, Any]:
    source = source.resolve(); out.mkdir(parents=True, exist_ok=True)
    files = find_card_files(source); cards = []; errors = []; checksums = {}; retrieved = now()
    for path in files:
        try:
            payload = load_json(path)
            rows = payload if isinstance(payload, list) else [payload]
            for row in rows:
                if not isinstance(row, dict): continue
                if row.get('id'):
                    cards.append(normalize(row, path, source, retrieved))
            checksums[str(path.relative_to(source))] = hashlib.sha256(path.read_bytes()).hexdigest()
        except Exception as exc: errors.append({'file': str(path), 'error': f'{type(exc).__name__}: {exc}'})
    counts = Counter(c['cardId'] for c in cards if c['cardId'])
    duplicates = sorted(k for k, v in counts.items() if v > 1)
    # Stable unique-ID lookup for simulator/runtime consumers. Keep the first
    # sorted source occurrence for duplicate IDs while retaining every source row
    # in JSONL/CSV and reporting duplicates in the audit.
    unique = {}
    for card in cards:
        if card['cardId']:
            unique.setdefault(card['cardId'], card)
    unique_json = out / 'punk_records_cards.by_id.json'
    unique_json.write_text(json.dumps(unique, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    jsonl = out / 'punk_records_cards.normalized.jsonl'
    with jsonl.open('w', encoding='utf-8') as f:
        for c in cards: f.write(json.dumps(c, ensure_ascii=False) + '\n')
    csv_path = out / 'punk_records_cards.normalized.csv'
    fields = ['cardId','name','category','colors','cost','power','counter','attributes','traits','effectText','triggerText','setCode','rarity','language','imageUrl','source','sourceUrl','sourceFile','retrievedAt','verificationStatus','errataStatus','implementedEffectStatus']
    with csv_path.open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
        for c in cards: w.writerow({k: json.dumps(c[k], ensure_ascii=False) if isinstance(c[k], (list,dict)) else c[k] for k in fields})
    status = {
        'generatedAt': now(), 'source': 'buhbbl/punk-records (vegapull)', 'sourceUrl': REPO_URL,
        'sourceRoot': str(source), 'inputFilesRead': len(checksums), 'inputFilesErrors': errors,
        'recordsImported': len(cards), 'uniqueCardIds': len(unique), 'duplicateCardIds': duplicates,
        'recordsWithEffectText': sum(bool(c['effectText'].strip()) for c in cards),
        'recordsWithTriggerText': sum(bool(c['triggerText'].strip()) for c in cards),
        'recordsMissingId': sum(not c['cardId'] for c in cards), 'recordsMissingName': sum(not c['name'] for c in cards),
        'completeDatasetRead': bool(checksums) and not errors,
        'recordsOfficiallyVerified': 0, 'effectsImplemented': 0,
        'uniqueIdIndex': str(unique_json.name),
        'inputSHA256': checksums,
        'warning': 'Dataset is a third-party generated snapshot. Coverage/currentness, official errata, judge rulings, and effect implementation require separate validation.'
    }
    (out / 'punk_records_import_status.json').write_text(json.dumps(status, indent=2, ensure_ascii=False), encoding='utf-8')
    return status

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source', required=True, help='Path to extracted punk-records repository or its english folder')
    ap.add_argument('--out', default=str(ROOT / 'data' / 'punk_records_import'), help='Output folder')
    args = ap.parse_args()
    status = import_dataset(Path(args.source), Path(args.out))
    print(json.dumps({k: status[k] for k in ['inputFilesRead','recordsImported','uniqueCardIds','recordsWithEffectText','recordsWithTriggerText','completeDatasetRead','recordsOfficiallyVerified','effectsImplemented']}, indent=2))
    return 0 if status['recordsImported'] else 1
if __name__ == '__main__': raise SystemExit(main())
