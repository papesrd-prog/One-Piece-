#!/usr/bin/env python3
"""Import publicly visible OnePiece.gg card metadata and image URLs via a real browser.

This tool stores card metadata and remote image URLs, not the artwork files themselves.
It intentionally does not bypass login, CAPTCHAs, access controls, or rate limits.
Requires: pip install playwright; playwright install chromium
"""
from __future__ import annotations
import argparse, asyncio, hashlib, json, re, sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'data' / 'database_import' / 'onepiece_gg'
BASE = 'https://onepiece.gg/cards/'

ID_RE = re.compile(r'\b(?:OP|ST|EB|PRB|P|DON|SP|EX|P\d{1,3})[- ]?\d{2,3}[- ]?\d{2,3}(?:_p\d+)?\b', re.I)

def now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')
def clean(v): return ' '.join(str(v or '').split())
def find_key(d, *names):
    if not isinstance(d, dict): return None
    low = {str(k).lower().replace('_','').replace('-',''):v for k,v in d.items()}
    for name in names:
        key = name.lower().replace('_','').replace('-','')
        if key in low and low[key] is not None: return low[key]
    return None

def card_like(d):
    if not isinstance(d, dict): return False
    cid = find_key(d,'cardId','card_id','code','number','id','cardNumber')
    name = find_key(d,'name','cardName','title')
    text = find_key(d,'effect','effectText','effect_text','rulesText','text')
    return bool(cid and name and (text is not None or ID_RE.search(str(cid)))) and bool(ID_RE.search(str(cid)))

def walk(obj):
    if isinstance(obj, dict):
        if card_like(obj):
            yield obj
        else:
            for v in obj.values(): yield from walk(v)
    elif isinstance(obj, list):
        for v in obj: yield from walk(v)

def normalize(raw, source_url, fetched):
    cid = clean(find_key(raw,'cardId','card_id','code','number','id','cardNumber')).upper().replace(' ','-')
    name = clean(find_key(raw,'name','cardName','title'))
    effect = clean(find_key(raw,'effect','effectText','effect_text','rulesText','text'))
    trigger = clean(find_key(raw,'trigger','triggerText','trigger_text'))
    images=[]
    for k,v in raw.items():
        if re.search(r'image|artwork|picture|thumbnail|img',str(k),re.I):
            if isinstance(v,str) and v.startswith(('http://','https://','/')): images.append(urljoin('https://onepiece.gg/',v))
            elif isinstance(v,dict):
                for iv in v.values():
                    if isinstance(iv,str) and iv.startswith(('http://','https://','/')): images.append(urljoin('https://onepiece.gg/',iv))
            elif isinstance(v,list):
                for iv in v:
                    if isinstance(iv,str) and iv.startswith(('http://','https://','/')): images.append(urljoin('https://onepiece.gg/',iv))
    imgs=list(dict.fromkeys(images))
    return {
      'cardId':cid,'name':name,'category':clean(find_key(raw,'category','cardType','type')),
      'colors':find_key(raw,'colors','color') or [], 'cost':find_key(raw,'cost'),
      'power':find_key(raw,'power'),'counter':find_key(raw,'counter'),
      'rarity':find_key(raw,'rarity'),'traits':find_key(raw,'traits','types') or [],
      'effectText':effect,'triggerText':trigger,'imageUrls':imgs,
      'imageUsage':'remote_reference_only; artwork ownership/permission not verified',
      'source':'OnePiece.gg','sourceUrl':source_url,'retrievedAt':fetched,
      'verificationStatus':'third_party_unverified','errataStatus':'not_reconciled',
      'implementedEffectStatus':'not_implemented','rawSourceRecord':raw
    }

async def main_async(args):
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        print('Missing Playwright. Run: python -m pip install playwright && python -m playwright install chromium',file=sys.stderr); return 2
    OUT.mkdir(parents=True,exist_ok=True)
    fetched=now(); captured=[]; failures=[]; page_records=[]; seen_urls=set()
    async with async_playwright() as p:
        browser=await p.chromium.launch(headless=not args.show_browser)
        context=await browser.new_context(viewport={'width':1440,'height':1000})
        page=await context.new_page()
        async def on_response(resp):
            try:
                ctype=resp.headers.get('content-type','')
                if 'json' in ctype:
                    body=await resp.json()
                    found=list(walk(body))
                    if found: captured.extend({'raw':x,'url':resp.url} for x in found)
            except Exception: pass
        page.on('response',on_response)
        try:
            await page.goto(args.url,wait_until='domcontentloaded',timeout=60000)
            await page.wait_for_timeout(args.settle_ms)
            # Capture rendered cards and image URLs from the listing as well as JSON APIs.
            for _ in range(args.scrolls):
                rows=await page.evaluate('''() => Array.from(document.querySelectorAll('a[href*="/cards/"]')).map(a => ({url:a.href, text:(a.innerText||a.getAttribute('aria-label')||'').trim(), images:Array.from(a.querySelectorAll('img')).map(i=>i.currentSrc||i.src).filter(Boolean), alt:Array.from(a.querySelectorAll('img')).map(i=>i.alt||'')}))''')
                for row in rows:
                    if row.get('url') and row['url'] not in seen_urls:
                        seen_urls.add(row['url']); page_records.append(row)
                await page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
                await page.wait_for_timeout(args.scroll_delay_ms)
            # Save browser-visible resource inventory to help diagnose app/API changes.
            resources=await page.evaluate('''() => performance.getEntriesByType('resource').map(r=>r.name).filter(n=>/api|card|image|graphql/i.test(n)).slice(0,10000)''')
            (OUT/'resource_urls.json').write_text(json.dumps(list(dict.fromkeys(resources)),indent=2),encoding='utf-8')
        except Exception as e:
            failures.append(f'{type(e).__name__}: {e}')
        await browser.close()
    # Normalize captured JSON records, dedupe identical raw records without collapsing printings.
    cards=[]; fingerprints=set()
    for item in captured:
        raw=item['raw']; fp=hashlib.sha256(json.dumps(raw,sort_keys=True,ensure_ascii=False,default=str).encode()).hexdigest()
        if fp in fingerprints: continue
        fingerprints.add(fp); cards.append(normalize(raw,item['url'],fetched))
    cards.sort(key=lambda c:(c['cardId'],c['name']))
    (OUT/'cards.from_json.jsonl').write_text(''.join(json.dumps(c,ensure_ascii=False)+'\n' for c in cards),encoding='utf-8')
    (OUT/'listing_links_and_images.json').write_text(json.dumps(page_records,ensure_ascii=False,indent=2),encoding='utf-8')
    status={'generatedAt':now(),'sourceUrl':args.url,'browserJsonCardRecords':len(cards),'listingLinks':len(page_records),'listingLinksWithImages':sum(bool(x.get('images')) for x in page_records),'recordsWithEffectText':sum(bool(x.get('effectText')) for x in cards),'recordsWithImageUrls':sum(bool(x.get('imageUrls')) for x in cards),'failures':failures,'complete':False,'note':'A rendered listing may lazy-load only a subset. Validate counts against the site and reconcile printings, errata and rules before production use. Card artwork remains remotely referenced; no images are bulk-downloaded.'}
    (OUT/'import-status.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
    print(json.dumps(status,indent=2))
    return 0 if cards or page_records else 3

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--url',default=BASE)
    ap.add_argument('--show-browser',action='store_true')
    ap.add_argument('--scrolls',type=int,default=80,help='number of listing scroll passes; adjust based on site behavior')
    ap.add_argument('--settle-ms',type=int,default=5000)
    ap.add_argument('--scroll-delay-ms',type=int,default=900)
    args=ap.parse_args()
    return asyncio.run(main_async(args))
if __name__=='__main__': raise SystemExit(main())
