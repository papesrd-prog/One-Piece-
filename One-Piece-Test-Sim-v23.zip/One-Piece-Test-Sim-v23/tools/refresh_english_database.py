#!/usr/bin/env python3
"""Refresh the English OPTCG fallback database from OPTCG API and Limitless.

This is a best-effort reproducible importer. It does NOT claim that third-party
sources are authoritative or that every English printing/erratum is complete.
Python 3.10+, requests, beautifulsoup4 recommended (requests is sufficient for API).
"""
from __future__ import annotations
import argparse, csv, hashlib, json, re, sys, time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin

import requests

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'data' / 'database_import' / 'raw'
OUT = ROOT / 'data' / 'database_import'
REPORTS = ROOT / 'reports'
BASE = 'https://www.optcgapi.com'
LIMITLESS = 'https://onepiece.limitlesstcg.com/cards/'
HEADERS = {'User-Agent': 'BrookLab-CardDatabase-Research/1.0 (personal TCG research; polite low-rate client)'}
TIMEOUT = 30

ALIASES = {
 'cardId': ['cardId','card_id','card_number','card_no','number','id','Card Number','Card No.'],
 'name': ['name','card_name','cardName','Name','Card Name'],
 'category': ['category','type','card_type','cardType','Card Type'],
 'colors': ['colors','color','colour','Color'],
 'cost': ['cost','play_cost','playCost','Cost'],
 'power': ['power','Power'],
 'counter': ['counter','Counter'],
 'attributes': ['attributes','attribute','Attribute'],
 'traits': ['types','traits','type_line','Type'],
 'effectText': ['effectText','effect','effect_text','text','Effect'],
 'triggerText': ['triggerText','trigger','trigger_text','Trigger'],
 'rarity': ['rarity','Rarity'],
 'blockIcon': ['blockIcon','block_icon','block','Block'],
 'setCode': ['setCode','set_code','set','set_id','Set'],
 'imageUrl': ['image_url','imageUrl','image'],
}

def now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')
def sha256(b: bytes): return hashlib.sha256(b).hexdigest()
def slug(s): return re.sub(r'[^a-z0-9]+','-',str(s).lower()).strip('-')
def listify(v):
    if v is None or v == '': return []
    if isinstance(v, list): return [str(x).strip() for x in v if x is not None and str(x).strip()]
    if isinstance(v, dict): return [str(x).strip() for x in v.values() if x is not None and str(x).strip()]
    # common third-party delimiter variants
    return [x.strip() for x in re.split(r'\s*[,;/|]\s*', str(v)) if x.strip()]
def int_or_none(v):
    if v is None or v == '' or str(v).lower() in {'null','none','-','—','n/a'}: return None
    m = re.search(r'-?\d+', str(v).replace(',',''))
    return int(m.group()) if m else None
def pick(d, names):
    if not isinstance(d, dict): return None
    low = {str(k).lower().replace(' ','_'): v for k,v in d.items()}
    for name in names:
        if name in d and d[name] is not None: return d[name]
        key = name.lower().replace(' ','_')
        if key in low and low[key] is not None: return low[key]
    return None

def walk_records(obj):
    """Recursively find card-shaped objects in differently shaped API responses."""
    if isinstance(obj, dict):
        raw_id = pick(obj, ALIASES['cardId'])
        raw_name = pick(obj, ALIASES['name'])
        if raw_id is not None and raw_name is not None and re.search(r'(OP|ST|EB|PRB|P|DON|P-|SP|EX)[-_ ]?\d{2,3}[-_ ]?\d{2,3}|DON[-_ ]?\d{3}', str(raw_id), re.I):
            yield obj
            return
        for v in obj.values(): yield from walk_records(v)
    elif isinstance(obj, list):
        for v in obj: yield from walk_records(v)

def first(obj, field): return pick(obj, ALIASES[field])
def normalize(raw, source, source_url, fetched_at):
    card_id = re.sub(r'\s+','',str(first(raw,'cardId') or '')).replace('_','-')
    # Keep printed ID exactly in normalized hyphenated convention when possible.
    card_id = card_id.upper()
    category = str(first(raw,'category') or '').strip()
    if category.lower() in {'don','don!!','don card'}: category = 'DON!!'
    elif category.lower() in {'character','event','stage','leader'}: category = category.title()
    elif not category: category = 'Unknown'
    set_code = first(raw,'setCode')
    if isinstance(set_code, dict): set_code = set_code.get('id') or set_code.get('code') or set_code.get('name')
    if not set_code:
        m = re.match(r'([A-Z]+\d{2,3}|DON|P)', card_id)
        set_code = m.group(1) if m else None
    effect = first(raw,'effectText')
    trigger = first(raw,'triggerText')
    return {
      'cardId': card_id, 'name': str(first(raw,'name') or '').strip(), 'rarity': first(raw,'rarity'),
      'category': category, 'colors': listify(first(raw,'colors')), 'cost': int_or_none(first(raw,'cost')),
      'power': int_or_none(first(raw,'power')), 'counter': int_or_none(first(raw,'counter')),
      'attributes': listify(first(raw,'attributes')), 'traits': listify(first(raw,'traits')),
      'blockIcon': int_or_none(first(raw,'blockIcon')), 'effectText': str(effect or '').strip(),
      'triggerText': str(trigger or '').strip(), 'setCode': str(set_code or ''),
      'imageUrl': first(raw,'imageUrl'), 'language': 'en (source dataset stated English; verify)',
      'region': 'Western/English (not independently verified)', 'source': source, 'sourceUrl': source_url,
      'retrievedAt': fetched_at, 'verificationStatus': 'third_party_unverified',
      'errataStatus': 'not_reconciled', 'implementedEffectStatus': 'not_implemented',
      'rawSourceRecord': raw
    }

def get_json(session, url):
    r = session.get(url, headers=HEADERS, timeout=TIMEOUT)
    r.raise_for_status()
    return r.content, r.json()

def get_text(session, url):
    r = session.get(url, headers=HEADERS, timeout=TIMEOUT)
    r.raise_for_status()
    return r.content, r.text

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--api-base', default=BASE, help='Base URL for OPTCG API (default https://www.optcgapi.com)')
    ap.add_argument('--skip-limitless', action='store_true', help='Skip Limitless set-index cross-check')
    ap.add_argument('--sleep', type=float, default=0.6, help='Delay between requests in seconds')
    args = ap.parse_args()
    for p in (RAW, OUT, REPORTS): p.mkdir(parents=True, exist_ok=True)
    s = requests.Session(); fetched = now(); errors=[]; hashes={}; datasets={}; endpoint_map={
      'all_sets': '/api/allSets/', 'all_set_cards': '/api/allSetCards/',
      'all_decks': '/api/allDecks/', 'all_starter_cards': '/api/allSTCards/',
      'all_promos': '/api/allPromoCards/', 'all_don': '/api/allDonCards/'
    }
    for name,path in endpoint_map.items():
      url=args.api_base.rstrip('/')+path
      try:
        blob,obj=get_json(s,url); (RAW/f'{name}.json').write_bytes(blob); hashes[str((RAW/f'{name}.json').relative_to(ROOT))]=sha256(blob)
        datasets[name]=obj
        print(f'OK {name}: {len(obj) if isinstance(obj,(list,dict)) else "payload"}')
      except Exception as e:
        errors.append({'source':'OPTCG API','endpoint':url,'error':f'{type(e).__name__}: {e}'})
        print(f'ERROR {name}: {e}', file=sys.stderr)
      time.sleep(max(0,args.sleep))
    limitless_sets=[]
    if not args.skip_limitless:
      try:
        blob,html=get_text(s,LIMITLESS); (RAW/'limitless_cards_index.html').write_bytes(blob); hashes[str((RAW/'limitless_cards_index.html').relative_to(ROOT))]=sha256(blob)
        # Parse set links without requiring a specific HTML structure.
        try:
          from bs4 import BeautifulSoup
          soup=BeautifulSoup(html,'html.parser')
          seen=set()
          for a in soup.find_all('a',href=True):
            href=urljoin(LIMITLESS,a['href']); title=' '.join(a.get_text(' ',strip=True).split())
            if '/cards/' in href and href.rstrip('/') != LIMITLESS.rstrip('/') and href not in seen and title:
              seen.add(href); limitless_sets.append({'name':title,'url':href})
        except ImportError:
          # Regex fallback captures card-set slug links and nearby anchor text.
          for m in re.finditer(r'<a\b[^>]*href=["\']([^"\']*/cards/[^"\']+)["\'][^>]*>(.*?)</a>',html,re.I|re.S):
            href=urljoin(LIMITLESS,m.group(1)); title=re.sub('<[^>]+>',' ',m.group(2)); title=' '.join(title.split())
            if title and href not in {x['url'] for x in limitless_sets}: limitless_sets.append({'name':title,'url':href})
        (OUT/'limitless_set_index.json').write_text(json.dumps({'sourceUrl':LIMITLESS,'retrievedAt':fetched,'sets':limitless_sets},indent=2),encoding='utf-8')
        print(f'OK Limitless set index: {len(limitless_sets)} links')
      except Exception as e:
        errors.append({'source':'Limitless','endpoint':LIMITLESS,'error':f'{type(e).__name__}: {e}'})
        print(f'ERROR Limitless index: {e}', file=sys.stderr)
    # Normalize all card-shaped records across endpoints. Keep source/set duplicates as printings.
    normalized=[]; seen_raw=set()
    for source_name,obj in datasets.items():
      src_url=args.api_base.rstrip('/')+endpoint_map[source_name]
      for raw in walk_records(obj):
        card=normalize(raw,'OPTCG API',src_url,fetched)
        # Deduplicate only exact repeated JSON records within the same card ID/source.
        fingerprint=hashlib.sha256(json.dumps(raw,sort_keys=True,ensure_ascii=False,default=str).encode()).hexdigest()
        if fingerprint in seen_raw: continue
        seen_raw.add(fingerprint); normalized.append(card)
    # Stable order and duplicate ID report: records remain printings/source variants.
    normalized.sort(key=lambda x:(x['cardId'],x['setCode'],x['name']))
    ids=sorted(set(x['cardId'] for x in normalized))
    with (OUT/'cards.normalized.jsonl').open('w',encoding='utf-8') as f:
      for c in normalized: f.write(json.dumps(c,ensure_ascii=False)+'\n')
    fields=['cardId','name','rarity','category','colors','cost','power','counter','attributes','traits','blockIcon','effectText','triggerText','setCode','imageUrl','language','region','source','sourceUrl','retrievedAt','verificationStatus','errataStatus','implementedEffectStatus']
    with (OUT/'cards.normalized.csv').open('w',newline='',encoding='utf-8-sig') as f:
      w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
      for c in normalized: w.writerow({k:json.dumps(c[k],ensure_ascii=False) if isinstance(c[k],list) else c[k] for k in fields})
    id_groups={}
    for c in normalized: id_groups.setdefault(c['cardId'],[]).append(c)
    duplicates=[{'cardId':k,'records':len(v),'names':sorted(set(x['name'] for x in v)),'sets':sorted(set(x['setCode'] for x in v))} for k,v in id_groups.items() if len(v)>1]
    (OUT/'duplicate_id_report.json').write_text(json.dumps(duplicates,indent=2,ensure_ascii=False),encoding='utf-8')
    missing=[{'cardId':c['cardId'],'name':c['name'],'missing':['effectText'] if not c['effectText'] else []} for c in normalized if not c['effectText'] and not c['triggerText'] and c['category'] not in {'DON!!'}]
    (OUT/'missing_effect_text_report.json').write_text(json.dumps(missing,indent=2,ensure_ascii=False),encoding='utf-8')
    set_counts={}
    for c in normalized: set_counts.setdefault(c['setCode'],set()).add(c['cardId'])
    with (OUT/'set_inventory.csv').open('w',newline='',encoding='utf-8-sig') as f:
      w=csv.writer(f); w.writerow(['setCode','uniqueCardIds','source'])
      for k,v in sorted(set_counts.items()): w.writerow([k,len(v),'OPTCG API'])
    status={'generatedAt':now(),'sourceScope':'English dataset claim from third-party API; not independently verified','apiBase':args.api_base,'limitlessIndexUrl':LIMITLESS,'endpointsSucceeded':sorted(datasets),'endpointsFailed':errors,'limitlessSetLinks':len(limitless_sets),'normalizedRecords':len(normalized),'uniqueCardIds':len(ids),'recordsWithEffectText':sum(bool(x['effectText']) for x in normalized),'recordsWithTriggerText':sum(bool(x['triggerText']) for x in normalized),'recordsMarkedVerified':0,'effectsImplemented':0,'duplicateCardIdGroups':len(duplicates),'recordsMissingEffectAndTrigger':len(missing),'complete':False,'reason':'Third-party import only; product/printing/errata reconciliation and effect implementation are not completed.','rawChecksumsSHA256':hashes}
    (OUT/'database-status.json').write_text(json.dumps(status,indent=2,ensure_ascii=False),encoding='utf-8')
    (OUT/'import-errors.json').write_text(json.dumps(errors,indent=2,ensure_ascii=False),encoding='utf-8')
    report=['# English OPTCG fallback import report','',f"Generated: {status['generatedAt']}",'', '**Completeness: NOT VERIFIED.** This importer does not claim the English card pool is complete.','',f"- Normalized records: {len(normalized)}",f"- Unique card IDs: {len(ids)}",f"- Limitless set links captured: {len(limitless_sets)}",f"- Records with effect text: {status['recordsWithEffectText']}",f"- Records with trigger text: {status['recordsWithTriggerText']}",f"- Duplicate-ID groups: {len(duplicates)}",f"- Records with no effect and no trigger: {len(missing)}",f"- Source endpoints failed: {len(errors)}",'', '## Gaps that remain', '- OPTCG API describes English data through OP-15 plus starter decks; newer products may be absent.', '- Limitless set-index links are a cross-check, not a complete card-text import.', '- Alternative-art/reprint printings may not be separately represented by the API.', '- Official errata and rule changes have not been reconciled card-by-card.', '- All effects remain marked `not_implemented`; this is a card-data pipeline, not a full rules simulator.','', '## Source policy','- OPTCG API: third-party English card data; API documentation describes set, starter, promo, and DON endpoints.', '- Limitless: set index cross-check.', '- Bandai official English card list and rules remain the final authority for verification.', '', 'See `database-status.json`, `import-errors.json`, `duplicate_id_report.json`, `missing_effect_text_report.json`, and `set_inventory.csv`.']
    (REPORTS/'DATABASE_COVERAGE_REPORT.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
    print(json.dumps({k:status[k] for k in ['normalizedRecords','uniqueCardIds','limitlessSetLinks','recordsWithEffectText','duplicateCardIdGroups','complete']},indent=2))
    return 0 if normalized else 2
if __name__=='__main__': raise SystemExit(main())
