@echo off
cd /d "%~dp0.."
py -m pip install -r tools\requirements.txt
py tools\refresh_english_database.py
pause
