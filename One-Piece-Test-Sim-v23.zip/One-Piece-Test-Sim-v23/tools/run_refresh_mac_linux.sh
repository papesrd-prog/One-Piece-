#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m pip install -r tools/requirements.txt
python3 tools/refresh_english_database.py
