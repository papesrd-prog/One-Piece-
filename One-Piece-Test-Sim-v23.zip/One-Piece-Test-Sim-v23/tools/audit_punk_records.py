#!/usr/bin/env python3
"""Audit the imported Punk Records English card snapshot without guessing missing values."""
import argparse, collections, hashlib, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = ROOT / 'data/punk_records_import/punk_records_cards.normalized.jsonl'
DEFAULT_REPORT = ROOT / 'data/punk_records_import/punk_records_data_audit.generated.json'
REQUIRED = ('cardId', 'name', 'category', 'colors', 'effectText', 'setCode', 'sourceFile', 'verificationStatus', 'implementedEffectStatus')

def audit(path):
    rows=[]
    with path.open(encoding='utf-8') as f:
        for n,line in enumerate(f,1):
            if not line.strip(): continue
            try: rows.append(json.loads(line))
            except json.JSONDecodeError as e: raise ValueError(f'Invalid JSON on line {n}: {e}') from e
    ids=collections.Counter(r.get('cardId') for r in rows)
    duplicates={k:v for k,v in sorted(ids.items()) if k and v>1}
    unique={}
    for r in rows:
        cid=r.get('cardId')
        if cid and cid not in unique: unique[cid]=r
    missing={field:sum(1 for r in rows if r.get(field) in (None,'',[])) for field in REQUIRED}
    categories=collections.Counter(r.get('category') or '(blank)' for r in rows)
    colors=collections.Counter('+'.join(r.get('colors') or []) or '(blank)' for r in rows)
    report={
      'sourceFile':str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path),
      'sourceSha256':hashlib.sha256(path.read_bytes()).hexdigest(),
      'sourceRows':len(rows), 'uniqueCardIds':len(unique), 'duplicateCardIds':duplicates,
      'missingRequiredFields':missing,
      'categories':dict(sorted(categories.items())), 'colorCombinations':dict(sorted(colors.items())),
      'effectTextDashCount':sum(r.get('effectText') in (None,'','-') for r in rows),
      'nonemptyTriggerTextCount':sum(bool(r.get('triggerText')) for r in rows),
      'unverifiedRecordCount':sum(r.get('verificationStatus') != 'verified' for r in unique.values()),
      'notStartedEffectCount':sum(r.get('implementedEffectStatus') != 'implemented-and-tested' for r in unique.values()),
      'notes':['Missing cost/power/counter values can be valid for particular card categories; inspect by category before treating them as errors.',
               'Third-party imported text is not official ruling verification.',
               'Duplicate source rows are preserved in JSONL; unique browser lookup uses the first occurrence per cardId.']
    }
    return report, list(unique.values())

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--input',type=Path,default=DEFAULT_INPUT); ap.add_argument('--report',type=Path,default=DEFAULT_REPORT); ap.add_argument('--browser-json',type=Path,default=ROOT/'data/punk_records_import/cards.browser.json'); args=ap.parse_args()
    report,cards=audit(args.input)
    args.report.parent.mkdir(parents=True,exist_ok=True); args.report.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    args.browser_json.parent.mkdir(parents=True,exist_ok=True)
    # Keep the browser payload compact, while preserving source effect/trigger text and provenance.
    fields=('cardId','name','category','colors','cost','power','counter','effectText','triggerText','setCode','rarity','imageUrl','sourceFile','verificationStatus','implementedEffectStatus')
    slim=[{k:r.get(k) for k in fields} for r in cards]
    args.browser_json.write_text(json.dumps(slim,separators=(',',':'),ensure_ascii=False),encoding='utf-8')
    print(json.dumps({k:report[k] for k in ('sourceRows','uniqueCardIds','duplicateCardIds','missingRequiredFields','effectTextDashCount','nonemptyTriggerTextCount','unverifiedRecordCount','notStartedEffectCount')},indent=2))
    print(f'Wrote report: {args.report}\nWrote browser index: {args.browser_json} ({len(cards)} unique IDs)')
if __name__=='__main__': main()
