#!/usr/bin/env python3
"""Import One Piece card data from Scrydex with pagination and auditable provenance.

Requires SCRYDEX_API_KEY and SCRYDEX_TEAM_ID environment variables.
Does not treat third-party data as official rules certification.
Python 3.10+, requests.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, os, sys, time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlencode
import requests

ROOT = Path(__file__).resolve().parents[1]
BASE = 'https://api.scrydex.com/onepiece/v1'
TIMEOUT = 30

def now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')
def sha256(data: bytes) -> str: return hashlib.sha256(data).hexdigest()
def headers(api_key: str, team_id: str) -> dict[str, str]:
    return {'X-Api-Key': api_key, 'X-Team-ID': team_id, 'Accept': 'application/json', 'User-Agent': 'OnePieceTestSim-CardAudit/1.0'}
def get_page(session, url, hdrs, page, page_size):
    response = session.get(url, params={'page': page, 'page_size': page_size}, headers=hdrs, timeout=TIMEOUT)
    response.raise_for_status()
    payload = response.json()
    if not isinstance(payload, dict) or not isinstance(payload.get('data'), list):
        raise ValueError(f'Unexpected API response schema on page {page}: expected object with data array')
    return response.content, payload

def normalized_card(card: dict[str, Any], source_url: str, retrieved_at: str) -> dict[str, Any]:
    """Preserve the complete provider record and expose stable fields for audits."""
    exp = card.get('expansion') if isinstance(card.get('expansion'), dict) else {}
    rules = card.get('rules') if isinstance(card.get('rules'), list) else []
    return {
        'cardId': str(card.get('id') or card.get('printed_number') or ''),
        'name': str(card.get('name') or ''),
        'printedNumber': card.get('printed_number'),
        'number': card.get('number'),
        'cost': card.get('cost'), 'power': card.get('power'),
        'attribute': card.get('attribute'), 'type': card.get('type'),
        'colors': card.get('colors') or [], 'subtypes': card.get('subtypes') or [],
        'tags': card.get('tags') or [], 'printings': card.get('printings') or [],
        'rarity': card.get('rarity'), 'rarityCode': card.get('rarity_code'),
        'rules': rules, 'rulesText': '\n'.join(str(x) for x in rules),
        'images': card.get('images') or [], 'variants': card.get('variants') or [],
        'expansion': exp, 'expansionId': exp.get('id'), 'language': card.get('language'),
        'languageCode': card.get('language_code'), 'expansionSortOrder': card.get('expansion_sort_order'),
        'source': 'Scrydex API (third-party; not Bandai authority)', 'sourceUrl': source_url,
        'retrievedAt': retrieved_at, 'rawSourceRecord': card,
        'verificationStatus': 'third_party_data_imported_not_officially_verified',
        'errataStatus': 'not_reconciled', 'implementedEffectStatus': 'not_implemented'
    }

def import_cards(session, api_key: str, team_id: str, endpoint: str, out_dir: Path,
                 page_size: int = 250, delay: float = 0.15, max_pages: int | None = None) -> dict[str, Any]:
    if not api_key or not team_id:
        raise ValueError('Both SCRYDEX_API_KEY and SCRYDEX_TEAM_ID are required. Do not put credentials in source code.')
    if not 1 <= page_size <= 250: raise ValueError('page_size must be between 1 and 250')
    out_dir.mkdir(parents=True, exist_ok=True)
    endpoint_url = BASE + endpoint
    hdrs = headers(api_key, team_id)
    retrieved = now(); records = []; errors = []; hashes = {}; total_count = None; page = 1
    raw_dir = out_dir / 'raw'; raw_dir.mkdir(exist_ok=True)
    while True:
        if max_pages is not None and page > max_pages: break
        try:
            blob, payload = get_page(session, endpoint_url, hdrs, page, page_size)
            raw_path = raw_dir / f'page-{page:04d}.json'
            raw_path.write_bytes(blob); hashes[str(raw_path.relative_to(out_dir))] = sha256(blob)
            batch = payload['data']; records.extend(x for x in batch if isinstance(x, dict))
            if isinstance(payload.get('totalCount'), int): total_count = payload['totalCount']
            reported_size = payload.get('pageSize', len(batch))
            print(f'OK page {page}: {len(batch)} records' + (f' / reported total {total_count}' if total_count is not None else ''))
            if not batch or len(batch) < page_size or (total_count is not None and len(records) >= total_count): break
            page += 1; time.sleep(max(0, delay))
        except Exception as exc:
            errors.append({'page': page, 'error': f'{type(exc).__name__}: {exc}'})
            break
    cards = [normalized_card(c, endpoint_url, retrieved) for c in records]
    # Keep source rows, but separately report unique card IDs and duplicate records.
    ids = [c['cardId'] for c in cards if c['cardId']]
    unique_ids = sorted(set(ids))
    duplicate_ids = sorted({x for x in ids if ids.count(x) > 1})
    jsonl = out_dir / 'scrydex_cards.normalized.jsonl'
    with jsonl.open('w', encoding='utf-8') as f:
        for c in cards: f.write(json.dumps(c, ensure_ascii=False) + '\n')
    csv_path = out_dir / 'scrydex_cards.normalized.csv'
    fields = ['cardId','name','printedNumber','number','cost','power','attribute','type','colors','subtypes','tags','printings','rarity','rarityCode','rulesText','expansionId','language','languageCode','source','sourceUrl','retrievedAt','verificationStatus','errataStatus','implementedEffectStatus']
    with csv_path.open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
        for c in cards: w.writerow({k: json.dumps(c[k], ensure_ascii=False) if isinstance(c[k], (list,dict)) else c[k] for k in fields})
    status = {
        'generatedAt': now(), 'source': 'Scrydex One Piece API', 'endpoint': endpoint_url,
        'scope': 'All base cards' if endpoint == '/cards' else 'Cards scoped to endpoint expansion',
        'pageSizeRequested': page_size, 'pagesFetched': len(list(raw_dir.glob('page-*.json'))),
        'reportedTotalCount': total_count, 'recordsImported': len(cards), 'uniqueCardIds': len(unique_ids),
        'recordsWithRulesText': sum(bool(c['rulesText'].strip()) for c in cards),
        'recordsMissingId': sum(not c['cardId'] for c in cards), 'recordsMissingName': sum(not c['name'] for c in cards),
        'duplicateCardIds': duplicate_ids, 'errors': errors,
        'completePagination': not errors and (max_pages is None or (total_count is not None and len(cards) >= total_count)),
        'recordsOfficiallyVerified': 0, 'effectsImplemented': 0,
        'warning': 'Scrydex is a third-party card-data source. Imported records are not automatically official-rule verified, errata reconciled, or effect implemented.',
        'rawPageSHA256': hashes
    }
    (out_dir / 'scrydex_import_status.json').write_text(json.dumps(status, indent=2, ensure_ascii=False), encoding='utf-8')
    (out_dir / 'scrydex_import_errors.json').write_text(json.dumps(errors, indent=2, ensure_ascii=False), encoding='utf-8')
    return status

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--expansion', default=None, help='Expansion code such as OP01. Omit to import the global card endpoint.')
    ap.add_argument('--out', default=str(ROOT / 'data' / 'scrydex_import'), help='Output directory')
    ap.add_argument('--page-size', type=int, default=250)
    ap.add_argument('--delay', type=float, default=0.15)
    ap.add_argument('--max-pages', type=int, default=None, help='Optional small test run; leaves completePagination false unless all records fetched')
    args = ap.parse_args()
    api_key = os.environ.get('SCRYDEX_API_KEY', '').strip(); team_id = os.environ.get('SCRYDEX_TEAM_ID', '').strip()
    if not api_key or not team_id:
        print('Missing credentials. Create/access your Scrydex API credentials, then set SCRYDEX_API_KEY and SCRYDEX_TEAM_ID as environment variables. Do not paste secrets into chat or commit them to Git.', file=sys.stderr)
        return 2
    endpoint = f'/expansions/{args.expansion}/cards' if args.expansion else '/cards'
    try:
        status = import_cards(requests.Session(), api_key, team_id, endpoint, Path(args.out), args.page_size, args.delay, args.max_pages)
    except Exception as exc:
        print(f'Import failed: {type(exc).__name__}: {exc}', file=sys.stderr); return 1
    print(json.dumps({k: status[k] for k in ['endpoint','pagesFetched','reportedTotalCount','recordsImported','uniqueCardIds','completePagination','recordsOfficiallyVerified','effectsImplemented']}, indent=2))
    return 0 if status['recordsImported'] else 1
if __name__ == '__main__': raise SystemExit(main())
