# One Piece Test Sim — Brook Deck Lab Preview

## Run it (v16)
1. Extract `One-Piece-Test-Sim-v16.zip`.
2. Open a terminal/command prompt in the extracted `One-Piece-Test-Sim-v16` folder.
3. Run `python -m http.server 8000`.
4. Open `http://localhost:8000/index.html` for Brook Deck Lab or `http://localhost:8000/opponent-deck-library.html` for the tournament deck library.
5. Choose a published opponent list and run the exploratory comparison.

A local server is required because the browser loads JSON and JavaScript modules. No account or upload is required; all processing stays local after the files are downloaded.

## Important accuracy notes
This is a research prototype, not an official One Piece Card Game rules engine. It models:
- 50-card deck setup, opening hand, one heuristic mulligan, life, turn progression and DON growth;
- Brook leader mill effect as a simplified state transition;
- role-based approximations for card play/search/recovery/removal;
- abstract matchup pressure presets.

The **visible browser page** remains a heuristic Brook deck-comparison demo and does not call the full rules core. In v16 it can select sourced tournament decklists and derives pressure profiles from those lists, but it still does not execute opponent card actions one by one. The separate `src/` engine now implements a subset of generic battle procedure and has its own tests, but it does not yet fully implement every card's official effect, Event Counter costs/effects, all Trigger/keyword interactions, leader-specific effects, or complete end-of-turn rule processing. The displayed win figure is a **heuristic model proxy**, not a real or validated win rate. The draw/engine access statistics are more trustworthy than the match proxy.

## Deck changes in Revised B
+2 OP17-081 Gerd
+2 OP17-084 Tony Tony.Chopper
-1 OP08-036 Electrical Luna
-1 OP15-032 Brook
-1 OP16-035 Roronoa Zoro
-1 OP15-094 Roronoa Zoro

Both lists are 50 cards. The original list is preserved in the source.

## References
- Official comprehensive rules: https://en.onepiece-cardgame.com/pdf/rule_comprehensive.pdf
- Brook OP15-022 card reference: https://onepiece.cardsrealm.com/en-us/card/brook-op15-022
- Card reference pages: https://onepiece.gg/cards/

## Recommended next development steps
1. Replace all heuristic card records with exact card text, cost, power, counter, type, and traits.
2. Implement effect resolution and legal action generation.
3. Expand the initial five-list opponent pool to a refreshed, format-complete set of verified legal decklists and implement card-by-card opponent action policies.
4. Validate a set of games against manual play or an established simulator.
5. Only then use match win-rate differences as meaningful evidence.


## Rules Core v0.2 (experimental update)

The `src/rules-engine.mjs` module adds a tested, explicit state-transition core for setup, deck validation, basic mulligan, turn start, DON!! refresh/gain/payment, legal attack targets, ordered battle steps, basic damage/KO, and a fail-closed effect-handler registry. Run its tests with Node.js 20+ from this folder: `npm test` (or `node --test tests/*.test.mjs`).

### Critical limitations — not a completed simulator

This update does **not** complete the requested full OPTCG simulator. The English card pool is not yet reconciled against every official printing; `data/effect-coverage.csv` deliberately marks every observed ID unverified rather than inventing official card text. The rules module does not yet implement the full rules revision, full card-effect timing/queue, Trigger resolution, Blocker and counter choices, continuous/delayed effects, all keywords, official rulings, current restrictions, or full opponent decks/policies. It is a safer foundation than the prior heuristic-only page, not a judge-accurate replacement.

### Source-of-truth checklist

- Official English card list: https://en.onepiece-cardgame.com/cardlist/
- Official Comprehensive Rules PDF currently linked by Bandai: https://en.onepiece-cardgame.com/pdf/rule_comprehensive.pdf
- The official page should be checked for changes after rules version 1.2.1 (2026-08-28); never assume an older PDF is current.
- Set FAQs, official errata, and the banned/restricted list must be captured with effective dates.

### Deliverables in this archive

- `index.html` — existing local browser prototype (still heuristic).
- `src/rules-engine.mjs` — new experimental rules core.
- `tests/rules-engine.test.mjs` — automated core regression tests.
- `data/card.schema.json` — required schema for auditable card records.
- `data/effect-coverage.csv` — honest coverage inventory; currently unverified, not a complete card database.
- `data/rules-compliance.csv` — rule-area status and known gaps.

## Expanded rules runtime (experimental)
See `RULES_RUNTIME_STATUS.md` for implemented runtime behavior, validation results, official references, and known gaps. `src/rules-runtime.mjs` adds explicit turn phases, effect queue ordering, basic modifier tracking, Life/Trigger/Double Attack processing, strict deck validation, and fail-closed effect dispatch. It is not a complete implementation of every printed card effect.


## Judge-accuracy audit update (2026-10-23)

- Added `src/effect-dsl.mjs`, a deterministic explicit action DSL for authoring card effects with fail-closed handling for unknown actions.
- Added `tests/effect-dsl.test.mjs`; the full Node test suite now has 20 passing tests.
- Added `RULES_COVERAGE_MATRIX.csv`, `RULES_SOURCE_MANIFEST.json`, and `JUDGE_ACCURACY_GAP_AUDIT.md`.
- The simulator is **not judge-accurate**: the full English card pool is not imported, and every printed effect is not yet implemented or tested. Local network/DNS is blocked, so the live card import must be run on a machine with internet access using the supplied refresh scripts.


## OnePiece.gg card + image URL import (v4 addition)

OnePiece.gg's card index is now included as an additional source target. The browser-based importer captures JSON card records returned to the page and visible card links/image URLs. It stores remote image URLs rather than copying/rehosting card artwork. Third-party card data and effects still require reconciliation against official rules, errata, and printings; import status intentionally remains `complete: false`.

Requirements: Python 3.10+, `pip install playwright`, then `python -m playwright install chromium`. Run from this folder:

```bash
python tools/import_onepiece_gg.py
```

For debugging the page/API capture, run `python tools/import_onepiece_gg.py --show-browser`. Output is written to `data/database_import/onepiece_gg/`. The listing uses lazy loading and site implementation may change, so compare the output counts with the live site. Do not bypass login, CAPTCHA, or rate limits. Use remote card image URLs only where permitted by the source site's terms and relevant rights.

## Rules validation status (2026-10-23)
See `RULES_VALIDATION_REPORT.md` for a section-by-section audit against Bandai Comprehensive Rules v1.2.1. The project is **not judge-accurate**; the report documents known timing, battle, zone, keyword, FAQ, errata, and card-pool gaps. Passing tests do not certify full rules accuracy.


## Focused rules engine update (v0.3 development snapshot)

The new `src/battle-engine.mjs` is the canonical battle state machine used by the legacy rules-core battle exports. The project name is now One Piece Test Sim; the current browser page is not yet integrated with this engine. It handles attack declaration, target legality, first-turn battle restriction, attack-step callbacks, Blocker redirect/limit, Counter Step power additions, battle resolution, Leader Life damage, Double Attack, Banish, Trigger callback handling, battle K.O., and battle cleanup. `src/rule-processing.mjs` centralizes deck-out and Leader-damage-at-zero-Life defeat checks, including simultaneous defeat. The effect DSL calls rule processing at deck-draw checkpoints so effects cannot continue drawing after a deck-out loss.

The engine remains intentionally incomplete for card-specific rulings: effect callbacks and card text implementations must be supplied explicitly. See `RULES_VALIDATION_REPORT.md` and `RULE_CASES.md` for the verified scope and outstanding gaps. The latest local run passes 44 JavaScript tests and 8 Python tests; these tests do not certify judge accuracy.


## Name and domain

The project branding is **One Piece Test Sim** and the intended domain is **www.OnePieceTestSim.com**. This source package does not register the domain, configure DNS, or deploy a public website. Those steps require domain-registry and hosting accounts. The current `index.html` is still a local Brook deck-comparison preview; the battle/rules modules are a separate experimental engine and are not yet wired into a full playable website.

## Scrydex card-data import (new)

One Piece Test Sim now includes `tools/import_scrydex.py`, an authenticated, paginated importer for the Scrydex One Piece API. It can import the full card endpoint (`/cards`) or a single expansion (for example, `/expansions/OP01/cards`). It preserves each raw provider record, full rules paragraphs, variants, images, printings, and SHA-256 checksums for fetched pages. Imported records are explicitly marked third-party/unverified; importing card text is not the same as verifying official rulings or implementing the effect engine.

### Requirements
- Python 3.10+
- `requests` (`python -m pip install requests`)
- A Scrydex API key and Team ID with permission to access the One Piece API. The API documentation shows these as `X-Api-Key` and `X-Team-ID` headers.

### Windows PowerShell
```powershell
$env:SCRYDEX_API_KEY = "YOUR_API_KEY"
$env:SCRYDEX_TEAM_ID = "YOUR_TEAM_ID"
python tools/import_scrydex.py --expansion OP01
# Full paginated database:
python tools/import_scrydex.py
```

### macOS / Linux
```bash
export SCRYDEX_API_KEY="YOUR_API_KEY"
export SCRYDEX_TEAM_ID="YOUR_TEAM_ID"
python3 tools/import_scrydex.py --expansion OP01
# Full paginated database:
python3 tools/import_scrydex.py
```

Output defaults to `data/scrydex_import/` and includes normalized CSV/JSONL, raw page responses, import status, errors, and source-page checksums. Start with OP01 as a small smoke test, inspect the report, then run the global endpoint. **Do not send API credentials in chat, put them in the source code, or commit them to a repository.** If Scrydex account access is not yet configured, the import will stop safely and explain which environment variables are missing.

### Important coverage distinction
Scrydex documents card fields including card ID, printed number, name, cost, power, attribute, type, colors, subtypes, printings, rarity, rules text, images and variants. It also documents pagination and a maximum page size of 250. See https://scrydex.com/docs/onepiece/cards and https://scrydex.com/docs/onepiece/api-reference. Scrydex is a data source, not the final authority for Bandai rulings. Official card text, errata, FAQs and rule interactions still need reconciliation, and each card effect must be separately marked as implemented and tested before we call it simulator-supported.

## Punk Records card-data import (offline)

The project includes `tools/import_punk_records.py` for importing a locally downloaded copy of [buhbbl/punk-records](https://github.com/buhbbl/punk-records), which provides generated card records derived from the official card website. This environment could not resolve GitHub to clone/download the live dataset, so no real card rows have been imported yet.

1. On GitHub, open the repository and choose **Code → Download ZIP**; extract it.
2. Run the importer against the extracted folder:
   - Windows: `python tools/import_punk_records.py --source "C:\\path\\to\\punk-records-main"`
   - macOS/Linux: `python3 tools/import_punk_records.py --source /path/to/punk-records-main`
3. Inspect `data/punk_records_import/punk_records_import_status.json` and the normalized JSONL/CSV files.

The importer supports `english/data/*.json` pack files and `english/cards/**/*.json` split card files. It records input checksums, duplicate IDs, source file provenance, and card effect/trigger text. It labels records unverified and does not claim that card effects are implemented or that current errata and judge rulings have been reconciled. Validate the dataset's release coverage before treating it as complete.

## Punk Records upstream data builder (helper added)

`tools/build_punk_records.py` is the upstream build script supplied for this project. It uses the `vega`/`vegapull` command-line program to fetch pack and card data, then writes language-specific JSON files and indexes. This script is a **data fetch/build step**, not a complete card-effect rules engine, and it does not itself import records into the simulator's runtime.

### Run it on a machine with internet access

1. Install Rust/Cargo and install `vegapull` as described by its project documentation. The script expects the executable to be named `vega` by default.
2. From this project directory, build English data first:

   ```bash
   python tools/build_punk_records.py --language english --out-dir ./punk-records --verbose
   ```

3. Then import the generated directory into the simulator's normalized database:

   ```bash
   python tools/import_punk_records.py --source ./punk-records
   ```

4. Review `data/punk_records_import/punk_records_import_status.json` and compare the unique card IDs and source coverage to the expected release/card list before treating the dataset as complete.

For Windows PowerShell, the same commands work with `python`; use a quoted absolute path for `--out-dir` or `--source` if the folders are elsewhere. To build every language, use `--language all`, but English-only is recommended for the initial test. Avoid `--overwrite` unless you intend to refresh existing pack files. The upstream script deletes its temporary `json` directory after generating the final files.

This environment does not currently have the `vega` executable installed and cannot access GitHub/network sources, so the upstream fetch has **not** been run here. Do not report card totals or coverage as verified until the generated dataset is actually inspected.

## Punk Records English data import (v11)

The uploaded Punk Records snapshot has now been imported into `data/punk_records_import/`.

See [`data/PUNK_RECORDS_DATA_AUDIT.md`](data/PUNK_RECORDS_DATA_AUDIT.md) for the measured audit. The import read 61 English pack JSON files with zero parse errors and found 4,910 unique card IDs (4,911 source rows because `OP07-091_p1` appears twice across pack files). The source manifest was generated on 2026-10-23.

This is card-data ingestion only. The import is **not** proof of complete coverage against the requested 5,603-card target, official errata reconciliation, judge verification, or automatic implementation of every card effect. The machine-readable status is `data/punk_records_import/punk_records_import_status.json`.


## Card database browser and repeatable data audit (v12)

- `card-database.html` provides search by card ID/name/effect text and filters by category/color against the imported English snapshot.
- `data/punk_records_import/cards.browser.json` is a compact unique-ID lookup index generated from the normalized JSONL. It uses the first source occurrence for duplicate IDs; the full JSONL preserves source rows and provenance.
- `tools/audit_punk_records.py` regenerates the browser index and a machine-readable audit report. Run `python tools/audit_punk_records.py` from this folder after refreshing/importing data.
- To use the browser locally, run `python -m http.server 8000` from this folder, then open `http://localhost:8000/card-database.html`. The data fetch may be blocked if the HTML is opened directly with `file://`.
- Tests include a repeatable snapshot audit and duplicate-ID behavior. Imported effect text is still **not** executable card logic; the browser does not make the simulator judge-accurate.

## Deck Builder & Legality Check (v13)

Open `deck-builder.html` using the same local server instructions as the card database. The builder reads `data/punk_records_import/cards.browser.json` directly and uses `src/deck-legality.mjs` for repeatable validation. Features include Leader selection, color-filtered card search, add/remove copy controls, main-deck count, card-number copy limit (parallel printings share the same limit), deck export to TXT/JSON, JSON import, and browser-local save.

### Loaded Global/English legality snapshot

`data/format-legality-global-2026-10-12.json` records the Bandai English/global banned/restricted notice effective October 12, 2026. It checks banned cards, restricted copy limits, and banned pairs alongside the core deck-construction rules. Official source: https://en.onepiece-cardgame.com/news/restriction.html

This is deliberately called a **deck-construction check**, not a certification of tournament legality. The imported card data does not reliably provide all block-icon, regional release, event-specific eligibility, errata, and printing metadata. Recheck Bandai's official notices before entering an event. The ban list can change after the snapshot date.

### v13 validation tests

- JavaScript: `node --test tests/*.test.mjs` — 51 tests passed at build time, including seven new deck legality tests.
- Python: `python -m pytest -q` — 15 tests passed at build time.

The new validator is separate from the legacy Brook heuristic simulation. It does not make the match engine judge-accurate and it does not implement card effects.

## Deck Builder → Brook Deck Lab bridge (v14 development update)

The Deck Lab page now accepts the `.json` export produced by `deck-builder.html`. The import bridge:

- resolves Leader and card IDs against `data/punk_records_import/cards.browser.json`;
- checks that the main deck has exactly 50 cards;
- runs `src/deck-legality.mjs` against `data/format-legality-global-2026-10-12.json` and refuses the import if the loaded checks report errors;
- currently accepts Brook Leader decks only, because the legacy comparison model assumes Brook's leader ability;
- lets the imported list replace the Original list for a comparison against Revised B.

**Simulation limitation:** this bridge does not make the old Monte Carlo model a rules-accurate simulator. For imported cards without a hand-authored role record, it infers coarse labels (search, recovery, engine, removal, finisher, event/value) from printed text and stats. Those labels are explicitly heuristic and unverified; card effects are not resolved according to the full rules. The displayed model proxy should not be treated as tournament win rate. Local legality checks are limited to the loaded snapshot and its implemented checks; event rules, block-icon legality, regional release timing, and official rulings still require separate verification.

To use it: run `python -m http.server 8000` in the project folder, build/check/export a deck as JSON from `deck-builder.html`, open `index.html`, and load that JSON under “Load a validated deck from Deck Builder”.




## v16 — Published opponent deck library (2026-10-23)

- Added five published OP17 tournament lists across Red/Black Sabo, Blue Rocks D. Xebec, Purple/Yellow Nico Robin, Purple Enel, and Black Monkey D. Luffy. Each includes 50 main-deck card IDs, a Leader ID, event/date/placement, source URL, and local validation summary. Green Dracule Mihawk is excluded per project constraint.
- Three source transcriptions have inferred quantities; these are explicitly flagged as provisional in `data/opponent-decks.json` and the library UI. Verify those card quantities at the linked source before relying on exact list composition.
- Added `opponent-deck-library.html` to review lists, inspect card IDs/names, validate custom pasted lists, and export a library JSON.
- Brook Deck Lab can select a published opponent list. Actual list composition is used to derive a transparent heuristic pressure/removal profile. The engine does **not** yet play each opponent card, resolve its printed effects, or model exact legal decisions; matchup outputs remain heuristic proxies.
- Data sources and transcription confidence are stored per deck in `data/opponent-decks.json`; see `data/opponent-decks-manifest.json`. The bundled legality snapshot is dated 2026-10-12 and may become stale.

### Run v16

1. Extract `One-Piece-Test-Sim-v16.zip`.
2. Open a terminal/command prompt in the extracted folder.
3. Run `python -m http.server 8000`.
4. Visit `http://localhost:8000/index.html` for Brook Deck Lab or `http://localhost:8000/opponent-deck-library.html` for the deck library.

### v16 verification boundary

The automated suite passes 63 JavaScript tests and 15 Python tests. All five included opponent lists contain 50 cards and pass the bundled database/restriction snapshot validation. Four card quantities across three lists are inferred from source-page category totals and are marked provisional; recheck them before treating the transcription as exact. See `data/meta_decks/OPPONENT_POOL_VALIDATION_REPORT.md`. Passing these checks does not certify judge accuracy or validate matchup win rates.


## v16 validation snapshot

- JavaScript tests: 62 passed.
- Python tests: 15 passed.
- All five opponent lists: 50 cards, all card IDs found in the imported database, and zero errors under the local legality snapshot effective 2026-10-12.
- Static inline JavaScript syntax checks and local HTTP file-serving checks passed. A full interactive browser run could not be completed in the build environment, so verify the interface after extracting the ZIP.


## v17 — card-by-card opponent turn policy (prototype)

Published tournament lists now run through `src/opponent-policy.mjs` rather than only a deck-statistics pressure profile. For each selected published list, the simulator shuffles its 50 main-deck IDs, deals an opening hand and Life, draws according to the current first/second approximation, adds DON!!, chooses affordable Characters/Stages/Events, and attacks using the selected Leader and board cards. The Brook side can spend imported counter cards to defend those attacks, and Brook attacks can be defended by counter cards in the opponent's simulated hand. Obvious removal/draw text is handled with conservative heuristics. The results view reports opponent plays, attacks, and counter cards spent.

The policy is **not judge-accurate**. It does not yet implement the full rules timing model, blockers, target selection, attack prohibitions, all triggers, conditional costs, all DON!! interactions, or reliable resolution of arbitrary printed text. Opponent and Brook turn ordering remains simplified, and several card effects are only recognized by text patterns. Results remain exploratory and must not be interpreted as tournament win-rate predictions.

### v17 verification

- `node --test tests/*.test.mjs`: 69 tests passed.
- `python -m pytest -q`: 15 tests passed.
- `node --check` on the simulator's module script and `src/opponent-policy.mjs`: passed.
- Added integration coverage that runs a real published tournament list through eight persistent opponent turns and checks card-zone conservation.

## Explicit card-effect runtime — v18

`src/card-effect-engine.mjs` introduces a small, explicit card-effect registry and connects it to the opponent policy's Character-play path. Only three simple `[On Play] Draw N card(s)` effects are registered: OP04-045 King, EB01-023 Edward Weevil, and OP13-041 Izo. The registry canonicalizes parallel printing suffixes and returns `unsupported` for all unregistered card/timing combinations rather than guessing from printed text. If a draw runs out of cards, the handler returns `deck-out-pending`; the heuristic adapter logs the required checkpoint, but full match termination is not yet integrated into that path.

See `CARD_EFFECT_RUNTIME_v18.md` and `CARD_EFFECT_COVERAGE_v18.csv`. These three handlers are unit-tested, but source card records remain unverified, so their status is `implemented-unverified`, not official/judge-verified. The browser matchup model remains heuristic and is not a reliable tournament win-rate simulator.

Validation for v18: `node --test tests/*.test.mjs` — 75 passed; `python -m pytest -q` — 15 passed. Passing tests establish only the tested behaviors, not full rules accuracy.

## v19 rules-kernel update (2026-10-23)

This build adds explicit generic DON!! attachment and temporary power modifier helpers in `src/rules-runtime.mjs`:

- `attachDon(state, playerIndex, targetRef, count)` spends active DON!! and attaches it to the player's Leader or a Character during Main Phase.
- `applyPowerModifier(state, playerIndex, targetRef, amount, duration, operation)` attaches a supported power modifier to a legal friendly Leader/Character.
- `currentEntityPower(entity)` calculates base power + modifiers + 1000 per attached DON!! for use in the battle engine.
- `endTurn(state)` returns attached DON!! to the rested DON!! area and clears `until-end-of-turn` power modifiers.

The runtime validates Main Phase, turn ownership, active DON!! count, target ownership, modifier operation, and numeric values. These helpers are generic rule primitives; they do not imply that every card with DON!! or power text has been implemented. Card-specific costs, target filters, timing, replacement effects, and effect chains still require explicit handlers. Unsupported effects remain unsupported.

Validation run in this build: `node --test tests/*.test.mjs` (78 passed) and `python -m pytest -q` (15 passed). These tests are regression checks for implemented behavior, not proof of complete tournament/judge accuracy.


## v20 update — explicit target filtering and removal safeguards

The effect DSL now provides structured Character target filtering and explicit-choice `ko` / `return-to-hand` actions with cost, power, rested, owner, and identity constraints. It checks known runtime protection flags and rejects ambiguous or illegal target choices. This is a generic rules primitive, not universal support for all card-specific removal effects or automatic printed-text interpretation. See `POWER_AND_DON_RUNTIME_v20.md`.

## v21 — battle/effect power integration

- Battle calculations now use the shared `currentEntityPower` helper, so DON!! and power modifiers are each counted exactly once.
- The battle engine no longer adds attached DON!! a second time after calculating current power.
- Effect DSL power modifiers now populate the canonical `powerModifiers` data consumed by battle calculations, while retaining a descriptive modifier ledger for inspection.
- Added regression tests for exact DON!! power and DSL-to-battle integration.
- This remains an incremental rules prototype; unsupported printed card effects are not inferred.

## v22 — Unified action facade (experimental)

`src/unified-game-engine.mjs` provides a single action entry point for the currently supported runtime actions: turn phases, draw, DON!! payment/attachment, power modifiers, queued effects, compiled card effects, battle steps, blockers, counters, and battle resolution. `executeUnifiedAction(state, action, context)` snapshots the canonical runtime state and restores it if an action throws a validation/runtime error. Legitimate game outcomes such as deck-out remain committed. The compiled-card-effect path now routes supported draw effects through `drawCards`, so they use the shared rule checkpoint rather than the simplified opponent-policy zone adapter.

The legacy `rules-engine.mjs` game factory, turn-start shorthand, DON!! payment, and registered effect handlers now use the canonical runtime state/handler registry; battle procedure already uses the shared battle engine. The browser pages and heuristic opponent policy are not yet fully wired to the unified action facade, and the facade does not automatically parse printed text or implement every card effect. Unsupported actions/effects remain unsupported. Run validation from the project root with `npm test` (or `node --test tests/*.test.mjs`) and `python -m pytest -q`.


### v22 validation

- JavaScript: `node --test tests/*.test.mjs` — 95 passed.
- Python: `python -m pytest -q` — 15 passed.
- `node --check` on all source and test `.mjs` files — passed.
- `UNIFIED_ENGINE_AUDIT_v22.md` records the integration boundary and remaining work.


## v23 — Reproducible Match Runner

Version 0.9.0 adds `src/match-runner.mjs`, deterministic seeded setup and bounded match execution, series summaries, and a unified `play-character` action. The starter policy is intentionally basic: greedy Character plays and Leader pressure using supported battle steps. It records unsupported On Play effects rather than guessing their behavior.

Run `npm test` for the full JavaScript suite or `npm run test:match-runner` for focused integration tests. The runner is not yet a full judge-accurate simulator and its synthetic fixture win rates must not be treated as competitive matchup results.
