
# v20 — explicit target filters and field-removal safeguards

The effect DSL now exposes `getLegalCharacterTargets(state, controller, filters)` for UI/AI target-choice generation. Supported structured filters are `player: 'own' | 'opponent' | 'any'`, `costAtMost`, `costAtLeast`, `powerAtMost`, `powerAtLeast`, `rested`, `name`, and `cardId`. Cost is read from `cost` or `printedCost`; power uses the entity's `power` field. This is structured-field evaluation, not printed-text parsing.

`ko` and `return-to-hand` accept explicit `targetId` or `targetIds`, optional `player` and target filters, and `maxTargets`. They reject missing/duplicate/excess choices instead of silently selecting a target. KO respects `cannotBeKO`, `cannotBeKoByEffect`, and `protection.koByEffect`; return-to-hand has distinct checks for `cannotBeReturnedToHand`, `cannotBeRemovedFromField`, and corresponding `protection` flags. These flags are runtime conventions and must be populated by a correctly compiled card effect or state setup; this release does not infer protection from arbitrary printed text.
