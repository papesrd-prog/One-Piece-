# v19 DON!! and Power Runtime

## Implemented generic primitives

- Active DON!! can be attached to the current turn player's own Leader or Character only during Main Phase.
- Attachment rejects zero/negative counts, insufficient active DON!!, invalid targets, and opponent-owned targets.
- Attached DON!! contributes +1000 power per attached card through `currentEntityPower`.
- `applyPowerModifier` supports explicit additive and set operations with a duration label.
- End-of-turn cleanup returns attached DON!! to the rested DON!! pool and clears `until-end-of-turn` modifiers.
- Target IDs are checked against the actual friendly Leader/Character, rather than treating any `type: leader` reference as the friendly Leader.

## Not yet complete

- Generic modifiers are not a substitute for a card's printed effect handler.
- Turn-duration timing is only implemented for the explicit `until-end-of-turn` and existing `until-start-of-your-next-turn` labels.
- Card-specific target legality, immunity/protection, costs, optional choices, simultaneous effects, replacement effects, and triggered chains need dedicated implementations.
- The whole simulator is not judge-accurate yet; don't treat heuristic matchup outputs as tournament win-rate estimates.

## Test coverage added

- Active DON!! spent on attachment and power total calculated.
- Insufficient DON!! and opponent target rejected.
- End-turn cleanup rests attached DON!! and removes end-of-turn power modifiers.
