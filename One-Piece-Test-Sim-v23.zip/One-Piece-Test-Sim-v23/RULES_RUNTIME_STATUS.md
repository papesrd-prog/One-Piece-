# Rules runtime status — 2026-10-23

## Reference baseline
- One Piece Card Game Comprehensive Rules revision 1.2.1, dated 2026-08-28 (official text mirrored for searchability): https://onepiece.gg/rules/comprehensive-rules/
- Official English rules and FAQ index: https://en.onepiece-cardgame.com/rules/
- Official English card list: https://en.onepiece-cardgame.com/cardlist/

## Added in this update
- Explicit phase progression: Refresh → Draw → DON!! → Main → End.
- First-player first-turn draw exception and DON!! gain timing.
- Turn-end / turn-player switching.
- Deck-out on attempted draw.
- Effect queue with turn-player priority for simultaneous timing windows.
- Registered effect-handler requirement: unsupported effects fail closed rather than being guessed.
- Basic modifier model for power/cost/life/counter with negative power preserved and non-power values floored at zero.
- Life damage helper with optional Trigger resolution and Banish bypassing Trigger; Double Attack processes Life cards one at a time.
- Once-per-turn flag helper.
- Strict deck validator that rejects unknown card IDs instead of silently treating legality as valid.

## Validation
`npm test` — current suite: 44 tests passed (2026-10-23 package update).

## Not yet implemented / not certified
- Complete card database import and card-by-card text verification.
- Full battle flow including every card-specific effect, Event Counter costs/effects, all replacement effects, and complete rule processing remains unfinished. Selected generic battle timing and legality are now covered by `src/battle-engine.mjs`.
- Generic parser/semantic compiler for every printed card text; each effect must be implemented and tested, not guessed from tags.
- All keyword effects and continuous/temporary effects, including exact duration interactions and source/target selection.
- All official FAQs, card-specific Q&As, errata, bans/restrictions, and set-specific rulings reconciled into executable tests.
- Judge-accurate handling of every simultaneous trigger, nested effect, replacement effect, hidden information, and edge case.

This module is an additive experimental kernel, not a complete or flawless simulator. Do not market it as judge-accurate until the outstanding checklist is closed and verified against official documents and regression fixtures.

## Battle/rule-processing hardening update (2026-10-23)

Added `src/rule-processing.mjs` as a central defeat checkpoint and `src/battle-engine.mjs` as an explicit attack/block/counter/damage/end state machine. The legacy `rules-engine.mjs` battle exports now delegate to the new battle engine.

Covered by automated tests: per-player first-turn attack restriction; legal rested-character targets; equal-power battle success; one Blocker per battle and redirect; Unblockable blocking restriction; counter-power addition; Double Attack Life processing one card at a time; Banish bypassing Trigger/hand; Trigger resolution callback default Trigger-to-Trash handling; Banish bypassing Trigger/hand; battle K.O.; immediate deck-out after drawing the final deck card; simultaneous defeat as a draw; and fail-closed unsupported effects.

Known limits remain: card text is not automatically interpreted; callbacks must implement card-specific attack/block/trigger/counter effects; replacement effects and the complete keyword catalog are not implemented; no exhaustive official interaction corpus has been run. Passing tests demonstrate these tested paths only, not full judge accuracy.


## 2026-10-23 rule-case update

`tests/official-rule-cases.test.mjs` adds rule-section-linked regression cases. These are locally authored tests based on the rules text, not official rulings. The engine now validates that the attacker is the current turn player, supports explicit effect permission to attack active Characters, and rejects cards marked with generic attack-prohibition flags. Latest test run: 44/44 Node tests and 8/8 Python tests passed.
