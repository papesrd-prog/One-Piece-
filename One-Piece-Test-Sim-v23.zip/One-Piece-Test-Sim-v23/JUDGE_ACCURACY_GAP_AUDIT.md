# Judge-accuracy gap audit — One Piece Test Sim

Audit date: 2026-10-23

## Current conclusion

Brook Lab is **not judge-accurate yet**. The existing code is a prototype core plus an explicit effect DSL. It can model selected state changes, but it does not implement all rules, all keyword timing, all official FAQs/errata, or every printed card effect. The local runtime cannot currently fetch live data: DNS resolution failed for `gumgum.gg`, `optcgapi.com`, and Bandai's English site. The import pipeline must be run from a machine with working internet access.

## Authoritative reference hierarchy

1. Bandai official Comprehensive Rules, official rule manual, official FAQ and Q&A, official errata and ban/restricted notices.
2. Bandai official English card list for printed English card fields and text.
3. Gumgum.gg and Limitless as independent card-text/product cross-checks.
4. Structured third-party APIs only as import accelerators, never as proof of completeness.

## Coverage gate

No card or rule area may be marked complete merely because code compiles. Each implementation must have: (a) rule/card source and version, (b) normalized effect representation, (c) target/choice/cost/timing semantics, (d) positive test, (e) negative/illegal-action test, (f) interaction test, and (g) regression fixture. Unknown effects must block deterministic simulation or be reported as unsupported.

## Critical unresolved areas

- Complete English card database and printing inventory: no records imported in this environment.
- Full battle: blocker activation and target redirection, Unblockable, Counter cards and events, power comparison, battle-end windows, and all damage/Trigger/Double Attack/Banish interactions.
- Unified rule-processing checkpoints: deck-out and zero-Life defeat timing, simultaneous losses, and effects that win/lose.
- All keyword effects and card-specific exceptions.
- Full effect stack/queue semantics, nested activation, conditions, costs, replacement/prevention effects, source leaving play, and zone changes.
- Official FAQ, Q&A, errata, and ban/restricted updates through the current date.
- Effect compiler and per-card test coverage for every printed English effect.

## Why no honest completion estimate is provided

There is no imported dataset to count, no working network fetch in this runtime, and the number of effects/interactions is not known until the card pool is reconciled. Any claim of a complete simulator or fixed finish time would be unsupported.
