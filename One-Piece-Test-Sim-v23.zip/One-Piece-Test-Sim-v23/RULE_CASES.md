# One Piece Test Sim — rule-section regression cases

**Baseline:** Comprehensive Rules revision 1.2.1 (2026-08-28), cross-checked against the searchable text at https://onepiece.gg/rules/comprehensive-rules/. Bandai's published Comprehensive Rules PDF is available at https://en.onepiece-cardgame.com/pdf/rule_comprehensive.pdf?20250221=. The searchable mirror is useful for section navigation; the latest Bandai-published document and official FAQs/errata take precedence.

These are **engine regression tests derived from rules text**, not official Bandai ruling examples and not certification by the Bandai Judge Program.

| Test case | Rules area | Expected engine behavior | Automated test |
|---|---|---|---|
| Only turn player declares battle | CR 6, turn structure | Reject out-of-turn attack before changing state | `official-rule-cases.test.mjs` |
| First-turn battle restriction | CR 6-5-6-1 | Reject battle on that player's first turn | `official-rule-cases.test.mjs` |
| Active Character target restriction | CR 7, Attack Step | Active Character is illegal unless an effect explicitly grants permission | `official-rule-cases.test.mjs` |
| Attack-prohibition effect | CR 1-3 and CR 7 | Reject attack without resting attacker or opening battle | `official-rule-cases.test.mjs` |
| Equal-power comparison | CR 7 | Attack succeeds when attack power equals defending power | `official-rule-cases.test.mjs` |
| Higher defending power | CR 7 | Attack does not damage Life or K.O. target by battle | `official-rule-cases.test.mjs` |
| Blocker redirection and limit | CR 7-1-2 | Rest legal Blocker, redirect target, reject a second Blocker that battle | `official-rule-cases.test.mjs` |
| Counter power | CR 7-1-3 | Add counter power before comparison | `official-rule-cases.test.mjs` |
| Deck-out checkpoint | CR 1-2 and CR 9 | Empty deck causes defeat at rule processing | `official-rule-cases.test.mjs` |
| Simultaneous defeat | CR 1-2 and CR 9 | Both players lose at same checkpoint; result is draw | `official-rule-cases.test.mjs` |
| Banish | CR 4-6 | Damaged Life goes to Trash and Trigger is not resolved | `official-rule-cases.test.mjs` |

## Important limitations

- A case passing proves only that the coded fixture behaves as expected. It does not prove all related rules, interactions, or printed card effects are correct.
- The test suite does not yet ingest the complete official FAQ/Q&A set, errata history, current banned/restricted list, or every card's text.
- Callback-based card effects are not automatically interpreted from printed card text.
- Do not describe this project as 100% judge-accurate until official sources have been versioned, every supported card effect has executable semantics, unsupported effects are blocked, and the full regression/interactions suite passes.
