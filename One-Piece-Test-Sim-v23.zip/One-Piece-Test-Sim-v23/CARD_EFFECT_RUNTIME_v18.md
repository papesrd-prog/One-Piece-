# Card Effect Runtime — v18

## Goal
Establish an explicit, fail-closed card-effect execution boundary and connect it to opponent character plays. This is a small foundation, not broad card coverage.

## Compiled handlers
The `src/card-effect-engine.mjs` registry contains only three manually registered effects:

- OP04-045 King — `[On Play] Draw 1 card.`
- EB01-023 Edward Weevil — `[On Play] Draw 1 card.`
- OP13-041 Izo — `[On Play] Draw 2 cards.`

Parallel printing suffixes such as `_p2` are normalized to the canonical card number. `resolveCompiledCardEffect` moves cards from the player's deck to hand and returns `deck-out-pending` when a draw attempts to continue with an empty deck. The caller must then run the relevant game-state checkpoint; the heuristic opponent adapter logs that a checkpoint is required but does not implement full game termination itself.

## Safety properties
- No regex-based effect inference in this registry.
- Unregistered card/timing combinations return `unsupported`.
- Database source verification and engine implementation status remain distinct.
- The registry is intentionally small and visible in `CARD_EFFECT_COVERAGE_v18.csv`.

## Current limitations
- Only simple On Play draw effects are compiled.
- No general payment/cost, target selection, optional choices, replacement effects, Trigger effects, simultaneous timing, conditional clauses, search/stack manipulation, or arbitrary effect chains are implemented here.
- The opponent policy calls the adapter after a Character is played. The existing browser simulator is still a heuristic model, not a complete rules-driven game loop.
- The three entries are marked `implemented-unverified` because their behavior is unit-tested but the imported source records have not been formally reconciled against every official card printing/erratum.

## Tests
Run `node --test tests/*.test.mjs`. The tests verify parallel-printing normalization, exact draw behavior, unknown-effect fail-closed behavior, pending deck-out signaling, and integration with the heuristic opponent policy.
