# Brook Lab — English card database fallback

This package adds a reproducible third-party fallback importer to the existing Brook Lab prototype and experimental rules core.

## Run on a computer with internet access

**Windows:** double-click `tools/run_refresh_windows.bat`.

**macOS/Linux:** run `bash tools/run_refresh_mac_linux.sh` from this folder.

Or manually:

```bash
python -m pip install -r tools/requirements.txt
python tools/refresh_english_database.py
```

The importer uses OPTCG API endpoints documented at https://www.optcgapi.com/documentation for sets, set cards, starter cards, promos and DON!! cards. It also fetches the Limitless One Piece card/set index at https://onepiece.limitlesstcg.com/cards/ for a separate set-list cross-check. It intentionally uses a low request rate and does not request every card one-by-one.

## Output files

- `data/database_import/cards.normalized.jsonl` — one normalized record per imported source record.
- `data/database_import/cards.normalized.csv` — spreadsheet-friendly copy.
- `data/database_import/raw/` — unmodified source snapshots.
- `data/database_import/database-status.json` — counts, endpoint failures and checksums.
- `data/database_import/set_inventory.csv` — sets represented in imported card records.
- `data/database_import/duplicate_id_report.json` — repeated card-ID groups to review, not automatically assumed to be alt arts.
- `data/database_import/missing_effect_text_report.json` — records lacking both effect and trigger text.
- `data/database_import/limitless_set_index.json` — set links captured from Limitless.
- `reports/DATABASE_COVERAGE_REPORT.md` — human-readable audit and known gaps.

## Critical honesty / scope

I could not download the remote datasets inside the current ChatGPT execution environment because DNS/network access fails there. Therefore this delivered package contains the importer and tests, not the full live card database. Run it on a normal internet-connected computer to populate the data files.

The OPTCG API homepage says its dataset covers OP-01 through OP-15 plus starter decks; it is not enough by itself to prove coverage of newer sets, all promos, all reprints/parallel arts, and errata. Limitless' set index shows later products, but the importer only uses that index for coverage cross-checking; it does not falsely claim the index alone contains every card effect. All imported records are marked `third_party_unverified`; all effects are marked `not_implemented`. The existing rules engine is still experimental and does not resolve all printed effects.

For simulator use, do not promote records to verified or enable an effect merely because text was imported. Reconcile names/text/stats against the official English card list, capture product/printing variants separately, then add each effect handler with explicit tests and official rule/errata references.
