# Opponent Policy Status — v17

## Implemented
- Uses the selected published list's exact main-deck card IDs.
- Shuffles/deals opening hand and Life; maintains a persistent opponent deck/hand/Life/trash/board.
- Adds DON!! turn by turn and chooses affordable Character/Stage/Event plays using cost, power, and basic effect-text signals.
- Models Leader/eligible Character attacks against Brook's Life and hand.
- Models counter cards being spent from either side's hand and moved to Trash.
- Models Brook's attacks against the opponent's Life and counter hand.
- Recognizes only obvious removal/draw text patterns, with approximate target/cost selection.
- Reports average opponent plays, attacks, and counter cards spent per game.

## Not implemented / not trustworthy yet
- Full Comprehensive Rules timing, exact turn sequence when Brook goes second, Blockers, Rush legality beyond a text hint, attack restrictions, active/rested target legality, triggers, replacement/prevention effects, DON!! attachment, and arbitrary conditional costs.
- Full card-specific effects or exact opponent AI. The greedy policy is deterministic for a seed but not strategic tournament play.
- The imported Original/Revised Brook lists still use a small hand-maintained card-role map for some simulation decisions.
- Do not use the win-proxy output as a tournament win-rate estimate.
