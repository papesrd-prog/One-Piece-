# v23 — Reproducible Match Runner

## Added

- `src/match-runner.mjs` creates a canonical runtime state from two leaders and deck lists, shuffles/deals using a seed, and executes a bounded match through `executeUnifiedAction`.
- Added a `play-character` action to the unified action facade. It validates phase, turn ownership, card identity/data, category, integer cost, active DON!!, and Character-area capacity before changing state.
- Basic deterministic policy plays affordable Characters greedily and sends eligible Leaders/Characters at the opposing Leader. Battle steps route through the shared battle engine.
- Explicitly compiled On Play effects are called through the shared effect path. Unsupported effects are reported in `unsupportedEffects`, not inferred from arbitrary text.
- `runMatchSeries` varies seeds, alternates first player, and reports wins, draws, turn limits, and invalid matches with sample size.

## Scope and limitations

This is an integration harness for the actions implemented in the current prototype, not a complete One Piece TCG simulator. It currently does not implement general Event play, full counter-card selection, arbitrary printed effects, all keyword rules, complete timing windows, or a tournament-grade opponent policy. Unsupported On Play effects are reported and may affect match outcomes. Do not interpret synthetic fixture results as Brook-vs-meta performance.

The current runtime's rule-processing behavior and other known gaps are documented in `JUDGE_ACCURACY_GAP_AUDIT.md` and `RULES_COVERAGE_MATRIX.csv`.
