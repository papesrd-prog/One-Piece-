import { processRuleCheckpoint } from './rule-processing.mjs';
/**
 * Explicit effect DSL for authoring and regression-testing card effects.
 * This is NOT an automatic parser for printed card text. Card records must be
 * manually/externally compiled to these instructions and pass card-specific tests.
 */
export class EffectDslError extends Error {
  constructor(code, message) { super(message); this.name = 'EffectDslError'; this.code = code; }
}
const fail = (code, message) => { throw new EffectDslError(code, message); };
const assert = (ok, code, message) => { if (!ok) fail(code, message); };
const getPlayer = (state, index) => {
  assert(Number.isInteger(index) && index >= 0 && index < state.players.length, 'BAD_PLAYER', `Invalid player index: ${index}`);
  return state.players[index];
};
const findCharacter = (state, controller, id, player = 'any') => {
  assert(typeof id === 'string' && id.length > 0, 'BAD_TARGET_ID', 'A target instance ID is required.');
  const expectedIndex = player === 'own' ? controller : player === 'opponent' ? 1 - controller : null;
  const matches = state.players
    .filter((p, index) => expectedIndex === null || index === expectedIndex)
    .map(owner => ({ owner, character: owner.characters.find(c => (c.instanceId ?? c.id) === id) }))
    .find(item => item.character);
  assert(matches, 'TARGET_NOT_FOUND', `Character target '${id}' was not found in the permitted field.`);
  return matches;
};

/** Return currently legal Character targets for a compiled effect. This only
 * evaluates structured fields; it never guesses from printed effect text. */
export function getLegalCharacterTargets(state, controller, filters = {}) {
  getPlayer(state, controller);
  const targetPlayer = filters.player ?? 'any';
  assert(['own', 'opponent', 'any'].includes(targetPlayer), 'BAD_TARGET_PLAYER', `Unsupported target player '${targetPlayer}'.`);
  const expectedIndex = targetPlayer === 'own' ? controller : targetPlayer === 'opponent' ? 1 - controller : null;
  return state.players.flatMap((owner, ownerIndex) => {
    if (expectedIndex !== null && ownerIndex !== expectedIndex) return [];
    return owner.characters
      .filter(character => matchesTargetFilters(character, filters))
      .map(character => ({ ownerIndex, ownerId: owner.id, instanceId: character.instanceId ?? character.id,
        cardId: cardId(character), cost: Number(character.cost ?? character.printedCost ?? 0),
        power: Number(character.power ?? 0), rested: Boolean(character.rested) }));
  });
}

function matchesTargetFilters(character, filters) {
  const cost = Number(character.cost ?? character.printedCost ?? 0);
  const power = Number(character.power ?? 0);
  if (filters.costAtMost !== undefined && cost > finite(filters.costAtMost, 'costAtMost')) return false;
  if (filters.costAtLeast !== undefined && cost < finite(filters.costAtLeast, 'costAtLeast')) return false;
  if (filters.powerAtMost !== undefined && power > finite(filters.powerAtMost, 'powerAtMost')) return false;
  if (filters.powerAtLeast !== undefined && power < finite(filters.powerAtLeast, 'powerAtLeast')) return false;
  if (filters.rested !== undefined && Boolean(character.rested) !== Boolean(filters.rested)) return false;
  if (filters.name !== undefined && character.name !== filters.name) return false;
  if (filters.cardId !== undefined && cardId(character) !== filters.cardId) return false;
  return true;
}

function assertTargetMatches(character, action) {
  assert(matchesTargetFilters(character, action), 'ILLEGAL_TARGET', 'The chosen Character does not meet this effect’s target restrictions.');
}

function isProtectedFromKo(character) {
  return Boolean(character.cannotBeKO || character.cannotBeKoByEffect || character.protection?.koByEffect === true);
}
function isProtectedFromReturn(character) {
  return Boolean(character.cannotBeReturnedToHand || character.cannotBeRemovedFromField || character.protection?.returnToHand === true || character.protection?.removedByEffect === true);
}

export function resolveEffectDsl(state, program, context = {}) {
  assert(program && typeof program === 'object', 'BAD_PROGRAM', 'Effect program must be an object.');
  assert(Array.isArray(program.actions), 'BAD_ACTIONS', 'Effect program must contain an actions array.');
  const controller = context.controller ?? state.turnPlayer ?? 0;
  getPlayer(state, controller);
  const results = [];
  for (const action of program.actions) {
    results.push(runAction(state, action, { ...context, controller }));
    const checkpoint = processRuleCheckpoint(state);
    if (checkpoint.status === 'win' || checkpoint.status === 'draw') break;
  }
  state.log?.push({ type: 'dsl-effect-resolved', controller, actionCount: program.actions.length, effectId: context.effectId ?? null });
  return { resolved: true, results };
}

function runAction(state, action, ctx) {
  assert(action && typeof action.op === 'string', 'BAD_ACTION', 'Each action needs an op string.');
  const own = getPlayer(state, ctx.controller);
  const opponent = getPlayer(state, 1 - ctx.controller);
  switch (action.op) {
    case 'draw': {
      const who = action.player === 'opponent' ? opponent : own;
      const count = integer(action.count ?? 1, 'draw count');
      const drawn = [];
      for (let i = 0; i < count; i++) {
        if (!who.deck.length) {
          const checkpoint = processRuleCheckpoint(state);
          return { op: action.op, drawn: drawn.length, deckOutPending: true, checkpoint };
        }
        drawn.push(who.deck.shift()); who.hand.push(drawn[drawn.length - 1]);
        const checkpoint = processRuleCheckpoint(state);
        if (checkpoint.status === 'win' || checkpoint.status === 'draw') {
          return { op: action.op, drawn: drawn.length, deckOutPending: true, checkpoint };
        }
      }
      return { op: action.op, drawn: drawn.length };
    }
    case 'rest':
    case 'set-active': {
      const { character } = findCharacter(state, ctx.controller, action.targetId);
      character.rested = action.op === 'rest';
      return { op: action.op, targetId: action.targetId };
    }
    case 'ko': {
      const ids = action.targetIds ?? (action.targetId !== undefined ? [action.targetId] : null);
      assert(Array.isArray(ids) && ids.length > 0, 'CHOICE_REQUIRED', 'KO requires explicit targetId or targetIds; the simulator will not choose targets implicitly.');
      assert(new Set(ids).size === ids.length, 'DUPLICATE_TARGET', 'A Character cannot be selected more than once for the same KO action.');
      const maxTargets = integer(action.maxTargets ?? ids.length, 'maxTargets');
      assert(ids.length <= maxTargets, 'TOO_MANY_TARGETS', `This effect may select at most ${maxTargets} target(s).`);
      const selected = ids.map(id => {
        const match = findCharacter(state, ctx.controller, id, action.player ?? 'any');
        assertTargetMatches(match.character, action);
        assert(!isProtectedFromKo(match.character), 'KO_PROHIBITED', `Character '${id}' is protected from being K.O.'d by an effect.`);
        return { id, ...match };
      });
      const moved = [];
      for (const { id, owner, character } of selected) {
        owner.characters.splice(owner.characters.indexOf(character), 1);
        owner.trash.push(character.card ?? character.cardId ?? character);
        moved.push(id);
        state.log?.push({ type: 'ko', player: owner.id, targetId: id, cause: 'effect' });
      }
      return { op: action.op, targetIds: moved, moved: moved.length };
    }
    case 'power-modifier': {
      const target = action.target === 'leader' ? own.leader : findCharacter(state, ctx.controller, action.targetId).character;
      assert(target, 'TARGET_NOT_FOUND', 'Power modifier target was not found.');
      const amount = finite(action.amount, 'power amount');
      target.powerModifiers ??= [];
      const duration = action.duration ?? 'until-end-of-turn';
      target.powerModifiers.push({ amount, operation: action.operation === 'set' ? 'set' : 'add', duration,
        createdTurn: own.turnCount ?? 0, ownerIndex: ctx.controller, sourceEffect: ctx.effectId ?? null });
      // Retain the descriptive ledger for UI/debugging while battle calculations
      // consume the canonical powerModifiers array.
      target.modifiers ??= [];
      target.modifiers.push({ stat: 'power', amount, duration, sourceEffect: ctx.effectId ?? null });
      return { op: action.op, amount, duration };
    }
    case 'life-to-hand': {
      const who = action.player === 'opponent' ? opponent : own;
      const count = Math.min(integer(action.count ?? 1, 'life count'), who.life.length);
      const moved = who.life.splice(0, count); who.hand.push(...moved);
      return { op: action.op, moved: moved.length };
    }
    case 'trash-from-hand': {
      const who = action.player === 'opponent' ? opponent : own;
      const ids = action.cardIds;
      assert(Array.isArray(ids), 'CHOICE_REQUIRED', 'trash-from-hand requires explicit cardIds chosen by the player/AI.');
      const trashed = [];
      for (const id of ids) {
        const idx = who.hand.findIndex(c => cardId(c) === id);
        if (idx < 0) continue;
        trashed.push(who.hand.splice(idx, 1)[0]);
      }
      who.trash.push(...trashed);
      return { op: action.op, trashed: trashed.length };
    }
    case 'attach-don': {
      const count = integer(action.count ?? 1, 'DON!! count');
      assert(own.donActive >= count, 'INSUFFICIENT_DON', `Need ${count} active DON!! to attach.`);
      const target = action.target === 'leader' ? own.leader : findCharacter(state, ctx.controller, action.targetId).character;
      assert(target, 'TARGET_NOT_FOUND', 'DON!! attachment target was not found.');
      own.donActive -= count;
      own.donAttached ??= [];
      own.donAttached.push({ targetId: target.instanceId ?? target.id, count, ownerIndex: ctx.controller });
      target.attachedDon = (target.attachedDon ?? 0) + count;
      return { op: action.op, count, targetId: target.instanceId ?? target.id };
    }
    case 'return-to-hand': {
      const ids = action.targetIds ?? (action.targetId !== undefined ? [action.targetId] : null);
      assert(Array.isArray(ids) && ids.length > 0, 'CHOICE_REQUIRED', 'Returning a Character requires explicit targetId or targetIds.');
      assert(new Set(ids).size === ids.length, 'DUPLICATE_TARGET', 'A Character cannot be selected more than once for the same return action.');
      const maxTargets = integer(action.maxTargets ?? ids.length, 'maxTargets');
      assert(ids.length <= maxTargets, 'TOO_MANY_TARGETS', `This effect may select at most ${maxTargets} target(s).`);
      const selected = ids.map(id => {
        const match = findCharacter(state, ctx.controller, id, action.player ?? 'any');
        assertTargetMatches(match.character, action);
        assert(!isProtectedFromReturn(match.character), 'RETURN_PROHIBITED', `Character '${id}' is protected from being returned to hand by an effect.`);
        return { id, ...match };
      });
      const moved = [];
      for (const { id, owner, character } of selected) {
        owner.characters.splice(owner.characters.indexOf(character), 1);
        owner.hand.push(character.card ?? character.cardId ?? character);
        moved.push(id);
        state.log?.push({ type: 'return-to-hand', player: owner.id, targetId: id, cause: 'effect' });
      }
      return { op: action.op, targetIds: moved, moved: moved.length };
    }
    case 'if': {
      assert(typeof action.condition === 'string', 'BAD_CONDITION', 'if action needs a named condition.');
      const condition = ctx.conditions?.[action.condition];
      assert(typeof condition === 'function', 'UNSUPPORTED_CONDITION', `Condition '${action.condition}' is not registered.`);
      const branch = condition(state, action, ctx) ? action.then : (action.else ?? []);
      assert(Array.isArray(branch), 'BAD_BRANCH', 'if branches must be action arrays.');
      return { op: action.op, results: branch.map(a => runAction(state, a, ctx)) };
    }
    default: fail('UNSUPPORTED_ACTION', `Effect DSL action '${action.op}' is not implemented.`);
  }
}
function integer(v, label) { assert(Number.isInteger(v) && v >= 0, 'BAD_NUMBER', `${label} must be a non-negative integer.`); return v; }
function finite(v, label) { assert(Number.isFinite(v), 'BAD_NUMBER', `${label} must be finite.`); return v; }
function cardId(card) { return typeof card === 'string' ? card : (card?.cardId ?? card?.id ?? card?.number); }
