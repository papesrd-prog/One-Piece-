import { drawCards } from './rules-runtime.mjs';

/**
 * Explicitly compiled card-effect handlers. This registry intentionally covers
 * only exact, manually reviewed text patterns; it does not guess from arbitrary
 * printed text. Unsupported effects are returned as unsupported, never ignored
 * silently or treated as implemented.
 */
const EFFECTS = new Map([
  ['OP04-045', { timing: 'on-play', handler: 'draw', count: 1, reviewedText: '[On Play] Draw 1 card.' }],
  ['EB01-023', { timing: 'on-play', handler: 'draw', count: 1, reviewedText: '[On Play] Draw 1 card.' }],
  ['OP13-041', { timing: 'on-play', handler: 'draw', count: 2, reviewedText: '[On Play] Draw 2 cards.' }],
]);

export function canonicalCardId(id) {
  return String(id ?? '').trim().replace(/_p\d+$/i, '');
}

export function getCompiledEffect(cardId, timing) {
  const effect = EFFECTS.get(canonicalCardId(cardId));
  return effect && (!timing || effect.timing === timing) ? { ...effect, cardId: canonicalCardId(cardId) } : null;
}

export function effectSupportStatus(cardId, timing) {
  const effect = getCompiledEffect(cardId, timing);
  return effect
    ? { status: 'implemented', effect }
    : { status: 'unsupported', reason: 'No explicitly compiled handler for this card ID and timing.' };
}

/**
 * Resolve an explicitly registered effect against a simple player-zone adapter
 * (the same shape used by the heuristic opponent policy). The caller is
 * responsible for running game-over/rule checkpoints after deck-out.
 */
export function resolveCompiledCardEffect({ cardId, timing, player, log = [] }) {
  const effect = getCompiledEffect(cardId, timing);
  if (!effect) return { resolved: false, status: 'unsupported', cardId: canonicalCardId(cardId), timing };
  if (!player || !Array.isArray(player.deck) || !Array.isArray(player.hand)) {
    throw new TypeError('Supported card effects require player.deck and player.hand arrays.');
  }
  if (effect.handler === 'draw') {
    let drawn = 0;
    for (let i = 0; i < effect.count; i++) {
      if (!player.deck.length) {
        log.push(`Effect ${effect.cardId}: deck-out checkpoint required after drawing ${drawn}/${effect.count}.`);
        return { resolved: true, status: 'deck-out-pending', effectId: effect.cardId, drawn, requested: effect.count };
      }
      player.hand.push(player.deck.shift());
      drawn++;
    }
    log.push(`Effect ${effect.cardId}: draw ${drawn} card${drawn === 1 ? '' : 's'}.`);
    return { resolved: true, status: 'resolved', effectId: effect.cardId, drawn, requested: effect.count };
  }
  return { resolved: false, status: 'unsupported', cardId: effect.cardId, timing };
}

export function listCompiledEffects() {
  return [...EFFECTS.entries()].map(([cardId, effect]) => ({ cardId, ...effect }));
}


/**
 * Resolve a compiled card effect against the canonical rules-runtime game state.
 * This is the integration path for engine simulations; unlike the lightweight
 * opponent-policy adapter above, draws pass through shared rule checkpoints.
 */
export function resolveCompiledCardEffectInState({ state, playerIndex, cardId, timing }) {
  const effect = getCompiledEffect(cardId, timing);
  if (!effect) return { resolved: false, status: 'unsupported', cardId: canonicalCardId(cardId), timing };
  if (!state || !Array.isArray(state.players) || state.players.length !== 2) {
    throw new TypeError('Canonical card effects require a two-player rules-runtime state.');
  }
  if (!Number.isInteger(playerIndex) || playerIndex < 0 || playerIndex > 1) {
    throw new TypeError('playerIndex must be 0 or 1.');
  }
  if (effect.handler === 'draw') {
    const drawResult = drawCards(state, playerIndex, effect.count);
    const status = drawResult.deckout ? (state.gameResult?.status === 'draw' ? 'game-draw' : 'deck-out') : 'resolved';
    return {
      resolved: true,
      status,
      effectId: effect.cardId,
      requested: effect.count,
      drawn: drawResult.drawn,
      checkpoint: drawResult.result ?? null
    };
  }
  return { resolved: false, status: 'unsupported', cardId: effect.cardId, timing };
}
