import { resolveCompiledCardEffect } from './card-effect-engine.mjs';
/**
 * Deterministic, card-by-card opponent turn policy for the prototype simulator.
 * It uses exact deck composition and database cost/power/counter/text, but effect
 * resolution and target selection remain heuristic; this is not judge-accurate.
 */
const textOf = c => `${c?.effectText || ''} ${c?.triggerText || ''}`.toLowerCase();
const lookup = (db, id) => db instanceof Map ? db.get(id) : db?.[id];
const num = (v, fallback=0) => Number.isFinite(Number(v)) ? Number(v) : fallback;
const isChar = c => ['character','stage'].includes(String(c?.category || '').toLowerCase());
const isEvent = c => String(c?.category || '').toLowerCase() === 'event';
const removalLike = c => /\bko\b|return.{0,100}(hand|deck)|place.{0,80}trash|trash.{0,80}character|cost of.{0,80}character|give.{0,100}-[0-9,]+ power|rest up to.{0,80}character/.test(textOf(c));
const shuffle = (arr, random) => { for(let i=arr.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[arr[i],arr[j]]=[arr[j],arr[i]];} return arr; };

export function createOpponentState(deck, cardsById, random) {
  const ids = [...(deck?.mainDeck || [])];
  const shuffled = shuffle(ids, random);
  const hand = shuffled.splice(0,5);
  const life = shuffled.splice(0,5);
  return {
    deckId: deck?.id || 'unknown', leaderId: deck?.leaderId || '',
    deck: shuffled, hand, life, trash: [], board: [], don: 0, turns: 0,
    cardsById
  };
}

function choosePlay(state, available) {
  const candidates = state.hand.map((id, index) => ({id,index,card:lookup(state.cardsById,id)}))
    .filter(x => x.card && num(x.card.cost,99) <= available && (isChar(x.card) || isEvent(x.card)))
    .map(x => ({...x, score: (num(x.card.power)/1000) + (isChar(x.card)?1.8:0) + (removalLike(x.card)?1.5:0) + (num(x.card.counter)>=2000?-0.25:0) - num(x.card.cost)*0.12}));
  candidates.sort((a,b)=>b.score-a.score || num(b.card.cost)-num(a.card.cost) || a.id.localeCompare(b.id));
  return candidates[0] || null;
}

function spendCounter(state, needed) {
  if (needed <= 0) return [];
  const options = state._brookHand.map((id,index)=>({id,index,card:lookup(state.cardsById,id),counter:num(lookup(state.cardsById,id)?.counter)}))
    .filter(x=>x.counter>0).sort((a,b)=>b.counter-a.counter);
  const used=[]; let total=0;
  for(const x of options){ if(total>=needed)break; total+=x.counter;used.push(x); }
  if(total<needed)return [];
  for(const x of used.sort((a,b)=>b.index-a.index))state._brookHand.splice(x.index,1);
  state._brookTrash.push(...used.map(x=>x.id));
  return used.map(x=>x.id);
}

/** Resolves one opponent turn against a simplified Brook defense state. */
export function playOpponentTurn(state, {turn, opponentStartsFirst=false, brookLife=[], brookHand=[], brookTrash=[], brookBoard=[], random=Math.random}={}) {
  state.turns++;
  state.board.forEach(c=>{c.rested=false;});
  const log=[];
  state._brookHand=brookHand;
  state._brookTrash=brookTrash;
  const firstOpponentTurn = turn===1;
  state.don=Math.min(10,state.don+(firstOpponentTurn && opponentStartsFirst ? 1 : 2));
  if(!(firstOpponentTurn && opponentStartsFirst) && state.deck.length){state.hand.push(state.deck.shift());log.push('Draw 1 card');}
  let available=state.don, plays=0, removals=0;
  while(plays<3){
    const chosen=choosePlay(state,available); if(!chosen)break;
    const {id,card}=chosen; const cost=num(card.cost,99);
    state.hand.splice(state.hand.indexOf(id),1);available-=cost;plays++;
    if(isChar(card)){
      state.board.push({id,power:num(card.power),cost,rested:false,enteredTurn:turn});
      log.push(`Play ${card.name||id} (${id}) for ${cost} DON!!`);
      const effectResult = resolveCompiledCardEffect({cardId:id,timing:'on-play',player:state,log});
      if (effectResult.status === 'deck-out-pending') log.push(`RULE CHECK REQUIRED: ${id} caused a pending deck-out check.`);
    } else {
      state.trash.push(id);log.push(`Use event ${card.name||id} (${id}) for ${cost} DON!!`);
      if(removalLike(card)&&brookBoard.length){
        const targetIndex=brookBoard.findIndex(x=>num(x.cost,99)<=cost+1);
        if(targetIndex>=0){brookBoard.splice(targetIndex,1);removals++;log.push(`Heuristic effect removes Brook board target (${id})`);}
      }
      // Heuristic resolution of obvious draw/search-like text; other effects are not interpreted.
      if(/draw\s+(?:up to )?\d+|look at the top \d+ cards/i.test(textOf(card)) && state.deck.length){
        const drawn=state.deck.shift();state.hand.push(drawn);log.push(`Heuristic draw/search: add ${drawn} to hand`);
      }
    }
  }
  const leader=lookup(state.cardsById,state.leaderId);
  const attackers=[{id:state.leaderId,name:leader?.name||'Leader',power:num(leader?.power,5000),leader:true},...state.board.filter(c=>!c.rested&&c.power>0&&(c.enteredTurn<turn||/\brush\b/i.test(textOf(lookup(state.cardsById,c.id))))).map(c=>({id:c.id,name:lookup(state.cardsById,c.id)?.name||c.id,power:c.power,leader:false,boardRef:c}))];
  let attacks=0,hits=0,noLifeHits=0,countersUsed=0;
  for(const attacker of attackers){
    attacks++;
    // Defender has a 5000-power Leader. Counter cards are spent only if sufficient.
    const needed=(Math.floor((attacker.power-5000)/1000)+1)*1000;
    if(attacker.power<5000){log.push(`${attacker.name} attacks at ${attacker.power}; no life pressure`);continue;}
    const used=spendCounter(state,needed);
    if(attacker.boardRef)attacker.boardRef.rested=true;
    if(used.length){countersUsed+=used.length;log.push(`Brook defends ${attacker.name} (${attacker.power}) with ${used.length} counter card(s)`);continue;}
    if(brookLife.length){const card=brookLife.shift();brookHand.push(card);hits++;log.push(`${attacker.name} hits Leader; life card ${card} enters hand`);}
    else {hits++;noLifeHits++;log.push(`${attacker.name} hits Leader with no life remaining`);}
    if(attacker.boardRef)attacker.boardRef.rested=true;
  }
  delete state._brookHand;
  delete state._brookTrash;
  return {log,plays,attacks,hits,noLifeHits,removals,countersUsed,availableDON:available,opponentHand:state.hand.length,opponentBoard:state.board.length,opponentDeck:state.deck.length};
}

export function resolveAttacksAgainstOpponent(state, attackers, random=Math.random) {
  const log=[]; let hits=0, noLifeHits=0, countersUsed=0;
  for(const attacker of attackers){
    const power=num(attacker.power);
    if(power<5000){log.push(`${attacker.name||attacker.id} attacks at ${power}; no leader pressure`);continue;}
    const needed=(Math.floor((power-5000)/1000)+1)*1000;
    const options=state.hand.map((id,index)=>({id,index,counter:num(lookup(state.cardsById,id)?.counter)})).filter(x=>x.counter>0).sort((a,b)=>b.counter-a.counter);
    const used=[];let total=0;for(const x of options){if(total>=needed)break;total+=x.counter;used.push(x);}
    if(total>=needed){for(const x of used.sort((a,b)=>b.index-a.index))state.hand.splice(x.index,1);state.trash.push(...used.map(x=>x.id));countersUsed+=used.length;log.push(`Opponent defends ${attacker.name||attacker.id} (${power}) with ${used.length} counter card(s)`);continue;}
    if(state.life.length){const lifeCard=state.life.shift();state.hand.push(lifeCard);hits++;log.push(`${attacker.name||attacker.id} hits opponent Leader; life card ${lifeCard} enters hand`);}
    else {hits++;noLifeHits++;log.push(`${attacker.name||attacker.id} hits opponent Leader with no life remaining`);}
  }
  return {log,hits,noLifeHits,countersUsed,opponentLife:state.life.length,opponentHand:state.hand.length,loss:noLifeHits>0};
}

export function estimateDeckActions(deck, cardsById) {
  const cards=(deck?.mainDeck||[]).map(id=>lookup(cardsById,id)).filter(Boolean);
  return {deckId:deck?.id||'unknown',mainDeckCount:cards.length,characterOrStageCount:cards.filter(isChar).length,eventCount:cards.filter(isEvent).length,unknownCards:(deck?.mainDeck||[]).length-cards.length,policy:'card-by-card greedy play; attacks and obvious text cues; incomplete effect resolution'};
}
