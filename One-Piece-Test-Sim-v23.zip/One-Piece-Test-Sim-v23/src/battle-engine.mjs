/**
 * Explicit battle state machine for Brook Lab.
 * Rules basis: One Piece Card Game Comprehensive Rules v1.2.1, sections 7-9.
 * This module handles generic battle procedure only. Printed card effects must
 * be supplied as explicit callbacks/actions; unsupported effects are not guessed.
 */
import { processRuleCheckpoint } from './rule-processing.mjs';
import { currentEntityPower } from './rules-runtime.mjs';

export class BattleRuleError extends Error {
  constructor(code, message) { super(message); this.name = 'BattleRuleError'; this.code = code; }
}
const need = (ok, code, message) => { if (!ok) throw new BattleRuleError(code, message); };
const other = i => 1 - i;
const cardId = c => c?.instanceId ?? c?.id;
const currentPower = c => currentEntityPower(c);
const findCharacter = (p, id) => p.characters.find(c => cardId(c) === id);
function getPlayer(state, i) { need(Number.isInteger(i) && i >= 0 && i < 2, 'BAD_PLAYER', 'Player index must be 0 or 1.'); return state.players[i]; }
function findEntity(p, ref) { if (ref?.type === 'leader') return p.leader; if (ref?.type === 'character') return findCharacter(p, ref.id); return null; }
function log(state, item) { state.log ??= []; state.log.push(item); }
function isCardInZone(player, card) {
  const same = x => x === card || (x && card && (x.instanceId ?? x.id) != null && (x.instanceId ?? x.id) === (card.instanceId ?? card.id));
  return player.hand.some(same) || player.deck.some(same) || player.life.some(same) || player.trash.some(same) || player.characters.some(same) || same(player.leader) || same(player.stage);
}
function hasKeyword(c, name) { return Boolean(c?.keywords?.includes(name)); }
function canAttackOnCurrentTurn(c, p, target) {
  if (!playedThisTurn(c, p)) return true;
  if (c?.canAttackOnPlay || c?.rush || hasKeyword(c, 'Rush')) return true;
  // Rush: Character permits an attack against a rested Character, not a Leader.
  if (c?.rushCharacter || hasKeyword(c, 'Rush: Character')) return target?.type === 'character';
  return false;
}
function playedThisTurn(c, p) { return c?.playedTurn === p.turnCount || c?.summoningSick === true; }

export function legalBattleTargets(state, attackerIndex, attacker = null) {
  const defender = getPlayer(state, other(attackerIndex));
  const canAttackActiveCharacters = Boolean(
    attacker?.canAttackActiveCharacters || attacker?.canAttackActiveCharactersThisTurn ||
    hasKeyword(attacker, 'Can Attack Active Characters')
  );
  return [
    ...(defender.leader ? [{ type: 'leader', id: cardId(defender.leader) }] : []),
    ...defender.characters
      .filter(c => c.rested || canAttackActiveCharacters)
      .map(c => ({ type: 'character', id: cardId(c) }))
  ];
}

export function declareBattle(state, { attackerPlayerIndex, attacker, target, onAttack = null, onOpponentAttack = null }) {
  need(!state.winner && !state.gameResult && state.phase === 'main', 'WRONG_PHASE', 'Attacks can only be declared in the Main Phase.');
  need(!state.battle, 'BATTLE_IN_PROGRESS', 'A battle is already in progress.');
  need(attackerPlayerIndex === state.turnPlayer, 'NOT_TURN_PLAYER', 'Only the turn player may declare an attack.');
  const ap = getPlayer(state, attackerPlayerIndex), dp = getPlayer(state, other(attackerPlayerIndex));
  let source;
  if (typeof attacker === 'string') source = cardId(ap.leader) === attacker ? { type: 'leader', id: attacker } : { type: 'character', id: attacker };
  else if (attacker?.type === 'leader' || attacker?.type === 'character') source = attacker;
  else if (attacker === ap.leader || cardId(attacker) === cardId(ap.leader)) source = { type: 'leader', id: cardId(ap.leader) };
  else source = { type: 'character', id: cardId(attacker) };
  const card = findEntity(ap, source);
  need(card, 'ATTACKER_NOT_FOUND', 'Attacking Leader or Character is not in the attacker’s field.');
  need(!card.rested, 'ATTACKER_RESTED', 'The attacker must be active.');
  need(!(card.cannotAttack || card.cannotAttackThisTurn || hasKeyword(card, 'Cannot Attack')), 'ATTACK_PROHIBITED', 'An effect prevents this card from attacking.');
  need(source.type === 'leader' || canAttackOnCurrentTurn(card, ap, target), 'SUMMONING_SICKNESS', 'This Character cannot attack that target on the turn it was played.');
  need(ap.turnCount > 0, 'TURN_NOT_STARTED', 'Begin the turn before declaring an attack.');
  need(ap.turnCount > 1, 'FIRST_TURN_ATTACK', 'A player cannot battle on their first turn.');
  const targets = legalBattleTargets(state, attackerPlayerIndex, card);
  need(targets.some(t => t.type === target?.type && t.id === target?.id), 'ILLEGAL_TARGET', 'Target must be the opposing Leader or a rested opposing Character.');
  card.rested = true;
  state.battle = {
    attackerPlayerIndex, defenderPlayerIndex: other(attackerPlayerIndex), attacker: { ...source },
    originalTarget: { ...target }, target: { ...target }, step: 'attack', blockerUsed: false,
    counterPower: 0, counterActions: [], result: null
  };
  state.phase = 'battle';
  log(state, { type: 'battle-start', attackerPlayerIndex, attacker: { ...source }, target: { ...target } });
  // The callbacks resolve explicitly registered [When Attacking] and [On Your
  // Opponent's Attack] effects. They are deliberately not inferred from text.
  if (typeof onAttack === 'function') onAttack({ state, battle: state.battle, attacker: card, controller: attackerPlayerIndex });
  if (typeof onOpponentAttack === 'function') onOpponentAttack({ state, battle: state.battle, defender: dp, controller: other(attackerPlayerIndex) });
  processRuleCheckpoint(state);
  if (!state.winner && !state.gameResult && (!findEntity(ap, source) || !findEntity(dp, target))) {
    state.battle.step = 'end';
    log(state, { type: 'battle-short-circuit', reason: 'attacker-or-target-left-area-during-attack-step' });
  }
  return state.battle;
}

const STEPS = ['attack', 'block', 'counter', 'damage', 'end'];
export function advanceBattleStep(state, { onCounterStep = null } = {}) {
  need(!state.winner && !state.gameResult, 'GAME_OVER', 'The game has ended.');
  const b = state.battle;
  need(state.phase === 'battle' && b, 'NO_BATTLE', 'There is no battle in progress.');
  if (b.step === 'attack' || b.step === 'block' || b.step === 'counter') {
    const ap = getPlayer(state, b.attackerPlayerIndex), dp = getPlayer(state, b.defenderPlayerIndex);
    if (!findEntity(ap, b.attacker) || !findEntity(dp, b.target)) {
      b.step = 'end'; log(state, { type: 'battle-short-circuit', reason: 'attacker-or-target-left-area' }); return b.step;
    }
  }
  const next = STEPS[STEPS.indexOf(b.step) + 1];
  need(next, 'BATTLE_ALREADY_AT_END', 'Battle is already at its final step.');
  b.step = next;
  log(state, { type: 'battle-step', step: next });
  if (next === 'counter' && typeof onCounterStep === 'function') {
    const defender = getPlayer(state, b.defenderPlayerIndex);
    onCounterStep({ state, battle: b, defender, controller: b.defenderPlayerIndex });
    processRuleCheckpoint(state);
  }
  return next;
}

/** Activate one Blocker in the Block Step. Effects such as [On Block] are caller-resolved. */
export function activateBlocker(state, blockerId, { onBlock } = {}) {
  need(!state.winner && !state.gameResult, 'GAME_OVER', 'The game has ended.');
  const b = state.battle;
  need(b && state.phase === 'battle' && b.step === 'block', 'WRONG_BATTLE_STEP', 'Blocker can only be activated during the Block Step.');
  need(!b.blockerUsed, 'BLOCKER_ALREADY_USED', 'Only one Blocker can be activated during a battle.');
  const defender = getPlayer(state, b.defenderPlayerIndex);
  const blocker = findCharacter(defender, blockerId);
  need(blocker && !blocker.rested && (blocker.blocker || blocker.keywords?.includes('Blocker')), 'ILLEGAL_BLOCKER', 'Chosen Character is not an active Blocker.');
  need(!(findEntity(getPlayer(state, b.attackerPlayerIndex), b.attacker)?.unblockable || findEntity(getPlayer(state, b.attackerPlayerIndex), b.attacker)?.keywords?.includes('Unblockable')), 'UNBLOCKABLE', 'This attack cannot be blocked.');
  blocker.rested = true;
  b.blockerUsed = true;
  b.target = { type: 'character', id: cardId(blocker) };
  log(state, { type: 'blocker', player: defender.id, blocker: cardId(blocker), redirectedTarget: b.target });
  if (typeof onBlock === 'function') onBlock({ state, blocker, battle: b, controller: b.defenderPlayerIndex });
  processRuleCheckpoint(state);
  return b.target;
}

/** Add a counter response during Counter Step. Caller must already validate/pay card-specific cost. */
export function addBattleCounter(state, { amount, cardId: responseCardId = null, source = 'character-counter', apply = null }) {
  need(!state.winner && !state.gameResult, 'GAME_OVER', 'The game has ended.');
  const b = state.battle;
  need(b && state.phase === 'battle' && b.step === 'counter', 'WRONG_BATTLE_STEP', 'Counter responses are only legal during the Counter Step.');
  need(Number.isInteger(amount) && amount >= 0, 'BAD_COUNTER_AMOUNT', 'Counter power must be a non-negative integer.');
  const defender = getPlayer(state, b.defenderPlayerIndex);
  const target = findEntity(defender, b.target);
  need(target, 'TARGET_LEFT_AREA', 'The battle target is no longer in its area.');
  b.counterPower += amount;
  b.counterActions.push({ amount, cardId: responseCardId, source });
  if (typeof apply === 'function') apply({ state, battle: b, defender, target });
  log(state, { type: 'counter', player: defender.id, amount, cardId: responseCardId, source, total: b.counterPower });
  processRuleCheckpoint(state);
  return b.counterPower;
}

/**
 * Resolve damage after all counter responses. `resolveLifeTrigger` must execute
 * a selected Trigger effect and return only after that effect resolves. It may
 * mutate the state; rule processing runs after each damage/trigger checkpoint.
 */
export function resolveBattleDamage(state, { resolveLifeTrigger = () => false, onBattleResult = null } = {}) {
  need(!state.winner && !state.gameResult, 'GAME_OVER', 'The game has ended.');
  const b = state.battle;
  need(b && state.phase === 'battle' && b.step === 'damage', 'WRONG_BATTLE_STEP', 'Damage resolves only during the Damage Step.');
  const ap = getPlayer(state, b.attackerPlayerIndex), dp = getPlayer(state, b.defenderPlayerIndex);
  const attacker = findEntity(ap, b.attacker), target = findEntity(dp, b.target);
  if (!attacker || !target) {
    b.result = { status: 'cancelled', reason: 'attacker-or-target-left-area' };
    b.step = 'end'; return b.result;
  }
  const attackPower = currentPower(attacker);
  const defensePower = currentPower(target) + b.counterPower;
  const won = attackPower >= defensePower;
  const result = { status: won ? 'attack-won' : 'attack-lost', attackPower, defensePower, target: { ...b.target }, lifeCardsProcessed: 0, ko: false };

  if (won && b.target.type === 'character') {
    const idx = dp.characters.findIndex(c => cardId(c) === b.target.id);
    if (idx >= 0) {
      const [ko] = dp.characters.splice(idx, 1);
      dp.trash.push(ko.cardId ?? ko.id ?? ko);
      result.ko = true;
      log(state, { type: 'character-ko-by-battle', player: dp.id, card: cardId(ko) });
    }
  } else if (won && b.target.type === 'leader') {
    const attackerKeywords = attacker.keywords ?? [];
    const doubleAttack = Boolean(attacker.doubleAttack || attackerKeywords.includes('Double Attack'));
    const banish = Boolean(attacker.banish || attackerKeywords.includes('Banish'));
    const damageCount = doubleAttack ? 2 : 1;
    for (let n = 0; n < damageCount; n++) {
      // Each successful damage instance is processed separately; trigger resolution
      // may change game state before a subsequent Double Attack damage is applied.
      if (dp.life.length === 0) {
        result.leaderDamagedAtZeroLife = true;
        processRuleCheckpoint(state, { pendingLeaderDamage: [b.defenderPlayerIndex] });
        break;
      }
      const lifeCard = dp.life.shift();
      result.lifeCardsProcessed++;
      if (banish) {
        dp.trash.push(lifeCard);
        log(state, { type: 'life-banished', player: dp.id, card: lifeCard });
      } else {
        const triggerAvailable = Boolean(lifeCard?.trigger || lifeCard?.keywords?.includes('Trigger'));
        const triggerResolved = triggerAvailable && resolveLifeTrigger({ state, defender: dp, card: lifeCard, damageIndex: n + 1 }) === true;
        if (!triggerResolved) dp.hand.push(lifeCard);
        else if (!isCardInZone(dp, lifeCard)) dp.trash.push(lifeCard);
        log(state, { type: triggerResolved ? 'life-trigger-resolved' : 'life-added-to-hand', player: dp.id, card: lifeCard });
      }
      processRuleCheckpoint(state);
      if (state.winner || state.gameResult) break;
    }
  }
  b.result = result;
  log(state, { type: 'battle-result', ...result });
  if (typeof onBattleResult === 'function') onBattleResult({ state, battle: b, result });
  processRuleCheckpoint(state);
  return result;
}

export function finishBattle(state) {
  const b = state.battle;
  need(b && state.phase === 'battle' && b.step === 'end', 'WRONG_BATTLE_STEP', 'Advance the battle to End of Battle before finishing it.');
  const result = b.result;
  log(state, { type: 'battle-end', result });
  state.battle = null;
  if (!state.winner && !state.gameResult) state.phase = 'main';
  return result;
}
