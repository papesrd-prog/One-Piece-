/**
 * Reproducible, deliberately limited match runner for the unified rules engine.
 * It executes only the actions implemented by this prototype. It is useful for
 * integration/regression tests, not a judge-accurate full-card simulator.
 */
import { createRuntimeState } from './rules-runtime.mjs';
import { executeUnifiedAction } from './unified-game-engine.mjs';

export function seededRandom(seed = 1) {
  let a = (Number(seed) >>> 0) || 1;
  return function random() {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function lookup(cardsById, id) { return cardsById instanceof Map ? cardsById.get(id) : cardsById?.[id]; }
function shuffle(array, random) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}
function cardIdOf(card) { return card?.cardId ?? card?.id ?? card; }
function normalizeCard(raw, cardsById, instanceId) {
  const id = typeof raw === 'string' ? raw : cardIdOf(raw);
  const source = typeof raw === 'string' ? lookup(cardsById, id) : raw;
  if (!source || typeof source !== 'object') throw new Error(`Missing card data for ${id}.`);
  return { ...source, id: source.id ?? id, cardId: id, instanceId };
}

/** Create a shuffled, dealt canonical runtime state from two deck descriptions. */
export function createMatchState({ players, cardsById, seed = 1, firstPlayer = 0 }) {
  if (!Array.isArray(players) || players.length !== 2) throw new TypeError('Exactly two player deck descriptions are required.');
  const random = seededRandom(seed);
  const runtimePlayers = players.map((input, playerIndex) => {
    if (!input?.leader || !Array.isArray(input.deck)) throw new TypeError(`Player ${playerIndex + 1} requires a leader and deck array.`);
    const leaderRaw = typeof input.leader === 'string' ? lookup(cardsById, input.leader) : input.leader;
    if (!leaderRaw || typeof leaderRaw !== 'object') throw new Error(`Missing leader data for player ${playerIndex + 1}.`);
    const leaderId = cardIdOf(leaderRaw);
    const leader = { ...leaderRaw, id: leaderRaw.id ?? leaderId, cardId: leaderId, instanceId: `P${playerIndex + 1}-leader` };
    const deck = input.deck.map((raw, i) => normalizeCard(raw, cardsById, `P${playerIndex + 1}-deck-${i + 1}`));
    shuffle(deck, random);
    const hand = deck.splice(0, 5);
    const life = deck.splice(0, 5);
    return { id: input.id ?? `P${playerIndex + 1}`, leader, deck, hand, life, donDeck: 10, donActive: 0, donRested: 0, characters: [], trash: [] };
  });
  const state = createRuntimeState(runtimePlayers, firstPlayer);
  state.phase = 'setup';
  state.match = { seed: Number(seed) >>> 0, actions: 0, unsupportedEffects: [], policy: 'greedy-character-and-leader-pressure-v1' };
  return state;
}

function action(state, payload, context) {
  const result = executeUnifiedAction(state, payload, context);
  state.match.actions++;
  return result;
}

function eligibleCharacterToPlay(player) {
  return player.hand
    .filter(card => String(card?.category ?? card?.type ?? '').toLowerCase() === 'character')
    .filter(card => Number.isInteger(Number(card.cost)) && Number(card.cost) >= 0 && Number(card.cost) <= player.donActive)
    .sort((a, b) => (Number(b.power || 0) - Number(a.power || 0)) || (Number(b.cost || 0) - Number(a.cost || 0)) || String(a.cardId).localeCompare(String(b.cardId)))[0] ?? null;
}

function resolveSimpleBattle(state, playerIndex, attacker, target, context) {
  action(state, { type: 'declare-attack', playerIndex, attacker, target }, context);
  action(state, { type: 'battle-step' }, context); // block
  action(state, { type: 'battle-step' }, context); // counter
  action(state, { type: 'battle-step' }, context); // damage
  action(state, { type: 'resolve-battle-damage' }, context);
  if (state.winner || state.gameResult) return;
  action(state, { type: 'battle-step' }, context); // end
  action(state, { type: 'finish-battle' }, context);
}

function takeMainActions(state, playerIndex, context) {
  const player = state.players[playerIndex];
  // Play affordable Characters greedily. Unsupported On Play effects are recorded,
  // never guessed from arbitrary printed text.
  while (!state.winner && !state.gameResult) {
    const card = eligibleCharacterToPlay(player);
    if (!card) break;
    const result = action(state, { type: 'play-character', playerIndex, cardId: card.cardId }, context);
    const effect = action(state, { type: 'resolve-card-effect', playerIndex, cardId: card.cardId, timing: 'on-play' }, context);
    if (effect.status === 'unsupported') state.match.unsupportedEffects.push({ player: player.id, cardId: card.cardId, timing: 'on-play' });
    if (!result.played) break;
  }
  if (state.winner || state.gameResult || player.turnCount <= 1) return;
  const defender = state.players[1 - playerIndex];
  const leaderTarget = { type: 'leader', id: defender.leader.instanceId ?? defender.leader.id };
  const attackers = [
    ...(player.leader && !player.leader.rested ? [{ type: 'leader', id: player.leader.instanceId ?? player.leader.id }] : []),
    ...player.characters.filter(c => !c.rested && c.playedTurn < player.turnCount).map(c => ({ type: 'character', id: c.instanceId ?? c.id }))
  ];
  for (const attacker of attackers) {
    if (state.winner || state.gameResult) break;
    const entity = attacker.type === 'leader' ? player.leader : player.characters.find(c => (c.instanceId ?? c.id) === attacker.id);
    if (!entity || entity.rested) continue;
    try { resolveSimpleBattle(state, playerIndex, attacker, leaderTarget, context); }
    catch (error) {
      // A policy's illegal proposed action is visible in the trace and terminates
      // this match as an engine/policy error; it is not silently counted as a loss.
      state.match.error = { code: error.code ?? 'ACTION_ERROR', message: error.message, action: { type: 'declare-attack', playerIndex, attacker, target: leaderTarget } };
      state.gameResult = { status: 'invalid-match', winner: null, reason: 'policy-action-rejected' };
      state.phase = 'ended';
      break;
    }
  }
}

/** Run a bounded reproducible match using only explicitly supported basic actions. */
export function runMatch({ players, cardsById, seed = 1, firstPlayer = 0, maxTurns = 30 } = {}) {
  if (!Number.isInteger(maxTurns) || maxTurns < 1) throw new TypeError('maxTurns must be a positive integer.');
  const state = createMatchState({ players, cardsById, seed, firstPlayer });
  const context = { cardsById };
  let turnsRun = 0;
  while (!state.winner && !state.gameResult && turnsRun < maxTurns) {
    const playerIndex = state.turnPlayer;
    action(state, { type: 'begin-turn', playerIndex }, context);
    turnsRun++;
    action(state, { type: 'advance-phase' }, context); // draw
    if (state.winner || state.gameResult) break;
    action(state, { type: 'advance-phase' }, context); // DON!!
    action(state, { type: 'advance-phase' }, context); // Main
    takeMainActions(state, playerIndex, context);
    if (state.winner || state.gameResult) break;
    action(state, { type: 'advance-phase' }, context); // End
    action(state, { type: 'end-turn' }, context);
  }
  const result = state.gameResult ?? { status: 'turn-limit', winner: null, reason: 'maximum-turns-reached' };
  return {
    seed: Number(seed) >>> 0,
    firstPlayer,
    turnsRun,
    actionCount: state.match.actions,
    status: result.status,
    winner: result.winner ?? null,
    reason: result.reason ?? null,
    unsupportedEffectCount: state.match.unsupportedEffects.length,
    unsupportedEffects: [...state.match.unsupportedEffects],
    error: state.match.error ?? null,
    players: state.players.map(p => ({ id: p.id, leaderId: p.leader?.cardId ?? p.leader?.id, life: p.life.length, hand: p.hand.length, deck: p.deck.length, trash: p.trash.length, characters: p.characters.length, donActive: p.donActive, donRested: p.donRested })),
    log: [...state.log]
  };
}

export function runMatchSeries({ games = 100, seed = 1, ...config } = {}) {
  if (!Number.isInteger(games) || games < 1) throw new TypeError('games must be a positive integer.');
  const results = [];
  const counts = { winsP1: 0, winsP2: 0, draws: 0, turnLimits: 0, invalidMatches: 0 };
  for (let i = 0; i < games; i++) {
    const result = runMatch({ ...config, seed: (Number(seed) + i) >>> 0, firstPlayer: i % 2 });
    results.push(result);
    if (result.status === 'win' && result.winner === (config.players?.[0]?.id ?? 'P1')) counts.winsP1++;
    else if (result.status === 'win') counts.winsP2++;
    else if (result.status === 'draw') counts.draws++;
    else if (result.status === 'turn-limit') counts.turnLimits++;
    else counts.invalidMatches++;
  }
  return { games, seed: Number(seed) >>> 0, counts, winRateP1: counts.winsP1 / games, winRateP2: counts.winsP2 / games, results };
}
