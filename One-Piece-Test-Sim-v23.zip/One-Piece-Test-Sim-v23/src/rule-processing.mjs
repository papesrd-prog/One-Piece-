/**
 * Rule-processing checkpoint for Brook Lab.
 * Implements CR 9 defeat checks for the runtime state model. Card-specific
 * replacement effects must be registered explicitly; this module never guesses.
 */
export class RuleProcessingError extends Error {
  constructor(code, message) { super(message); this.name = 'RuleProcessingError'; this.code = code; }
}

/**
 * Run one CR 9 defeat checkpoint after a game action/effect has finished.
 * A player loses when their deck is empty, or when their leader was damaged
 * while they had no Life. If both players meet a defeat condition at this same
 * checkpoint, both lose (draw); do not award a winner arbitrarily.
 * `pendingLeaderDamage` is a per-checkpoint set of player indices whose Leader
 * took damage while they had zero Life. Clear it after processing.
 */
export function processRuleCheckpoint(state, { pendingLeaderDamage = [] } = {}) {
  if (!state || !Array.isArray(state.players) || state.players.length !== 2) {
    throw new RuleProcessingError('BAD_STATE', 'Rule processing requires a two-player state.');
  }
  if (state.winner || state.gameResult) return state.gameResult ?? { status: 'ended', winner: state.winner };

  const damagedAtZero = new Set(pendingLeaderDamage);
  const losers = state.players.filter((p, i) => p.deck.length === 0 || damagedAtZero.has(i));
  if (!losers.length) {
    state.log?.push({ type: 'rule-checkpoint', result: 'no-defeat' });
    return { status: 'continue', losers: [] };
  }

  const loserIds = losers.map(p => p.id);
  const winnerIds = state.players.filter(p => !loserIds.includes(p.id)).map(p => p.id);
  const result = loserIds.length === 2
    ? { status: 'draw', winner: null, losers: loserIds, reason: 'simultaneous-defeat' }
    : { status: 'win', winner: winnerIds[0], losers: loserIds, reason: losers[0].deck.length === 0 ? 'deck-out' : 'leader-damaged-at-zero-life' };

  state.gameResult = result;
  state.winner = result.winner;
  state.phase = 'ended';
  state.log?.push({ type: 'rule-processing', ...result });
  return result;
}
