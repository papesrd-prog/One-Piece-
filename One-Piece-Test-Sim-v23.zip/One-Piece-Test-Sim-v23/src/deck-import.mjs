/** Import helpers for deck-builder exports. Simulation role mapping is explicitly heuristic. */
export function normalizeDeckExport(input, cardsById) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('Deck JSON must be an object.');
  const leaderId = input.leaderId || input.leader?.cardId || '';
  const raw = input.mainDeck ?? input.deck;
  if (!Array.isArray(raw)) throw new Error('Deck JSON must contain a mainDeck array.');
  const mainDeck = raw.map(x => typeof x === 'string' ? x : x?.cardId).filter(Boolean);
  if (!leaderId) throw new Error('Deck JSON is missing leaderId. Export the deck from Deck Builder and include its Leader.');
  const lookup = id => cardsById instanceof Map ? cardsById.get(id) : cardsById?.[id];
  if (!lookup(leaderId)) throw new Error(`Unknown Leader ID: ${leaderId}`);
  const unknown = [...new Set(mainDeck.filter(id => !lookup(id)))];
  if (unknown.length) throw new Error(`Unknown card IDs: ${unknown.slice(0, 12).join(', ')}`);
  const counts = Object.create(null);
  for (const id of mainDeck) counts[id] = (counts[id] || 0) + 1;
  return { leaderId, mainDeck, counts, total: mainDeck.length, is50CardDeck: mainDeck.length === 50 };
}

/** Convert imported printed data into the old Brook model's approximate role labels. */
export function inferSimulationCard(card) {
  const effect = `${card?.effectText || ''} ${card?.triggerText || ''}`.toLowerCase();
  const cost = Number.isFinite(Number(card?.cost)) ? Number(card.cost) : 4;
  const power = Number.isFinite(Number(card?.power)) ? Number(card.power) : 0;
  const counter = Number.isFinite(Number(card?.counter)) ? Number(card.counter) : 0;
  let role = 'value';
  if (/look at the top|reveal.*cards|search your deck|search.*deck|add up to .*hand/.test(effect)) role = 'search';
  else if (/return .*from your trash|add .*from your trash|add .*from .*trash to your hand/.test(effect)) role = 'recovery';
  else if (/trash .*from the top of your deck|mill|trash the top .*cards of your deck/.test(effect)) role = 'engine';
  else if (/ko .*character|return .*to the owner's hand|return .*to the bottom of .*deck|place .*in the trash/.test(effect)) role = 'removal';
  else if (/rush|double attack|banish/.test(effect) || power >= 7000 || cost >= 7) role = 'finisher';
  if (String(card?.category || '').toLowerCase() === 'event') role = /counter/.test(effect) ? 'counter-event' : (role === 'value' ? 'event' : role);
  return { name: card?.name || card?.cardId || 'Unknown', cost, power, role, counter, category: card?.category || 'Unknown', source: 'inferred-from-printed-text', confidence: 'heuristic-unverified' };
}

export function inferSimulationCardMap(deckIds, cardsById) {
  const out = {};
  const lookup = id => cardsById instanceof Map ? cardsById.get(id) : cardsById?.[id];
  for (const id of deckIds) if (!out[id]) out[id] = inferSimulationCard(lookup(id));
  return out;
}
