/**
 * Unified action facade for the experimental One Piece TCG rules runtime.
 * It routes supported actions through shared state and rules checkpoints.
 * This is an integration layer, not a claim of complete card/rules coverage.
 */
import {
  beginTurn, advancePhase, endTurn, drawCards, payDon, attachDon,
  applyPowerModifier, enqueueTriggeredEffect, resolveNextEffect, getRuntimeEffectHandlers
} from './rules-runtime.mjs';
import {
  declareBattle, advanceBattleStep, activateBlocker, addBattleCounter,
  resolveBattleDamage, finishBattle
} from './battle-engine.mjs';
import { resolveEffectDsl } from './effect-dsl.mjs';
import { resolveCompiledCardEffectInState } from './card-effect-engine.mjs';

export class UnifiedActionError extends Error {
  constructor(code, message) { super(message); this.name = 'UnifiedActionError'; this.code = code; }
}

function restoreState(state, snapshot) {
  for (const key of Object.keys(state)) delete state[key];
  Object.assign(state, snapshot);
}

const entityCardId = card => card?.cardId ?? card?.id ?? card?.instanceId;
const dbLookup = (db, id) => db instanceof Map ? db.get(id) : db?.[id];

function playCharacter(state, action, context = {}) {
  const playerIndex = action.playerIndex ?? state.turnPlayer;
  if (state.winner || state.gameResult) throw new UnifiedActionError('GAME_OVER', 'The game has ended.');
  if (state.phase !== 'main') throw new UnifiedActionError('WRONG_PHASE', 'Characters can only be played during the Main Phase.');
  if (playerIndex !== state.turnPlayer) throw new UnifiedActionError('NOT_TURN_PLAYER', 'Only the turn player may play a Character.');
  if (typeof action.cardId !== 'string' || !action.cardId) throw new UnifiedActionError('BAD_CARD_ID', 'A card ID is required.');
  const player = state.players[playerIndex];
  const handIndex = player.hand.findIndex(card => entityCardId(card) === action.cardId || card?.instanceId === action.cardId);
  if (handIndex < 0) throw new UnifiedActionError('CARD_NOT_IN_HAND', `Card ${action.cardId} is not in the player's hand.`);
  const handCard = player.hand[handIndex];
  const card = (handCard && typeof handCard === 'object') ? handCard : dbLookup(context.cardsById, action.cardId);
  if (!card || typeof card !== 'object') throw new UnifiedActionError('CARD_DATA_REQUIRED', `Card data for ${action.cardId} is required to play it.`);
  if (!['character'].includes(String(card.category ?? card.type ?? '').toLowerCase())) {
    throw new UnifiedActionError('NOT_CHARACTER', `Card ${action.cardId} is not identified as a Character.`);
  }
  const cost = Number(card.cost);
  if (!Number.isInteger(cost) || cost < 0) throw new UnifiedActionError('BAD_CARD_COST', `Card ${action.cardId} has no valid integer cost.`);
  if (player.donActive < cost) throw new UnifiedActionError('INSUFFICIENT_DON', `Playing ${action.cardId} costs ${cost} active DON!!.`);
  if (player.characters.length >= 5) throw new UnifiedActionError('CHARACTER_AREA_FULL', 'The Character area is full.');
  // Validate completely before applying costs or moving the card.
  player.donActive -= cost;
  player.donRested += cost;
  player.hand.splice(handIndex, 1);
  const instanceId = handCard?.instanceId ?? `inst-${player.id}-${player.turnCount}-${state.log.length}-${action.cardId}`;
  const character = {
    ...card,
    id: card.id ?? action.cardId,
    cardId: action.cardId,
    instanceId,
    cost,
    power: Number.isFinite(Number(card.power)) ? Number(card.power) : 0,
    rested: false,
    playedTurn: player.turnCount,
    summoningSick: false,
    attachedDon: Number(card.attachedDon ?? 0),
    powerModifiers: Array.isArray(card.powerModifiers) ? [...card.powerModifiers] : []
  };
  player.characters.push(character);
  state.log.push({ type: 'character-played', player: player.id, cardId: action.cardId, instanceId, cost });
  return { played: true, cardId: action.cardId, instanceId, cost, donActive: player.donActive, donRested: player.donRested };
}

/**
 * Apply one supported action atomically with respect to thrown validation errors.
 * If a handler rejects an action, the canonical state is restored. Valid game
 * outcomes such as deck-out remain committed. `context` may supply effect
 * handlers/callbacks, but those functions are not stored in game state.
 */
export function executeUnifiedAction(state, action, context = {}) {
  if (!state || !Array.isArray(state.players) || state.players.length !== 2) {
    throw new UnifiedActionError('BAD_STATE', 'Unified actions require a two-player game state.');
  }
  if (!action || typeof action.type !== 'string') {
    throw new UnifiedActionError('BAD_ACTION', 'An action type is required.');
  }
  let snapshot;
  try { snapshot = structuredClone(state); }
  catch { throw new UnifiedActionError('UNSNAPSHOTTABLE_STATE', 'Game state must contain cloneable data for atomic action validation.'); }

  try {
    switch (action.type) {
      case 'begin-turn': return beginTurn(state, action.playerIndex ?? state.turnPlayer);
      case 'advance-phase': return advancePhase(state);
      case 'end-turn': return endTurn(state);
      case 'draw': return drawCards(state, action.playerIndex ?? state.turnPlayer, action.count ?? 1);
      case 'pay-don': return payDon(state, action.playerIndex ?? state.turnPlayer, action.amount);
      case 'play-character': return playCharacter(state, action, context);
      case 'attach-don': return attachDon(state, action.playerIndex ?? state.turnPlayer, action.target, action.count ?? 1);
      case 'power-modifier': return applyPowerModifier(state, action.playerIndex ?? state.turnPlayer, action.target, action.amount, action.duration, action.operation ?? 'add');
      case 'queue-effect': return enqueueTriggeredEffect(state, action.effect);
      case 'resolve-next-effect': return resolveNextEffect(state, context.handlers ?? getRuntimeEffectHandlers(), context.effectContext ?? {});
      case 'resolve-dsl-effect': return resolveEffectDsl(state, action.program, { controller: action.controller ?? state.turnPlayer, effectId: action.effectId ?? null });
      case 'resolve-card-effect': return resolveCompiledCardEffectInState({ state, playerIndex: action.playerIndex ?? state.turnPlayer, cardId: action.cardId, timing: action.timing });
      case 'declare-attack': return declareBattle(state, {
        attackerPlayerIndex: action.playerIndex ?? state.turnPlayer,
        attacker: action.attacker,
        target: action.target
      });
      case 'battle-step': return advanceBattleStep(state);
      case 'activate-blocker': return activateBlocker(state, action.blockerId);
      case 'counter': return addBattleCounter(state, { amount: action.amount, cardId: action.cardId ?? null, source: action.source ?? 'unified-action' });
      case 'resolve-battle-damage': return resolveBattleDamage(state, { resolveLifeTrigger: context.resolveLifeTrigger ?? (() => false) });
      case 'finish-battle': return finishBattle(state);
      default: throw new UnifiedActionError('UNSUPPORTED_ACTION', `Unsupported unified action: ${action.type}`);
    }
  } catch (error) {
    restoreState(state, snapshot);
    throw error;
  }
}

export const UNIFIED_ACTION_TYPES = Object.freeze([
  'begin-turn', 'advance-phase', 'end-turn', 'draw', 'pay-don', 'play-character', 'attach-don',
  'power-modifier', 'queue-effect', 'resolve-next-effect', 'resolve-dsl-effect',
  'resolve-card-effect', 'declare-attack', 'battle-step', 'activate-blocker',
  'counter', 'resolve-battle-damage', 'finish-battle'
]);
