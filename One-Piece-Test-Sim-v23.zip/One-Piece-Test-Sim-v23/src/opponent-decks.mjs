import { validateDeck } from './deck-legality.mjs';
const clamp=(n,min,max)=>Math.min(max,Math.max(min,n));
const effectText=c=>`${c?.effectText||''} ${c?.triggerText||''}`.toLowerCase();

export function validateOpponentDeck(deck,cardsById,legality){
 const result=validateDeck({leaderId:deck.leaderId,mainDeck:deck.mainDeck,cardsById,legality});
 return {...result,legal:result.legal,errors:result.errors,warnings:result.warnings};
}

/** Reproducible composition-based proxy. Does not simulate opponent cards/actions individually. */
export function deriveOpponentProfile(deck,cardsById){
 const get=id=>cardsById instanceof Map?cardsById.get(id):cardsById?.[id];
 const cards=(deck.mainDeck||[]).map(get).filter(Boolean),n=Math.max(1,cards.length);
 const costs=cards.map(c=>Number.isFinite(Number(c.cost))?Number(c.cost):4);
 const powers=cards.map(c=>Number.isFinite(Number(c.power))?Number(c.power):0);
 const mean=xs=>xs.reduce((a,b)=>a+b,0)/Math.max(1,xs.length);
 const low=costs.filter(c=>c<=2).length/n, high=costs.filter(c=>c>=6).length/n;
 const counter=cards.filter(c=>Number(c.counter)>=1000).length/n;
 const event=cards.filter(c=>String(c.category||'').toLowerCase()==='event').length/n;
 const removal=/\bko\b|return.{0,80}(owner'?s hand|bottom of (?:the )?deck)|place.{0,60}in the trash|trash.{0,60}character|cost of.{0,60}character|rest up to.{0,50}character|give.{0,80}-[0-9,]+ power/i;
 const removalDensity=cards.filter(c=>removal.test(effectText(c))).length/n;
 const avgPower=mean(powers);
 const hit=clamp(.30+low*.38+(avgPower/10000)*.20-high*.08,.28,.78);
 const remove=clamp(.08+removalDensity*1.65+event*.10,.08,.72);
 return {hit:Number(hit.toFixed(4)),remove:Number(remove.toFixed(4)),life:Number(deck.leaderLife ?? 5),meanCost:Number(mean(costs).toFixed(3)),meanPower:Math.round(avgPower),lowCostRatio:Number(low.toFixed(4)),highCostRatio:Number(high.toFixed(4)),counterRatio:Number(counter.toFixed(4)),eventRatio:Number(event.toFixed(4)),removalDensity:Number(removalDensity.toFixed(4)),listSize:cards.length,method:'heuristic-derived-from-list-statistics-and-effect-text',caveat:'Opponent cards are not played individually; profile is only an abstract pressure approximation.'};
}


/** Parse common one-card-per-line tournament list formats. Parsing is convenience only; IDs are validated separately. */
export function parseOpponentDeckText(text) {
  const mainDeck = [];
  const unparsed = [];
  const lines = String(text ?? '').split(/\r?\n/);
  const idPattern = '([A-Z0-9]+-\\d{3}(?:_p\\d+)?)';
  const firstQty = new RegExp('^(\\d+)\\s*[x×]?\\s+' + idPattern + '(?:\\s|$)', 'i');
  const idFirst = new RegExp('^' + idPattern + '\\s*[x×]\\s*(\\d+)(?:\\s|$)', 'i');
  const idOnly = new RegExp('^' + idPattern + '(?:\\s|$)', 'i');
  for (const raw of lines) {
    const line = raw.trim();
    if (!line || line.startsWith('#') || line.startsWith('//')) continue;
    let m = line.match(firstQty);
    let id, count;
    if (m) { count = Number(m[1]); id = m[2]; }
    else if ((m = line.match(idFirst))) { id = m[1]; count = Number(m[2]); }
    else if ((m = line.match(idOnly))) { id = m[1]; count = 1; }
    else { unparsed.push(raw); continue; }
    if (!Number.isInteger(count) || count < 1 || count > 50) { unparsed.push(raw); continue; }
    for (let i = 0; i < count; i++) mainDeck.push(id.toUpperCase());
  }
  return { mainDeck, unparsed, total: mainDeck.length };
}
