import { declareBattle, advanceBattleStep, addBattleCounter, resolveBattleDamage as resolveBattleDamageCore, finishBattle } from './battle-engine.mjs';
import { createRuntimeState, beginTurn as beginRuntimeTurn, advancePhase as advanceRuntimePhase, endTurn as endRuntimeTurn, payDon as payRuntimeDon, registerRuntimeEffectHandler, getRuntimeEffectHandler, getRuntimeEffectHandlers } from './rules-runtime.mjs';
/**
 * Brook Lab rules core (experimental).
 * This module models core state transitions, not a complete judge-accurate OPTCG implementation.
 * Card text effects must be registered explicitly; unsupported effects throw instead of being guessed.
 */
export const RULES_VERSION = '1.2.1';
export const RULES_DATE = '2026-08-28';
export const STARTING_LIFE = 5;
export const STARTING_HAND = 5;
export const DECK_SIZE = 50;
export const DON_DECK_SIZE = 10;

export class RuleError extends Error { constructor(code, message) { super(message); this.name='RuleError'; this.code=code; } }
const assert = (condition, code, message) => { if (!condition) throw new RuleError(code, message); };

export function validateDeck(deck, leader, donCount=10) {
  assert(leader && leader.category === 'Leader', 'LEADER_REQUIRED', 'A leader card is required.');
  assert(Array.isArray(deck), 'DECK_NOT_ARRAY', 'Deck must be an array of card IDs.');
  assert(deck.length === DECK_SIZE, 'DECK_SIZE', `Main deck must contain exactly ${DECK_SIZE} cards.`);
  assert(donCount === DON_DECK_SIZE, 'DON_DECK_SIZE', `DON!! deck must contain exactly ${DON_DECK_SIZE} cards.`);
  const counts = new Map();
  for (const card of deck) {
    assert(typeof card === 'string' && card.length, 'INVALID_CARD_ID', 'Each deck entry must be a card ID.');
    counts.set(card, (counts.get(card)||0)+1);
    assert(counts.get(card) <= 4, 'COPY_LIMIT', `Deck contains more than four copies of ${card}.`);
  }
  for (const id of deck) {
    const c = leader.cardDatabase?.[id];
    if (c) assert(c.colors?.some(color => leader.colors?.includes(color)), 'COLOR_RESTRICTION', `${id} is outside leader color identity.`);
  }
  return { valid:true, cards:deck.length, unique:counts.size, warnings: deck.some(id=>!leader.cardDatabase?.[id]) ? ['Some card IDs are absent from the loaded card database; their legality was not checked.'] : [] };
}

export function createGame({ players, random = Math.random, firstPlayer = 0 }) {
  assert(Array.isArray(players) && players.length === 2, 'PLAYER_COUNT', 'Exactly two players are supported.');
  assert(firstPlayer === 0 || firstPlayer === 1, 'BAD_FIRST_PLAYER', 'First player must be index 0 or 1.');
  const runtimePlayers = players.map((p, i) => {
    assert(Array.isArray(p.deck), 'DECK_NOT_ARRAY', `Player ${i + 1} must provide a deck array.`);
    const deck = [...p.deck];
    shuffle(deck, random);
    const hand = deck.splice(0, STARTING_HAND);
    const life = deck.splice(0, STARTING_LIFE);
    const leader = p.leader ? { ...p.leader, colors: Array.isArray(p.leader.colors) ? [...p.leader.colors] : p.leader.colors } : null;
    return {
      id: p.id ?? `P${i + 1}`, leader, deck, hand, life,
      trash: [], characters: [], stage: null, donDeck: DON_DECK_SIZE,
      donActive: 0, donRested: 0, donAttached: []
    };
  });
  const state = createRuntimeState(runtimePlayers, firstPlayer);
  // Preserve the legacy setup phase name for existing deck/mulligan UI code.
  state.phase = 'ready';
  state.turn = 0;
  return state;
}
function shuffle(a, random) { for(let i=a.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[a[i],a[j]]=[a[j],a[i]];} return a; }
export function mulligan(state, playerIndex, random=Math.random) {
  const p=player(state,playerIndex); assert(state.phase==='ready','WRONG_PHASE','Mulligan is only allowed during setup.');
  assert(!p.hasMulliganed,'MULLIGAN_USED','This player has already mulliganed.');
  p.deck.push(...p.hand); p.hand=[]; shuffle(p.deck,random); p.hand=p.deck.splice(0,STARTING_HAND); p.hasMulliganed=true;
  state.log.push({type:'mulligan',player:p.id}); return state;
}
export function startTurn(state, playerIndex = state.turnPlayer) {
  try {
    assert(!state.winner && !state.gameResult, 'GAME_OVER', 'The game has ended.');
    // Compatibility shorthand: if the caller starts the opposing turn from Main,
    // close the previous turn through the canonical End Phase and cleanup.
    if (state.phase === 'main') {
      assert(!state.battle, 'BATTLE_IN_PROGRESS', 'Finish the current battle before ending the turn.');
      assert(playerIndex === 1 - state.turnPlayer, 'WRONG_TURN_PLAYER', 'It is the opposing player’s turn next.');
      advanceRuntimePhase(state); // Main -> End
      endRuntimeTurn(state);
    } else if (state.phase === 'end') {
      assert(playerIndex === 1 - state.turnPlayer, 'WRONG_TURN_PLAYER', 'It is the opposing player’s turn next.');
      endRuntimeTurn(state);
    }
    beginRuntimeTurn(state, playerIndex);
    // Advance Refresh -> Draw -> DON!! -> Main using the same canonical runtime.
    for (let i = 0; i < 3; i++) {
      advanceRuntimePhase(state);
      if (state.winner || state.gameResult) break;
    }
    if (!state.winner && !state.gameResult) {
      const p = player(state, playerIndex);
      state.log.push({ type: 'turn-start', player: p.id, turn: state.turn, playerTurn: p.turnCount });
    }
    return state;
  } catch (e) {
    if (e instanceof Error && e.code && !(e instanceof RuleError)) throw new RuleError(e.code, e.message);
    throw e;
  }
}

export function endTurn(state) {
  try { return endRuntimeTurn(state); }
  catch (e) { if (e instanceof Error && e.code && !(e instanceof RuleError)) throw new RuleError(e.code, e.message); throw e; }
}
function player(state, i) { assert(Number.isInteger(i)&&i>=0&&i<2,'BAD_PLAYER','Player index must be 0 or 1.'); return state.players[i]; }
export function payDon(state, playerIndex, amount) {
  try { return payRuntimeDon(state, playerIndex, amount); }
  catch (e) { if (e instanceof Error && e.code && !(e instanceof RuleError)) throw new RuleError(e.code, e.message); throw e; }
}
export function legalAttackTargets(state, attackerPlayerIndex, attacker) {
  const defender=player(state,1-attackerPlayerIndex);
  const targets=[...(defender.leader ? [{type:'leader',id:defender.leader.id}] : [])];
  const canAttackActiveCharacters = Boolean(attacker?.canAttackActiveCharacters || attacker?.canAttackActiveCharactersThisTurn || attacker?.keywords?.includes('Can Attack Active Characters'));
  for(const c of defender.characters) if(c.rested || canAttackActiveCharacters) targets.push({type:'character',id:c.instanceId ?? c.id});
  return targets;
}
export function declareAttack(state, attackerPlayerIndex, attacker, target) {
  assert(state.phase==='main','WRONG_PHASE','Attacks can only be declared in the main phase.');
  try { return declareBattle(state,{attackerPlayerIndex,attacker,target}); }
  catch(e) { if(e instanceof Error && e.code) throw new RuleError(e.code,e.message); throw e; }
}
export function advanceBattle(state, nextStep) {
  assert(state.phase==='battle'&&state.battle,'NO_BATTLE','There is no battle in progress.');
  const order=['attack','block','counter','damage','end'];
  const current=order.indexOf(state.battle.step), next=order.indexOf(nextStep);
  assert(next===current+1,'BATTLE_STEP_ORDER','Battle steps must advance in order: attack, block, counter, damage, end.');
  const reached=advanceBattleStep(state);
  assert(reached===nextStep,'BATTLE_STEP_ORDER','Battle could not proceed to the requested step because the battle ended early.');
  return state.battle;
}
export function resolveBattleDamage(state, defenderCounterPower=0) {
  assert(state.phase==='battle'&&state.battle?.step==='damage','WRONG_BATTLE_STEP','Damage resolves only in the damage step.');
  try {
    if (defenderCounterPower > 0) state.battle.counterPower += defenderCounterPower;
    const r=resolveBattleDamageCore(state);
    const result={wins:r.status==='attack-won',attackerPower:r.attackPower,defenderPower:r.defensePower,...r};
    state.battle.result=result;
    return result;
  } catch(e) { if(e instanceof Error && e.code) throw new RuleError(e.code,e.message); throw e; }
}
export function endBattle(state) {
  assert(state.battle?.step==='end','WRONG_BATTLE_STEP','Advance to end step first.');
  try { finishBattle(state); } catch(e) { if(e instanceof Error && e.code) throw new RuleError(e.code,e.message); throw e; }
}

export function resolveEffect(state, effect, context={}) {
  assert(effect && typeof effect.handler==='string','INVALID_EFFECT','Effect requires a registered handler name.');
  const handler=getRuntimeEffectHandler(effect.handler);
  assert(handler,'UNSUPPORTED_EFFECT',`No implemented handler for effect: ${effect.handler}`);
  return handler(state,effect,context);
}
export function registerEffectHandler(name, handler) { try { return registerRuntimeEffectHandler(name, handler); } catch (e) { if (e instanceof Error && e.code && !(e instanceof RuleError)) throw new RuleError(e.code, e.message); throw e; } }
export function getImplementedEffectHandlers() { return Object.keys(getRuntimeEffectHandlers()).sort(); }
export function findCharacter(p,id) { return p.characters.find(c=>(c.instanceId ?? c.id)===id); }
