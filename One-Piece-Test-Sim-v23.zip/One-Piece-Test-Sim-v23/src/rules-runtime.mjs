import { processRuleCheckpoint } from './rule-processing.mjs';
/**
 * Brook Lab deterministic rules runtime layer.
 * Based on One Piece Card Game Comprehensive Rules v1.2.1 (2026-08-28).
 * This is an additive, testable kernel; it does NOT parse or implement every printed card effect.
 * Unknown card effects must remain unsupported rather than being guessed.
 */
export const RULES_VERSION = '1.2.1';
export const RULES_DATE = '2026-08-28';
export const TURN_PHASES = ['refresh', 'draw', 'don', 'main', 'end'];
const runtimeEffectHandlers = new Map();

export function registerRuntimeEffectHandler(name, handler) {
  requireRule(typeof name === 'string' && name.length > 0, 'BAD_HANDLER_NAME', 'Effect handler name is required.');
  requireRule(typeof handler === 'function', 'BAD_HANDLER', 'Effect handler must be a function.');
  runtimeEffectHandlers.set(name, handler);
  return handler;
}
export function getRuntimeEffectHandler(name) { return runtimeEffectHandlers.get(name) ?? null; }
export function getRuntimeEffectHandlers() { return Object.fromEntries(runtimeEffectHandlers.entries()); }

export class RuntimeRuleError extends Error {
  constructor(code, message) { super(message); this.name = 'RuntimeRuleError'; this.code = code; }
}
const requireRule = (ok, code, message) => { if (!ok) throw new RuntimeRuleError(code, message); };

export function createRuntimeState(players, firstPlayer = 0) {
  requireRule(Array.isArray(players) && players.length === 2, 'PLAYER_COUNT', 'Exactly two players are supported.');
  requireRule(firstPlayer === 0 || firstPlayer === 1, 'BAD_FIRST_PLAYER', 'First player must be index 0 or 1.');
  return {
    rulesVersion: RULES_VERSION,
    turn: 0,
    turnNumber: 0,
    turnPlayer: firstPlayer,
    firstPlayer,
    phase: 'setup',
    winner: null,
    gameResult: null,
    battle: null,
    pendingEffects: [],
    resolvingEffect: false,
    nextEffectId: 1,
    log: [],
    players: players.map((p, i) => ({
      id: p.id ?? `P${i + 1}`, leader: p.leader, deck: [...(p.deck ?? [])], hand: [...(p.hand ?? [])],
      life: [...(p.life ?? [])], trash: [...(p.trash ?? [])], characters: [...(p.characters ?? [])],
      stage: p.stage ?? null, donDeck: p.donDeck ?? 10, donActive: p.donActive ?? 0,
      donRested: p.donRested ?? 0, donAttached: p.donAttached ?? [], oncePerTurn: {},
      modifiers: [], flags: {}, turnFlags: {}, turnCount: 0, hasMulliganed: false, index: i
    }))
  };
}

export function beginTurn(state, playerIndex = state.turnPlayer) {
  requireRule(!state.winner && !state.gameResult, 'GAME_OVER', 'The game has ended.');
  requireRule(state.phase === 'setup' || state.phase === 'ready' || state.phase === 'between-turns', 'TURN_ALREADY_ACTIVE', 'A turn can begin only during setup or between turns.');
  const p = getPlayer(state, playerIndex);
  requireRule(playerIndex === state.turnPlayer, 'WRONG_TURN_PLAYER', 'Only the designated turn player may begin a turn.');
  state.turnNumber += 1;
  state.turn = state.turnNumber;
  p.turnCount += 1;
  p.oncePerTurn = {};
  p.flags = {};
  state.phase = 'refresh';
  // Refresh phase: active all cards in the turn player's field and return rested DON!!.
  p.donActive += p.donRested;
  p.donRested = 0;
  for (const c of p.characters) { c.rested = false; c.turnFlags = {}; }
  if (p.leader) p.leader.rested = false;
  if (p.stage) p.stage.rested = false;
  // Turn-duration effects expire at the start of their owner's next turn.
  p.modifiers = p.modifiers.filter(m => !(m.duration === 'until-start-of-your-next-turn' && m.createdTurn < p.turnCount));
  state.log.push({ type: 'phase', phase: 'refresh', player: p.id, turn: state.turnNumber });
  return state;
}

export function advancePhase(state) {
  requireRule(!state.winner && !state.gameResult, 'GAME_OVER', 'The game has ended.');
  const i = TURN_PHASES.indexOf(state.phase);
  requireRule(i >= 0 && i < TURN_PHASES.length - 1, 'BAD_PHASE', 'Cannot advance from this phase.');
  const next = TURN_PHASES[i + 1];
  const p = getPlayer(state, state.turnPlayer);
  state.phase = next;
  if (next === 'draw') {
    // CR 6: the first player does not draw during their first turn.
    if (!(p.index === state.firstPlayer && p.turnCount === 1)) drawCards(state, p.index, 1);
  } else if (next === 'don') {
    const amount = Math.min(p.index === state.firstPlayer && p.turnCount === 1 ? 1 : 2, p.donDeck);
    p.donDeck -= amount;
    p.donActive += amount;
    state.log.push({ type: 'don-gain', player: p.id, amount });
  } else if (next === 'end') {
    state.log.push({ type: 'phase', phase: 'end', player: p.id, turn: state.turnNumber });
  }
  state.log.push({ type: 'phase', phase: next, player: p.id, turn: state.turnNumber });
  return state;
}

export function endTurn(state) {
  requireRule(!state.winner && !state.gameResult, 'GAME_OVER', 'The game has ended.');
  requireRule(state.phase === 'end', 'WRONG_PHASE', 'A turn can end only during the End Phase.');
  const ended = getPlayer(state, state.turnPlayer);
  // DON!! attached to Leaders/Characters returns to the cost area rested at end of turn.
  let returnedDon = 0;
  for (const target of [ended.leader, ...ended.characters].filter(Boolean)) {
    const attached = Math.max(0, Number(target.attachedDon ?? 0));
    if (attached) {
      returnedDon += attached;
      target.attachedDon = 0;
    }
    if (Array.isArray(target.powerModifiers)) {
      target.powerModifiers = target.powerModifiers.filter(m => m.duration !== 'until-end-of-turn');
    }
  }
  ended.donRested += returnedDon;
  ended.donAttached = ended.donAttached.filter(entry => entry.attachedTurn !== ended.turnCount);
  ended.modifiers = ended.modifiers.filter(m => m.duration !== 'until-end-of-turn');
  if (returnedDon) state.log.push({ type: 'don-detach-cleanup', player: ended.id, amount: returnedDon, destination: 'rested' });
  state.log.push({ type: 'turn-end', player: ended.id, turn: state.turnNumber });
  state.turnPlayer = 1 - state.turnPlayer;
  state.phase = 'between-turns';
  return state;
}


/** Pay active DON!! by resting it during the Main Phase. */
export function payDon(state, playerIndex, amount) {
  requireRule(!state.winner && !state.gameResult, 'GAME_OVER', 'The game has ended.');
  requireRule(state.phase === 'main', 'WRONG_PHASE', 'DON!! can only be paid during the Main Phase.');
  requireRule(playerIndex === state.turnPlayer, 'NOT_TURN_PLAYER', 'Only the turn player may pay DON!!.');
  requireRule(Number.isInteger(amount) && amount >= 0, 'BAD_DON_COST', 'DON!! cost must be a non-negative integer.');
  const p = getPlayer(state, playerIndex);
  requireRule(p.donActive >= amount, 'INSUFFICIENT_DON', 'Not enough active DON!!.');
  p.donActive -= amount;
  p.donRested += amount;
  state.log.push({ type: 'don-pay', player: p.id, amount });
  return { donActive: p.donActive, donRested: p.donRested };
}

/** Attach active DON!! to a Leader or Character during the Main Phase. */
export function attachDon(state, playerIndex, targetRef, count = 1) {
  requireRule(!state.winner && !state.gameResult, 'GAME_OVER', 'The game has ended.');
  requireRule(state.phase === 'main', 'WRONG_PHASE', 'DON!! can only be attached during the Main Phase.');
  requireRule(playerIndex === state.turnPlayer, 'NOT_TURN_PLAYER', 'Only the turn player may attach DON!!.');
  requireRule(Number.isInteger(count) && count > 0, 'BAD_DON_COUNT', 'Attach count must be a positive integer.');
  const p = getPlayer(state, playerIndex);
  requireRule(p.donActive >= count, 'INSUFFICIENT_DON', 'Not enough active DON!!.');
  const ref = typeof targetRef === 'string' ? { id: targetRef } : targetRef;
  const target = ref?.type === 'leader'
    ? ((p.leader?.instanceId ?? p.leader?.id) === ref.id ? p.leader : null)
    : ref?.type === 'character'
      ? p.characters.find(c => (c.instanceId ?? c.id) === ref.id)
      : [p.leader, ...p.characters].find(c => c && (c.instanceId ?? c.id) === ref?.id);
  requireRule(Boolean(target), 'TARGET_NOT_FOUND', 'DON!! target must be your Leader or one of your Characters.');
  p.donActive -= count;
  target.attachedDon = Math.max(0, Number(target.attachedDon ?? 0)) + count;
  p.donAttached.push({ targetId: target.instanceId ?? target.id, count, ownerIndex: playerIndex, attachedTurn: p.turnCount });
  state.log.push({ type: 'don-attach', player: p.id, targetId: target.instanceId ?? target.id, count });
  return { target, attachedDon: target.attachedDon, donActive: p.donActive };
}

/** Apply a power modifier directly to a battle-engine entity. */
export function applyPowerModifier(state, playerIndex, targetRef, amount, duration = 'until-end-of-turn', operation = 'add') {
  requireRule(!state.winner && !state.gameResult, 'GAME_OVER', 'The game has ended.');
  requireRule(Number.isInteger(amount), 'BAD_MODIFIER_AMOUNT', 'Power modifier must be an integer.');
  requireRule(['add', 'set'].includes(operation), 'BAD_MODIFIER_OPERATION', 'Power modifier operation must be add or set.');
  const p = getPlayer(state, playerIndex);
  const ref = typeof targetRef === 'string' ? { id: targetRef } : targetRef;
  const target = ref?.type === 'leader'
    ? ((p.leader?.instanceId ?? p.leader?.id) === ref.id ? p.leader : null)
    : ref?.type === 'character'
      ? p.characters.find(c => (c.instanceId ?? c.id) === ref.id)
      : [p.leader, ...p.characters].find(c => c && (c.instanceId ?? c.id) === ref?.id);
  requireRule(Boolean(target), 'TARGET_NOT_FOUND', 'Power modifier target must be your Leader or one of your Characters.');
  target.powerModifiers ??= [];
  target.powerModifiers.push({ amount, operation, duration, createdTurn: p.turnCount, ownerIndex: playerIndex });
  state.log.push({ type: 'power-modifier', player: p.id, targetId: target.instanceId ?? target.id, amount, operation, duration });
  return target;
}

export function currentEntityPower(entity) {
  const base = Number(entity?.power ?? 0);
  const modified = (entity?.powerModifiers ?? []).reduce((value, modifier) => {
    if (modifier.operation === 'set') return modifier.amount;
    if (modifier.operation === 'multiply') return value * modifier.amount;
    return value + Number(modifier.amount ?? 0);
  }, base);
  return modified + Math.max(0, Number(entity?.attachedDon ?? 0)) * 1000;
}

export function drawCards(state, playerIndex, count = 1) {
  requireRule(!state.winner && !state.gameResult, 'GAME_OVER', 'The game has ended.');
  const p = getPlayer(state, playerIndex);
  requireRule(Number.isInteger(count) && count >= 0, 'BAD_DRAW_COUNT', 'Draw count must be a non-negative integer.');
  let drawn = 0;
  for (let i = 0; i < count; i++) {
    if (!p.deck.length) {
      const result = processRuleCheckpoint(state);
      return { drawn, deckout: true, result };
    }
    p.hand.push(p.deck.shift());
    drawn++;
    // Deck-out is checked at the rule-processing checkpoint immediately after
    // the action that empties the deck, not only before a later draw attempt.
    const result = processRuleCheckpoint(state);
    if (result.status === 'win' || result.status === 'draw') return { drawn, deckout: true, result };
  }
  state.log.push({ type: 'draw', player: p.id, count: drawn });
  return { drawn, deckout: false };
}

export function enqueueTriggeredEffect(state, { controller, sourceId, timing, effect, optional = false, timestamp }) {
  requireRule(!state.winner && !state.gameResult, 'GAME_OVER', 'The game has ended.');
  requireRule(controller === 0 || controller === 1, 'BAD_CONTROLLER', 'Effect controller must be player index 0 or 1.');
  requireRule(typeof timing === 'string' && timing, 'MISSING_TIMING', 'Effect timing is required.');
  requireRule(effect && typeof effect.handler === 'string', 'UNSUPPORTED_EFFECT', 'Effect must have an explicitly registered handler.');
  const entry = { id: state.nextEffectId++, controller, sourceId, timing, effect, optional, timestamp: timestamp ?? state.log.length, status: 'pending' };
  state.pendingEffects.push(entry);
  // CR 8.6: turn player's simultaneous effects resolve before non-turn player's effects.
  state.pendingEffects.sort((a, b) => {
    const aTurn = a.controller === state.turnPlayer ? 0 : 1;
    const bTurn = b.controller === state.turnPlayer ? 0 : 1;
    return aTurn - bTurn || a.timestamp - b.timestamp || a.id - b.id;
  });
  state.log.push({ type: 'effect-queued', effectId: entry.id, controller: state.players[controller].id, timing });
  return entry;
}

export function resolveNextEffect(state, handlers = getRuntimeEffectHandlers(), context = {}) {
  requireRule(!state.winner && !state.gameResult, 'GAME_OVER', 'The game has ended.');
  requireRule(!state.resolvingEffect, 'REENTRANT_RESOLUTION', 'Effect resolution is already in progress.');
  const entry = state.pendingEffects.find(e => e.status === 'pending');
  if (!entry) return { resolved: false, reason: 'queue-empty' };
  const handler = handlers instanceof Map ? handlers.get(entry.effect.handler) : handlers?.[entry.effect.handler];
  requireRule(typeof handler === 'function', 'UNSUPPORTED_EFFECT', `No implemented handler for effect '${entry.effect.handler}'.`);
  state.resolvingEffect = true;
  entry.status = 'resolving';
  try {
    const result = handler(state, entry.effect, { ...context, controller: entry.controller, sourceId: entry.sourceId, timing: entry.timing });
    entry.status = 'resolved';
    state.log.push({ type: 'effect-resolved', effectId: entry.id, handler: entry.effect.handler });
    const checkpoint = processRuleCheckpoint(state);
    return { resolved: true, entry, result, checkpoint };
  } catch (error) {
    entry.status = 'pending';
    throw error;
  } finally {
    state.resolvingEffect = false;
  }
}

export function addModifier(state, target, modifier) {
  requireRule(!state.winner && !state.gameResult, 'GAME_OVER', 'The game has ended.');
  requireRule(target && typeof target === 'object', 'BAD_TARGET', 'Modifier target is required.');
  requireRule(modifier && ['power', 'cost', 'life', 'counter'].includes(modifier.stat), 'BAD_MODIFIER_STAT', 'Unsupported modifier stat.');
  requireRule(Number.isFinite(modifier.amount), 'BAD_MODIFIER_AMOUNT', 'Modifier amount must be numeric.');
  const ownerIndex = modifier.ownerIndex ?? state.turnPlayer;
  const owner = getPlayer(state, ownerIndex);
  const record = { ...modifier, targetId: target.instanceId ?? target.id, createdTurn: owner.turnCount, createdBy: modifier.createdBy ?? null };
  owner.modifiers.push(record);
  if (modifier.stat === 'power') {
    target.powerModifiers ??= [];
    target.powerModifiers.push({ amount: modifier.amount, operation: modifier.operation === 'set' ? 'set' : 'add', duration: modifier.duration, createdTurn: owner.turnCount, ownerIndex });
  }
  return record;
}

export function calculateModifiedValue(baseValue, modifiers, { stat, targetId, round = false } = {}) {
  let value = baseValue;
  for (const m of modifiers ?? []) {
    if (m.stat !== stat || (m.targetId != null && m.targetId !== targetId)) continue;
    if (m.operation === 'set') value = m.amount;
    else if (m.operation === 'multiply') value *= m.amount;
    else value += m.amount;
  }
  if (stat !== 'power') value = Math.max(0, value);
  return round ? Math.trunc(value) : value;
}

export function applyLifeDamage(state, defenderIndex, { banish = false, triggerDecider = () => false, resolveTrigger = () => {} } = {}) {
  requireRule(!state.winner && !state.gameResult, 'GAME_OVER', 'The game has ended.');
  const p = getPlayer(state, defenderIndex);
  if (p.life.length === 0) {
    const result = processRuleCheckpoint(state, { pendingLeaderDamage: [defenderIndex] });
    state.log.push({ type: 'defeat-check', loser: p.id, reason: 'leader-damage-at-zero-life', result });
    return { defeated: true, cardsProcessed: 0, result };
  }
  const card = p.life.shift();
  if (banish) {
    p.trash.push(card);
    state.log.push({ type: 'life-banish', player: p.id, card });
    processRuleCheckpoint(state);
    return { defeated: Boolean(state.winner || state.gameResult), cardsProcessed: 1, triggerActivated: false, banished: true };
  }
  const hasTrigger = Boolean(card?.trigger || card?.keywords?.includes('Trigger'));
  if (hasTrigger && triggerDecider(card, p.index)) {
    resolveTrigger(card, state, p.index);
    // Trigger effects that play/move the card own that move; otherwise it goes to Trash.
    const same = x => x === card || (x && card && (x.instanceId ?? x.id) != null && (x.instanceId ?? x.id) === (card.instanceId ?? card.id));
    const moved = p.hand.some(same) || p.deck.some(same) || p.life.some(same) || p.trash.some(same) || p.characters.some(same) || same(p.leader) || same(p.stage);
    if (!moved) p.trash.push(card);
    state.log.push({ type: 'trigger', player: p.id, card });
    processRuleCheckpoint(state);
    return { defeated: Boolean(state.winner || state.gameResult), cardsProcessed: 1, triggerActivated: true };
  }
  p.hand.push(card);
  state.log.push({ type: 'life-to-hand', player: p.id, card });
  processRuleCheckpoint(state);
  return { defeated: Boolean(state.winner || state.gameResult), cardsProcessed: 1, triggerActivated: false };
}

export function resolveLeaderDamage(state, defenderIndex, { doubleAttack = false, banish = false, triggerDecider, resolveTrigger } = {}) {
  requireRule(!state.winner && !state.gameResult, 'GAME_OVER', 'The game has ended.');
  const first = applyLifeDamage(state, defenderIndex, { banish, triggerDecider, resolveTrigger });
  if (first.defeated || !doubleAttack) return { ...first, doubleAttack, totalLifeCardsProcessed: first.cardsProcessed };
  // Double Attack processes the second Life card separately; triggers can resolve between damage checks.
  if (state.winner) return { ...first, doubleAttack, totalLifeCardsProcessed: first.cardsProcessed };
  const second = applyLifeDamage(state, defenderIndex, { banish, triggerDecider, resolveTrigger });
  return { ...second, doubleAttack, totalLifeCardsProcessed: first.cardsProcessed + second.cardsProcessed, firstDamage: first };
}

export function useOncePerTurn(state, playerIndex, key) {
  requireRule(!state.winner && !state.gameResult, 'GAME_OVER', 'The game has ended.');
  const p = getPlayer(state, playerIndex);
  requireRule(!p.oncePerTurn[key], 'ONCE_PER_TURN_USED', `Once-per-turn limit already used: ${key}`);
  p.oncePerTurn[key] = true;
}

export function validateDeckStrict({ deck, leader, cardDatabase, banned = new Set(), restricted = new Map(), donCount = 10 }) {
  requireRule(leader && leader.category === 'Leader', 'LEADER_REQUIRED', 'A leader card is required.');
  requireRule(Array.isArray(deck) && deck.length === 50, 'DECK_SIZE', 'Main deck must contain exactly 50 cards.');
  requireRule(donCount === 10, 'DON_DECK_SIZE', 'DON!! deck must contain exactly 10 cards.');
  const counts = new Map();
  for (const id of deck) {
    const card = cardDatabase?.[id];
    requireRule(card, 'UNKNOWN_CARD', `Card '${id}' is missing from the loaded database; legality cannot be verified.`);
    requireRule(card.category !== 'Leader' && card.category !== 'DON!!', 'INVALID_MAIN_DECK_CARD', `Card '${id}' cannot be in the main deck.`);
    counts.set(id, (counts.get(id) ?? 0) + 1);
    requireRule(counts.get(id) <= 4, 'COPY_LIMIT', `More than four copies of ${id}.`);
    requireRule(!banned.has(id), 'BANNED_CARD', `${id} is banned in the selected format.`);
    if (restricted.has(id)) requireRule(counts.get(id) <= restricted.get(id), 'RESTRICTED_CARD', `${id} exceeds the selected restricted limit.`);
    requireRule(card.colors?.some(c => leader.colors?.includes(c)), 'COLOR_RESTRICTION', `${id} is outside the leader's color identity.`);
  }
  return { valid: true, cards: 50, unique: counts.size, rulesVersion: RULES_VERSION };
}

function getPlayer(state, index) {
  requireRule(Number.isInteger(index) && index >= 0 && index < 2, 'BAD_PLAYER', 'Player index must be 0 or 1.');
  return state.players[index];
}
