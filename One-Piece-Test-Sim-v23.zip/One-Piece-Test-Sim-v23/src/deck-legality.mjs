/** Core deck construction checks for One Piece Test Sim.
 * Data records are expected to use cardId, name, category, colors.
 * This module checks the known global banned/restricted list snapshot, but is not
 * a substitute for event-specific rules or a judge ruling.
 */
export const canonicalCardNumber = (id) => String(id ?? '').trim().replace(/_p\d+$/i, '');
const isLeader = c => String(c?.category ?? '').toLowerCase() === 'leader';
const isMainDeckCard = c => ['character', 'event', 'stage'].includes(String(c?.category ?? '').toLowerCase());
const colorsOf = c => Array.isArray(c?.colors) ? c.colors : [];

export function validateDeck({leaderId, mainDeck = [], cardsById, legality}) {
  const errors = [], warnings = [];
  const lookup = id => cardsById instanceof Map ? cardsById.get(id) : cardsById?.[id];
  const leader = leaderId ? lookup(leaderId) : null;
  if (!leaderId || !leader) errors.push({code:'leader.missing', message:'Select one valid Leader from the imported card database.'});
  else if (!isLeader(leader)) errors.push({code:'leader.category', message:`${leader.cardId} is not categorized as a Leader in the imported database.`});

  if (mainDeck.length !== 50) errors.push({code:'deck.size', message:`Main deck must contain exactly 50 cards; currently ${mainDeck.length}.`});

  const counts = new Map();
  for (const id of mainDeck) {
    const card = lookup(id);
    if (!card) { errors.push({code:'card.unknown', cardId:id, message:`Card ${id} is not in the imported database.`}); continue; }
    if (!isMainDeckCard(card)) errors.push({code:'card.category', cardId:id, message:`${id} is a ${card.category} and cannot be included in the 50-card main deck.`});
    const num = canonicalCardNumber(card.cardId || id);
    counts.set(num, (counts.get(num) || 0) + 1);
    if (leader && colorsOf(card).some(color => !colorsOf(leader).includes(color))) {
      errors.push({code:'card.color', cardId:id, message:`${id} has color ${colorsOf(card).filter(color => !colorsOf(leader).includes(color)).join('/')} not present on Leader ${leader.cardId}.`});
    }
  }
  for (const [id, count] of counts) if (count > 4) errors.push({code:'card.copy-limit', cardId:id, message:`${id} has ${count} copies; maximum is 4 per card number (parallel printings share the limit).`});

  const allIds = [...(leaderId ? [leaderId] : []), ...mainDeck].map(canonicalCardNumber);
  const banned = new Set((legality?.banned || []).map(x => canonicalCardNumber(x.id)));
  const restricted = new Map((legality?.restricted || []).map(x => [canonicalCardNumber(x.id), x.maxCopies ?? 1]));
  for (const id of allIds) if (banned.has(id)) {
    const item = (legality?.banned || []).find(x => canonicalCardNumber(x.id) === id);
    errors.push({code:'card.banned', cardId:id, message:`${item?.name || id} (${id}) is banned under the loaded format snapshot.`});
  }
  for (const [id, max] of restricted) {
    const count = counts.get(id) || 0;
    if (count > max) errors.push({code:'card.restricted', cardId:id, message:`${id} is restricted to ${max} main-deck copy/copies; found ${count}.`});
  }
  const included = new Set(allIds);
  for (const pair of legality?.bannedPairs || []) {
    const a = canonicalCardNumber(pair.a), b = canonicalCardNumber(pair.b);
    if (included.has(a) && included.has(b)) errors.push({code:'card.banned-pair', message:`Banned pair: ${pair.aName || a} (${a}) cannot be in the same deck as ${pair.bName || b} (${b}).`});
  }
  if (leader && !isLeader(leader)) warnings.push('Leader record category is not trusted; check this card in the official card list.');
  if (!legality) warnings.push('No legality snapshot was loaded; ban/restriction checks were not run.');
  return {legal: errors.length === 0, errors, warnings, mainDeckCount:mainDeck.length, distinctMainDeckCards:counts.size, leader:leader || null, legalityEffectiveDate:legality?.effectiveDate || null};
}
