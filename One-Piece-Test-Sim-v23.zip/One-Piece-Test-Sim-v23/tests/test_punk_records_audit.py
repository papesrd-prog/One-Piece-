import importlib.util, json, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('audit_punk_records',ROOT/'tools/audit_punk_records.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

class PunkRecordsAuditTests(unittest.TestCase):
    def test_real_snapshot_has_expected_unique_id_and_duplicate(self):
        report, cards=mod.audit(ROOT/'data/punk_records_import/punk_records_cards.normalized.jsonl')
        self.assertEqual(report['sourceRows'],4911)
        self.assertEqual(report['uniqueCardIds'],4910)
        self.assertEqual(report['duplicateCardIds'],{'OP07-091_p1':2})
        self.assertEqual(len(cards),4910)
        self.assertEqual(report['missingRequiredFields']['cardId'],0)

    def test_audit_handles_duplicate_source_rows_without_double_counting_lookup(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'tiny.jsonl'
            rows=[{'cardId':'X-001','name':'Test','category':'Leader','colors':['Green'],'effectText':'-','setCode':'S','sourceFile':'a','verificationStatus':'unverified','implementedEffectStatus':'not-started'}, {'cardId':'X-001','name':'Test','category':'Leader','colors':['Green'],'effectText':'-','setCode':'S','sourceFile':'b','verificationStatus':'unverified','implementedEffectStatus':'not-started'}]
            p.write_text('\n'.join(json.dumps(r) for r in rows),encoding='utf8')
            report,cards=mod.audit(p)
            self.assertEqual(report['sourceRows'],2); self.assertEqual(report['uniqueCardIds'],1); self.assertEqual(len(cards),1)

if __name__=='__main__': unittest.main()
