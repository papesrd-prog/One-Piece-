import test from 'node:test';
import assert from 'node:assert/strict';
import {createGame, validateDeck, startTurn, payDon, legalAttackTargets, declareAttack, advanceBattle, resolveBattleDamage, endBattle, resolveEffect, registerEffectHandler, RuleError} from '../src/rules-engine.mjs';
import { executeUnifiedAction } from '../src/unified-game-engine.mjs';
import { enqueueTriggeredEffect } from '../src/rules-runtime.mjs';
const leader={id:'L',category:'Leader',colors:['Green'],power:5000};
const mkDeck=(prefix='C')=>Array.from({length:50},(_,i)=>`${prefix}${i}`);
const players=()=>[{id:'A',leader,deck:mkDeck('A')},{id:'B',leader,deck:mkDeck('B')}];
const rng=()=>0.5;
const throwsCode=(fn,code)=>assert.throws(fn,e=>e instanceof RuleError&&e.code===code);
test('deck validation accepts 50 cards and rejects wrong size',()=>{assert.equal(validateDeck(mkDeck(),leader).valid,true);throwsCode(()=>validateDeck(mkDeck().slice(1),leader),'DECK_SIZE')});
test('deck validation rejects more than four copies',()=>throwsCode(()=>validateDeck(Array(50).fill('X'),leader),'COPY_LIMIT'));
test('setup deals 5 cards and 5 life to each player',()=>{const s=createGame({players:players(),random:rng});for(const p of s.players){assert.equal(p.hand.length,5);assert.equal(p.life.length,5);assert.equal(p.deck.length,40)}});
test('first player gets one DON and skips first draw',()=>{const s=createGame({players:players(),random:rng});const before=s.players[0].hand.length;startTurn(s,0);assert.equal(s.players[0].donActive,1);assert.equal(s.players[0].hand.length,before)});
test('second player receives two DON and draws',()=>{const s=createGame({players:players(),random:rng});startTurn(s,0);startTurn(s,1);assert.equal(s.players[1].donActive,2);assert.equal(s.players[1].hand.length,6)});
test('cannot pay more DON than available',()=>{const s=createGame({players:players(),random:rng});startTurn(s,0);throwsCode(()=>payDon(s,0,2),'INSUFFICIENT_DON')});
test('attack targets include leader and only rested characters',()=>{const s=createGame({players:players(),random:rng});s.players[1].characters=[{instanceId:'ready',power:3000,rested:false},{instanceId:'rested',power:3000,rested:true}];const t=legalAttackTargets(s,0,{power:5000});assert.deepEqual(t.map(x=>x.id),['L','rested'])});
test('attack rejects active character target',()=>{const s=createGame({players:players(),random:rng});startTurn(s,0);startTurn(s,1);startTurn(s,0);s.players[1].characters=[{instanceId:'ready',power:3000,rested:false}];throwsCode(()=>declareAttack(s,0,{type:'leader',id:'L'},{type:'character',id:'ready'}),'ILLEGAL_TARGET')});
test('battle steps must be in order and successful attack damages life',()=>{const s=createGame({players:players(),random:rng});startTurn(s,0);startTurn(s,1);startTurn(s,0);s.players[0].leader.power=6000;declareAttack(s,0,{type:'leader',id:'L'},{type:'leader',id:'L'});throwsCode(()=>advanceBattle(s,'counter'),'BATTLE_STEP_ORDER');advanceBattle(s,'block');advanceBattle(s,'counter');advanceBattle(s,'damage');const before=s.players[1].life.length;assert.equal(resolveBattleDamage(s,0).wins,true);assert.equal(s.players[1].life.length,before-1);advanceBattle(s,'end');endBattle(s);assert.equal(s.phase,'main')});
test('unsupported card effect fails closed instead of guessing',()=>{const s=createGame({players:players(),random:rng});throwsCode(()=>resolveEffect(s,{handler:'unknown-card-effect'}),'UNSUPPORTED_EFFECT')});


test('legacy public game factory now produces state accepted by the unified runtime',()=>{
  const s=createGame({players:players(),random:rng});
  assert.equal(s.phase,'ready'); assert.equal(s.turnNumber,0);
  executeUnifiedAction(s,{type:'begin-turn'});
  executeUnifiedAction(s,{type:'advance-phase'});
  executeUnifiedAction(s,{type:'advance-phase'});
  executeUnifiedAction(s,{type:'advance-phase'});
  assert.equal(s.phase,'main'); assert.equal(s.players[0].donActive,1);
  assert.equal(s.players[0].hand.length,5);
});

test('registered effect handlers are shared by direct and queued unified resolution',()=>{
  const s=createGame({players:players(),random:rng});
  registerEffectHandler('v22-shared-handler',(state,_effect,ctx)=>{state.players[ctx.controller].hand.push('shared-effect-marker');return {ok:true};});
  enqueueTriggeredEffect(s,{controller:0,timing:'test-window',effect:{handler:'v22-shared-handler'}});
  const result=executeUnifiedAction(s,{type:'resolve-next-effect'});
  assert.equal(result.resolved,true);
  assert.ok(s.players[0].hand.includes('shared-effect-marker'));
  assert.deepEqual(s.pendingEffects.map(e=>e.status),['resolved']);
});
