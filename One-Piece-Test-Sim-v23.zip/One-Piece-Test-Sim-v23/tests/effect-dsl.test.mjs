import test from 'node:test';
import assert from 'node:assert/strict';
import { resolveEffectDsl, EffectDslError } from '../src/effect-dsl.mjs';

function state() {
  return { turnPlayer:0, log:[], players:[
    {id:'P1', deck:['D1','D2'], hand:[], life:['L1'], trash:[], leader:{id:'LDR1',power:5000}, characters:[{instanceId:'C1',cardId:'OP01-001',power:3000,rested:false}], donActive:2, donAttached:[]},
    {id:'P2', deck:['E1'], hand:[], life:['L2'], trash:[], leader:{id:'LDR2',power:5000}, characters:[{instanceId:'C2',cardId:'OP01-002',power:4000,rested:true}], donActive:0, donAttached:[]}
  ]};
}

test('effect DSL resolves ordered draw, rest and power actions', () => {
  const s=state();
  const result=resolveEffectDsl(s,{actions:[{op:'draw',count:1},{op:'rest',targetId:'C2'},{op:'power-modifier',target:'leader',amount:1000}]},{controller:0,effectId:'test-1'});
  assert.equal(s.players[0].hand[0],'D1');
  assert.equal(s.players[1].characters[0].rested,true);
  assert.equal(s.players[0].leader.modifiers[0].amount,1000);
  assert.equal(s.players[0].leader.powerModifiers[0].amount,1000);
  assert.equal(s.players[0].leader.powerModifiers[0].duration,'until-end-of-turn');
  assert.equal(result.results.length,3);
});

test('effect DSL spends and attaches DON!!', () => {
  const s=state(); resolveEffectDsl(s,{actions:[{op:'attach-don',target:'leader',count:2}]},{controller:0});
  assert.equal(s.players[0].donActive,0); assert.equal(s.players[0].leader.attachedDon,2);
});

test('effect DSL rejects unimplemented actions rather than guessing', () => {
  assert.throws(()=>resolveEffectDsl(state(),{actions:[{op:'search-deck'}]}),e=>e instanceof EffectDslError && e.code==='UNSUPPORTED_ACTION');
});

test('effect DSL requires explicit discard choices', () => {
  assert.throws(()=>resolveEffectDsl(state(),{actions:[{op:'trash-from-hand'}]}),e=>e instanceof EffectDslError && e.code==='CHOICE_REQUIRED');
});

test('effect DSL applies available actions when a later action is impossible only if represented by no-op', () => {
  const s=state();
  const r=resolveEffectDsl(s,{actions:[{op:'life-to-hand',player:'opponent',count:3}]},{controller:0});
  assert.equal(r.results[0].moved,1); assert.equal(s.players[1].life.length,0);
});


test('drawing the last deck card in a card effect causes immediate deck-out', () => {
  const s = state();
  s.players[0].deck = ['last'];
  s.players[1].deck = ['other'];
  const r = resolveEffectDsl(s, {actions:[{op:'draw',count:2}]}, {controller:0});
  assert.equal(r.results[0].drawn, 1);
  assert.equal(s.winner, 'P2');
  assert.equal(s.phase, 'ended');
});

test('legal target query filters by owner, cost, power and rested state', async () => {
  const { getLegalCharacterTargets } = await import('../src/effect-dsl.mjs');
  const s = state();
  s.players[0].characters[0].cost = 5;
  s.players[1].characters[0].cost = 3;
  const targets = getLegalCharacterTargets(s, 0, { player: 'opponent', costAtMost: 3, powerAtMost: 4000, rested: true });
  assert.deepEqual(targets.map(t => t.instanceId), ['C2']);
  assert.deepEqual(getLegalCharacterTargets(s, 0, { player: 'own', costAtMost: 3 }), []);
});

test('effect KO checks target restrictions and KO protection before moving a Character', () => {
  const s = state();
  s.players[1].characters[0].cost = 4;
  assert.throws(() => resolveEffectDsl(s, { actions: [{ op: 'ko', targetId: 'C2', player: 'opponent', costAtMost: 3 }] }, { controller: 0 }),
    e => e instanceof EffectDslError && e.code === 'ILLEGAL_TARGET');
  s.players[1].characters[0].cannotBeKO = true;
  assert.throws(() => resolveEffectDsl(s, { actions: [{ op: 'ko', targetId: 'C2', player: 'opponent' }] }, { controller: 0 }),
    e => e instanceof EffectDslError && e.code === 'KO_PROHIBITED');
  assert.equal(s.players[1].characters.length, 1);
  assert.equal(s.players[1].trash.length, 0);
});

test('effect KO supports explicit multi-target choices and refuses duplicate or excess targets', () => {
  const s = state();
  s.players[1].characters.push({ instanceId: 'C3', cardId: 'OP02-003', cost: 2, power: 2000 });
  const r = resolveEffectDsl(s, { actions: [{ op: 'ko', targetIds: ['C2', 'C3'], player: 'opponent', maxTargets: 2 }] }, { controller: 0 });
  assert.equal(r.results[0].moved, 2);
  assert.equal(s.players[1].characters.length, 0);
  assert.equal(s.players[1].trash.length, 2);
  assert.throws(() => resolveEffectDsl(state(), { actions: [{ op: 'ko', targetIds: ['C2', 'C2'] }] }, { controller: 0 }),
    e => e instanceof EffectDslError && e.code === 'DUPLICATE_TARGET');
});

test('return-to-hand applies target restrictions and separate removal protection', () => {
  const s = state();
  s.players[1].characters[0].cost = 2;
  s.players[1].characters[0].cannotBeKO = true;
  resolveEffectDsl(s, { actions: [{ op: 'return-to-hand', targetId: 'C2', player: 'opponent', costAtMost: 2 }] }, { controller: 0 });
  assert.equal(s.players[1].characters.length, 0);
  assert.equal(s.players[1].hand[0], 'OP01-002');

  const protectedState = state();
  protectedState.players[1].characters[0].cannotBeRemovedFromField = true;
  assert.throws(() => resolveEffectDsl(protectedState, { actions: [{ op: 'return-to-hand', targetId: 'C2', player: 'opponent' }] }, { controller: 0 }),
    e => e instanceof EffectDslError && e.code === 'RETURN_PROHIBITED');
});

test('multi-target removal validates all selected targets before moving any card', () => {
  const s = state();
  s.players[1].characters.push({ instanceId: 'C3', cardId: 'OP02-003', cost: 2, power: 2000, cannotBeKO: true });
  assert.throws(() => resolveEffectDsl(s, { actions: [{ op: 'ko', targetIds: ['C2', 'C3'], player: 'opponent' }] }, { controller: 0 }),
    e => e instanceof EffectDslError && e.code === 'KO_PROHIBITED');
  assert.deepEqual(s.players[1].characters.map(c => c.instanceId), ['C2', 'C3']);
  assert.equal(s.players[1].trash.length, 0);
});
