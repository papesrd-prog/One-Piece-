import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from import_scrydex import headers, normalized_card, import_cards

class FakeResponse:
    def __init__(self, data, page, total):
        self.data, self.page, self.total = data, page, total
        self.content = json.dumps({'data': data, 'page': page, 'pageSize': len(data), 'totalCount': total}).encode()
    def raise_for_status(self): pass
    def json(self): return {'data': self.data, 'page': self.page, 'pageSize': len(self.data), 'totalCount': self.total}
class FakeSession:
    def __init__(self): self.calls=[]
    def get(self, url, params, headers, timeout):
        self.calls.append((url,params,headers))
        page=params['page']
        sample={'id':f'OP01-{page:03d}','name':f'Card {page}','printed_number':f'OP01-{page:03d}','rules':['[On Play] Draw 1 card.'],'expansion':{'id':'OP01'},'language':'English'}
        return FakeResponse([sample] if page <= 2 else [],page,2)

def test_headers_use_scrydex_expected_names():
    h=headers('key-value','team-value')
    assert h['X-Api-Key']=='key-value' and h['X-Team-ID']=='team-value'

def test_normalize_preserves_full_rules_and_raw_record():
    raw={'id':'OP01-001','name':'Luffy','rules':['[Rush]','[On Play] Draw 1.'],'colors':['Red'],'expansion':{'id':'OP01'}}
    card=normalized_card(raw,'https://example.test/cards','2026-10-23T00:00:00+00:00')
    assert card['cardId']=='OP01-001'
    assert card['rulesText']=='[Rush]\n[On Play] Draw 1.'
    assert card['rawSourceRecord']==raw
    assert card['verificationStatus']=='third_party_data_imported_not_officially_verified'

def test_importer_paginates_and_writes_auditable_outputs(tmp_path):
    status=import_cards(FakeSession(),'key','team','/cards',tmp_path,page_size=1,delay=0)
    assert status['recordsImported']==2
    assert status['uniqueCardIds']==2
    assert status['completePagination'] is True
    assert status['recordsOfficiallyVerified']==0
    assert (tmp_path/'scrydex_cards.normalized.jsonl').exists()
    assert (tmp_path/'scrydex_cards.normalized.csv').exists()
    assert (tmp_path/'scrydex_import_status.json').exists()
