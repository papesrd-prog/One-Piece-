import test from 'node:test';
import assert from 'node:assert/strict';
import {validateDeck, canonicalCardNumber} from '../src/deck-legality.mjs';
const colors=['Green'];
const data = {
 'LEADER-G':{cardId:'LEADER-G',name:'Green Leader',category:'Leader',colors},
 'R-1':{cardId:'R-1',name:'Red Character',category:'Character',colors:['Red'],cost:2},
 'OP14-020':{cardId:'OP14-020',name:'Dracule Mihawk',category:'Leader',colors},
 'OP14-020_p1':{cardId:'OP14-020_p1',name:'Dracule Mihawk Parallel',category:'Leader',colors},
 'OP07-115':{cardId:'OP07-115',name:'I Re-Quasar Helllp!!',category:'Event',colors:['Green']},
 'EB04-058':{cardId:'EB04-058',name:'Borsalino',category:'Character',colors:['Green']}
};
for(let i=1;i<=13;i++) data[`G-${i}`]={cardId:`G-${i}`,name:`Green Card ${i}`,category:'Character',colors,cost:2};
const legality={effectiveDate:'2026-10-12',banned:[{id:'OP14-020',name:'Dracule Mihawk'}],restricted:[],bannedPairs:[{a:'OP07-115',aName:'I Re-Quasar Helllp!!',b:'EB04-058',bName:'Borsalino'}]};
const validDeck=()=>[...Array.from({length:12},(_,i)=>`G-${i+1}`).flatMap(id=>Array(4).fill(id)), 'G-13','G-13'];
test('accepts a 50-card same-color main deck and a valid leader',()=>{const r=validateDeck({leaderId:'LEADER-G',mainDeck:validDeck(),cardsById:data,legality});assert.equal(r.legal,true);assert.equal(r.errors.length,0)});
test('checks main deck size',()=>{const r=validateDeck({leaderId:'LEADER-G',mainDeck:validDeck().slice(1),cardsById:data,legality});assert.ok(r.errors.some(x=>x.code==='deck.size'))});
test('rejects off-color cards',()=>{const d=validDeck();d[0]='R-1';const r=validateDeck({leaderId:'LEADER-G',mainDeck:d,cardsById:data,legality});assert.ok(r.errors.some(x=>x.code==='card.color'))});
test('rejects over four copies by card number',()=>{const d=validDeck();d[0]='G-13';d[1]='G-13';d[2]='G-13';const r=validateDeck({leaderId:'LEADER-G',mainDeck:d,cardsById:data,legality});assert.ok(r.errors.some(x=>x.code==='card.copy-limit'))});
test('parallel printing uses same copy limit identity',()=>assert.equal(canonicalCardNumber('OP14-020_p1'),'OP14-020'));
test('banned leader and banned pairs are caught',()=>{const d=[...Array(48).fill('G-1'),'OP07-115','EB04-058'];const r=validateDeck({leaderId:'OP14-020_p1',mainDeck:d,cardsById:data,legality});assert.ok(r.errors.some(x=>x.code==='card.banned'));assert.ok(r.errors.some(x=>x.code==='card.banned-pair'))});
test('leaders cannot be placed in main deck',()=>{const d=validDeck();d[0]='LEADER-G';const r=validateDeck({leaderId:'LEADER-G',mainDeck:d,cardsById:data,legality});assert.ok(r.errors.some(x=>x.code==='card.category'))});
