import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { deriveOpponentProfile, validateOpponentDeck, parseOpponentDeckText } from '../src/opponent-decks.mjs';
const pool=JSON.parse(fs.readFileSync(new URL('../data/opponent-decks.json',import.meta.url),'utf8'));
const records=JSON.parse(fs.readFileSync(new URL('../data/punk_records_import/cards.browser.json',import.meta.url),'utf8'));
const byId=new Map(records.map(c=>[c.cardId,c]));
const legality=JSON.parse(fs.readFileSync(new URL('../data/format-legality-global-2026-10-12.json',import.meta.url),'utf8'));
test('five published tournament decks have 50 cards and sources',()=>{
 assert.equal(pool.decks.length,5);
 for(const d of pool.decks){assert.equal(d.mainDeck.length,50,d.id);assert.ok(d.source.startsWith('https://'));assert.ok(byId.has(d.leaderId));}
});
test('published decks pass local snapshot validation and resolve all cards',()=>{
 for(const d of pool.decks){const v=validateOpponentDeck(d,byId,legality);assert.equal(v.legal,true,`${d.id}: ${v.errors.map(e=>e.message).join('; ')}`);assert.equal(v.mainDeckCount,50);assert.ok(d.mainDeck.every(id=>byId.has(id)),d.id);}
});
test('Mihawk is excluded from all opponent lists',()=>{
 for(const d of pool.decks){assert.notEqual(d.leaderId,'OP14-020');assert.ok(!d.mainDeck.includes('OP14-020'));}
});
test('deck-derived profiles are deterministic and caveated',()=>{
 const a=deriveOpponentProfile(pool.decks[0],byId),b=deriveOpponentProfile(pool.decks[0],byId);
 assert.deepEqual(a,b);assert.equal(a.listSize,50);assert.ok(a.hit>=.28&&a.hit<=.78);assert.ok(a.remove>=.08&&a.remove<=.72);assert.match(a.caveat,/not played individually/i);
});
test('two source transcriptions with omitted quantity markers are explicitly flagged',()=>{
 assert.equal(pool.decks.filter(d=>d.provisionalSourceTranscription).length,3); // Sabo, Rocks, and Enel have one or more inferred count markers.
});

test('pasted deck parser supports quantity-first and ID-first lines',()=>{
 const parsed=parseOpponentDeckText('4x OP17-039 Rocks D. Xebec\nOP17-045 x2 Kyo\nST01-001 Monkey.D.Luffy');
 assert.deepEqual(parsed.unparsed,[]);assert.equal(parsed.total,7);assert.deepEqual(parsed.mainDeck.slice(0,4),['OP17-039','OP17-039','OP17-039','OP17-039']);assert.deepEqual(parsed.mainDeck.slice(4),['OP17-045','OP17-045','ST01-001']);
});
