import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeDeckExport, inferSimulationCard, inferSimulationCardMap } from '../src/deck-import.mjs';
const cards = new Map([
 ['OP15-022',{cardId:'OP15-022',name:'Brook',category:'Leader',colors:['Green','Black'],cost:null,power:5000}],
 ['OP17-081',{cardId:'OP17-081',name:'Gerd',category:'Character',colors:['Green'],cost:2,power:3000,counter:2000,effectText:'Add 1 card from your trash to your hand.'}],
 ['OP01-001',{cardId:'OP01-001',name:'Example',category:'Character',colors:['Red'],cost:1,power:2000,counter:0,effectText:'Look at the top 5 cards of your deck.'}]
]);
test('normalizes deck-builder export with duplicated card IDs',()=>{
 const d=normalizeDeckExport({leaderId:'OP15-022',mainDeck:[{cardId:'OP17-081'},{cardId:'OP17-081'}]},cards);
 assert.equal(d.total,2); assert.equal(d.counts['OP17-081'],2); assert.equal(d.is50CardDeck,false);
});
test('rejects unknown leader and unknown card IDs',()=>{
 assert.throws(()=>normalizeDeckExport({leaderId:'NOPE',mainDeck:[]},cards),/Unknown Leader/);
 assert.throws(()=>normalizeDeckExport({leaderId:'OP15-022',mainDeck:['NOPE']},cards),/Unknown card IDs/);
});
test('infers role labels but explicitly marks them heuristic',()=>{
 assert.equal(inferSimulationCard(cards.get('OP17-081')).role,'recovery');
 assert.equal(inferSimulationCard(cards.get('OP17-081')).confidence,'heuristic-unverified');
 assert.equal(inferSimulationCard(cards.get('OP01-001')).role,'search');
});
test('creates simulation card mapping for imported list',()=>{
 const m=inferSimulationCardMap(['OP17-081'],cards);
 assert.equal(m['OP17-081'].name,'Gerd'); assert.equal(m['OP17-081'].counter,2000);
});
