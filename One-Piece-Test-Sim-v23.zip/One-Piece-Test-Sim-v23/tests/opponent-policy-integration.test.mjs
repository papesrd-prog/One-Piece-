import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createOpponentState,playOpponentTurn,resolveAttacksAgainstOpponent} from '../src/opponent-policy.mjs';
const records=JSON.parse(fs.readFileSync(new URL('../data/punk_records_import/cards.browser.json',import.meta.url),'utf8'));
const db=new Map(records.map(c=>[c.cardId,c]));
const pool=JSON.parse(fs.readFileSync(new URL('../data/opponent-decks.json',import.meta.url),'utf8'));
const rand=(()=>{let x=20261023;return()=>{x=(x*1664525+1013904223)>>>0;return x/4294967296;};})();
test('real published deck can run 8 persistent card-by-card turns without unknown IDs',()=>{
 const deck=pool.decks[0];const state=createOpponentState(deck,db,rand);const brookLife=['ST01-001','ST01-001','ST01-001','ST01-001','ST01-001'];const brookHand=[];const brookBoard=[];let plays=0,attacks=0;
 for(let turn=1;turn<=8;turn++){
  const result=playOpponentTurn(state,{turn,opponentStartsFirst:false,brookLife,brookHand,brookBoard,random:rand});
  plays+=result.plays;attacks+=result.attacks;
  resolveAttacksAgainstOpponent(state,[{name:'Brook',power:5000}],rand);
 }
 assert.ok(plays>0);assert.ok(attacks>0);assert.equal(state.deck.length+state.hand.length+state.life.length+state.trash.length+state.board.length,50);
});
