import test from 'node:test';
import assert from 'node:assert/strict';
import { createRuntimeState, beginTurn, advancePhase, endTurn, enqueueTriggeredEffect, resolveNextEffect, resolveLeaderDamage, validateDeckStrict, drawCards, RuntimeRuleError, attachDon, applyPowerModifier, currentEntityPower } from '../src/rules-runtime.mjs';

const make = () => createRuntimeState([
  { id:'A', leader:{id:'LA'}, deck:['a','b','c'], life:['l1','l2'], donDeck:10 },
  { id:'B', leader:{id:'LB'}, deck:['d','e','f'], life:[{id:'trig',trigger:true},'l4'], donDeck:10 }
], 0);

test('turn sequence is Refresh -> Draw -> DON!! -> Main -> End', () => {
  const s = make(); beginTurn(s, 0);
  assert.equal(s.phase, 'refresh');
  advancePhase(s); assert.equal(s.phase, 'draw'); assert.equal(s.players[0].hand.length, 0); // first player skips first draw
  advancePhase(s); assert.equal(s.phase, 'don'); assert.equal(s.players[0].donActive, 1);
  advancePhase(s); assert.equal(s.phase, 'main');
  advancePhase(s); assert.equal(s.phase, 'end');
  endTurn(s); assert.equal(s.turnPlayer, 1);
  beginTurn(s, 1); advancePhase(s); assert.equal(s.players[1].hand.length, 1);
  advancePhase(s); assert.equal(s.players[1].donActive, 2);
});

test('effect queue prioritizes turn player effects when timing is simultaneous', () => {
  const s = make(); beginTurn(s, 0);
  enqueueTriggeredEffect(s, {controller:1, timing:'same-window', effect:{handler:'mark'}, timestamp:1});
  enqueueTriggeredEffect(s, {controller:0, timing:'same-window', effect:{handler:'mark'}, timestamp:2});
  const seen=[]; const handlers={mark:(_s,_e,c)=>seen.push(c.controller)};
  resolveNextEffect(s, handlers); resolveNextEffect(s, handlers);
  assert.deepEqual(seen, [0,1]);
});

test('Double Attack processes Life cards one at a time and can resolve Trigger', () => {
  const s = make();
  const events=[];
  const r = resolveLeaderDamage(s, 1, {doubleAttack:true, triggerDecider:card=>card.trigger, resolveTrigger:card=>events.push(card.id)});
  assert.deepEqual(events, ['trig']);
  assert.equal(r.totalLifeCardsProcessed, 2);
  assert.equal(s.players[1].life.length, 0);
  assert.equal(s.players[1].hand.includes('l4'), true);
});

test('unknown effect handlers fail closed', () => {
  const s=make(); beginTurn(s,0);
  enqueueTriggeredEffect(s,{controller:0,timing:'test',effect:{handler:'not-built'}});
  assert.throws(()=>resolveNextEffect(s,{}), e=>e instanceof RuntimeRuleError && e.code==='UNSUPPORTED_EFFECT');
});

test('strict deck validator rejects unknown cards rather than silently accepting them', () => {
  const deck=Array(50).fill('X');
  assert.throws(()=>validateDeckStrict({deck,leader:{category:'Leader',colors:['red']},cardDatabase:{}}), e=>e.code==='UNKNOWN_CARD');
});


test('drawing the final card triggers immediate deck-out rule processing', () => {
  const s = createRuntimeState([
    { id:'A', leader:{id:'LA'}, deck:['last'], hand:[], life:[] },
    { id:'B', leader:{id:'LB'}, deck:['other'], hand:[], life:[] }
  ], 0);
  const r = drawCards(s, 0, 1);
  assert.equal(r.deckout, true); assert.equal(s.winner, 'B'); assert.equal(s.phase, 'ended');
  assert.deepEqual(s.players[0].hand, ['last']);
});

test('simultaneous empty decks resolve as a draw at one rule checkpoint', () => {
  const s = createRuntimeState([
    { id:'A', leader:{id:'LA'}, deck:[], hand:[], life:[] },
    { id:'B', leader:{id:'LB'}, deck:[], hand:[], life:[] }
  ], 0);
  const r = drawCards(s, 0, 1);
  assert.equal(r.result.status, 'draw'); assert.equal(s.winner, null); assert.equal(s.gameResult.status, 'draw');
});


test('attaching DON!! spends active DON and increases battle-engine entity power', () => {
  const s = createRuntimeState([
    { id:'A', leader:{id:'LA', power:5000}, deck:['a'], life:[], donDeck:10, donActive:3 },
    { id:'B', leader:{id:'LB', power:5000}, deck:['b'], life:[], donDeck:10 }
  ], 0);
  beginTurn(s, 0); s.phase = 'main';
  const r = attachDon(s, 0, {type:'leader', id:'LA'}, 2);
  assert.equal(r.donActive, 1);
  assert.equal(s.players[0].leader.attachedDon, 2);
  assert.equal(currentEntityPower(s.players[0].leader), 7000);
});

test('attaching DON!! rejects insufficient DON and opponent targets', () => {
  const s = make(); beginTurn(s,0); s.phase='main';
  assert.throws(() => attachDon(s,0,{type:'leader',id:'LA'}, 99), e => e.code === 'INSUFFICIENT_DON');
  s.players[0].donActive = 2;
  assert.throws(() => attachDon(s,0,{type:'leader',id:'LB'}, 1), e => e.code === 'TARGET_NOT_FOUND');
});

test('end turn returns attached DON rested and clears end-of-turn power modifiers', () => {
  const s = createRuntimeState([
    { id:'A', leader:{id:'LA', power:5000}, deck:['a'], life:[], donDeck:10, donActive:2 },
    { id:'B', leader:{id:'LB', power:5000}, deck:['b'], life:[] }
  ], 0);
  beginTurn(s,0); s.phase='main';
  attachDon(s,0,{type:'leader',id:'LA'},1);
  applyPowerModifier(s,0,{type:'leader',id:'LA'},2000,'until-end-of-turn');
  assert.equal(currentEntityPower(s.players[0].leader),8000);
  s.phase='end'; endTurn(s);
  assert.equal(s.players[0].leader.attachedDon,0);
  assert.equal(s.players[0].donRested,1);
  assert.equal(currentEntityPower(s.players[0].leader),5000);
});

test('paying DON!! moves only active DON!! to rested during the Main Phase', async () => {
  const { payDon } = await import('../src/rules-runtime.mjs');
  const s = createRuntimeState([
    { id:'A', leader:{id:'LA'}, deck:['a'], life:[], donDeck:10, donActive:3 },
    { id:'B', leader:{id:'LB'}, deck:['b'], life:[] }
  ], 0);
  beginTurn(s, 0); s.phase = 'main';
  const result = payDon(s, 0, 2);
  assert.deepEqual(result, { donActive: 1, donRested: 2 });
  assert.throws(() => payDon(s, 1, 1), e => e.code === 'NOT_TURN_PLAYER');
});
