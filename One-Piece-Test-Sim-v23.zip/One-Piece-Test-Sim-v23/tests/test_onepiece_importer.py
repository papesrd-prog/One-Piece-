import importlib.util
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('onepiece_importer',ROOT/'tools'/'import_onepiece_gg.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

def test_walk_finds_card_records():
    payload={'data':[{'id':'OP01-001','name':'Roronoa Zoro','effect':'Rush'}]}
    found=list(mod.walk(payload))
    assert len(found)==1 and found[0]['id']=='OP01-001'

def test_normalize_keeps_effect_and_image_url():
    card=mod.normalize({'id':'OP01-001','name':'Roronoa Zoro','effect':'Rush','imageUrl':'/assets/OP01-001.png'},'https://onepiece.gg/cards/OP01-001-zoro/','2026-10-23T00:00:00+00:00')
    assert card['cardId']=='OP01-001'
    assert card['effectText']=='Rush'
    assert card['imageUrls']==['https://onepiece.gg/assets/OP01-001.png']
    assert 'remote_reference_only' in card['imageUsage']

def test_dedupe_preserves_parallel_id_variant():
    a={'id':'OP01-001','name':'Zoro','effect':'Rush'}
    b={'id':'OP01-001_p1','name':'Zoro (Parallel)','effect':'Rush'}
    assert len(list(mod.walk([a,b])))==2
