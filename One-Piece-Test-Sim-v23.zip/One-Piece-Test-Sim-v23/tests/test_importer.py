import importlib.util, unittest
from pathlib import Path
P=Path(__file__).resolve().parents[1]/'tools'/'refresh_english_database.py'
spec=importlib.util.spec_from_file_location('refresh',P); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
class ImporterTests(unittest.TestCase):
 def test_walk_nested_api(self):
  payload={'sets':[{'cards':[{'card_id':'OP01-001','name':'Roronoa Zoro','effect':'Test'}]}]}
  self.assertEqual(len(list(m.walk_records(payload))),1)
 def test_normalize_fields(self):
  raw={'card_id':'OP01-001','name':'Roronoa Zoro','type':'Leader','color':'Red','cost':'5','power':'5000','counter':None,'attribute':'Slash','types':'Supernovas, Straw Hat Crew','effect':'[DON!! x1] All Characters gain +1000 power.','trigger':None}
  c=m.normalize(raw,'test','https://example.invalid','2026-10-23T00:00:00+00:00')
  self.assertEqual(c['cardId'],'OP01-001'); self.assertEqual(c['category'],'Leader'); self.assertEqual(c['colors'],['Red']); self.assertEqual(c['power'],5000); self.assertEqual(len(c['traits']),2); self.assertIn('+1000',c['effectText']); self.assertEqual(c['implementedEffectStatus'],'not_implemented')
 def test_don_normalize(self):
  c=m.normalize({'id':'DON-001','name':'DON!!','type':'Don'},'test','x','t')
  self.assertEqual(c['category'],'DON!!')
 def test_missing_effect_is_empty_not_fabricated(self):
  c=m.normalize({'card_id':'OP01-001','name':'Example'},'test','x','t')
  self.assertEqual(c['effectText'],''); self.assertEqual(c['verificationStatus'],'third_party_unverified')
 def test_card_shape_rejects_noncard(self):
  self.assertEqual(list(m.walk_records({'id':'EXAMPLE-001','name':'No Number Match'})),[])
if __name__=='__main__': unittest.main()
