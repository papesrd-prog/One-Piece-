import test from 'node:test';
import assert from 'node:assert/strict';
import { canonicalCardId, getCompiledEffect, effectSupportStatus, resolveCompiledCardEffect, listCompiledEffects } from '../src/card-effect-engine.mjs';
import { createOpponentState, playOpponentTurn } from '../src/opponent-policy.mjs';

test('parallel printings resolve through canonical card IDs', () => {
  assert.equal(canonicalCardId('EB01-023_p2'), 'EB01-023');
  assert.equal(getCompiledEffect('EB01-023_p2', 'on-play').count, 1);
});

test('explicit On Play draw effect moves cards from deck to hand', () => {
  const player = { deck: ['a','b'], hand: [] };
  const log = [];
  const result = resolveCompiledCardEffect({ cardId:'OP13-041', timing:'on-play', player, log });
  assert.equal(result.status, 'resolved');
  assert.equal(result.drawn, 2);
  assert.deepEqual(player.hand, ['a','b']);
  assert.deepEqual(player.deck, []);
});

test('unknown effects remain unsupported instead of guessed', () => {
  assert.equal(effectSupportStatus('OP99-999','on-play').status, 'unsupported');
  const result = resolveCompiledCardEffect({cardId:'ST01-001',timing:'on-play',player:{deck:[],hand:[]}});
  assert.equal(result.resolved, false);
});

test('deck-out is surfaced for caller rule checkpoint', () => {
  const player = { deck: ['only'], hand: [] };
  const result = resolveCompiledCardEffect({cardId:'OP13-041',timing:'on-play',player,log:[]});
  assert.equal(result.status, 'deck-out-pending');
  assert.equal(result.drawn, 1);
});

test('opponent policy invokes explicitly compiled On Play draw effects', () => {
  const deck = {id:'test',leaderId:'L',mainDeck:['OP04-045','x','y','z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x2','y2','z2','a2','b2','c2','d2','e2','f2','g2','h2','i2','j2','k2','l2','m2','n2','o2','p2','q2','r2','s2','t2']};
  const cards = new Map([
    ['L',{cardId:'L',name:'Leader',category:'Leader',power:5000}],
    ['OP04-045',{cardId:'OP04-045',name:'King',category:'Character',cost:1,power:1000,counter:0,effectText:'[On Play] Draw 1 card.'}],
    ...deck.mainDeck.filter(id=>id!=='OP04-045').map(id=>[id,{cardId:id,name:id,category:'Character',cost:99,power:0,counter:0,effectText:'-'}])
  ]);
  const state = createOpponentState(deck,cards,()=>0.5);
  state.hand = ['OP04-045'];
  state.deck = ['drawn-card'];
  const result = playOpponentTurn(state,{turn:1,opponentStartsFirst:true,brookLife:[],brookHand:[],brookTrash:[],brookBoard:[],random:()=>0.5});
  assert.ok(result.log.some(line=>line.includes('Effect OP04-045: draw 1 card')));
  assert.ok(state.hand.includes('drawn-card'));
});

test('compiled effect registry stays intentionally small and inspectable', () => {
  assert.deepEqual(listCompiledEffects().map(e=>e.cardId).sort(), ['EB01-023','OP04-045','OP13-041']);
});
