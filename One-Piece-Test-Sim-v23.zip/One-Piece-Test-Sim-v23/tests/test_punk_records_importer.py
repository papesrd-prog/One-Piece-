import json
from pathlib import Path
from tools.import_punk_records import import_dataset

def test_import_grouped_pack_json(tmp_path):
    source = tmp_path / 'repo'; data = source / 'english' / 'data'; data.mkdir(parents=True)
    (data / 'OP01.json').write_text(json.dumps([
        {'id':'OP01-001','name':'Leader A','category':'Leader','colors':['Red'],'cost':4,'power':5000,'counter':None,'attributes':['Slash'],'types':['Crew'],'effect':'[Your Turn] Example effect','trigger':None,'pack_id':'OP01'},
        {'id':'OP01-002','name':'Card B','category':'Character','colors':['Blue'],'cost':2,'power':3000,'counter':1000,'attributes':['Wisdom'],'types':['Crew'],'effect':'Draw 1','trigger':'Add to hand','pack_id':'OP01'}
    ]), encoding='utf-8')
    status = import_dataset(source, tmp_path / 'out')
    assert status['recordsImported'] == 2 and status['uniqueCardIds'] == 2
    rows = [json.loads(x) for x in (tmp_path/'out'/'punk_records_cards.normalized.jsonl').read_text().splitlines()]
    assert rows[0]['effectText'] == '[Your Turn] Example effect'
    assert rows[1]['triggerText'] == 'Add to hand'
    assert rows[0]['verificationStatus'] == 'unverified'
    unique = json.loads((tmp_path/'out'/'punk_records_cards.by_id.json').read_text())
    assert len(unique) == 2 and unique['OP01-001']['name'] == 'Leader A'

def test_import_split_per_card(tmp_path):
    source = tmp_path / 'repo' / 'english' / 'cards' / 'OP01'; source.mkdir(parents=True)
    (source/'OP01-001.json').write_text(json.dumps({'id':'OP01-001','name':'Card','effect':'Test'}), encoding='utf-8')
    status = import_dataset(tmp_path/'repo', tmp_path/'out')
    assert status['recordsImported'] == 1
    assert status['completeDatasetRead'] is True
