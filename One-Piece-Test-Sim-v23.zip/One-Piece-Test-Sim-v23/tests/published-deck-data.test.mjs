import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {validateOpponentDeck} from '../src/opponent-decks.mjs';
const records=JSON.parse(fs.readFileSync(new URL('../data/punk_records_import/cards.browser.json',import.meta.url)));
const legality=JSON.parse(fs.readFileSync(new URL('../data/format-legality-global-2026-10-12.json',import.meta.url)));
const library=JSON.parse(fs.readFileSync(new URL('../data/opponent-decks.json',import.meta.url)));
const byId=new Map(records.map(c=>[c.cardId,c]));
test('published opponent list library has at least three distinct sourced lists',()=>{
 assert.ok(library.decks.length>=3);
 assert.equal(new Set(library.decks.map(d=>d.id)).size,library.decks.length);
 for(const d of library.decks){assert.ok(d.source.startsWith('https://')); assert.ok(d.sourcePublisher); assert.ok(d.sourceNotes);assert.equal(d.mainDeck.length,50);assert.notEqual(d.leaderId,'OP14-020');assert.ok(!d.mainDeck.some(id=>id.replace(/_p\d+$/i,'')==='OP14-020'));}
});
test('all published lists validate against the loaded local card database and dated restrictions',()=>{
 for(const d of library.decks){const v=validateOpponentDeck(d,byId,legality);assert.equal(v.legal,true,`${d.name}: ${v.errors.map(e=>e.message).join('; ')}`);}
});
