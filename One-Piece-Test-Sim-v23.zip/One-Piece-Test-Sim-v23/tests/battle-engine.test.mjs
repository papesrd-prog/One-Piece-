import test from 'node:test';
import assert from 'node:assert/strict';
import { declareBattle, advanceBattleStep, activateBlocker, addBattleCounter, resolveBattleDamage, finishBattle, BattleRuleError } from '../src/battle-engine.mjs';
import { processRuleCheckpoint } from '../src/rule-processing.mjs';

function game({ deckA=['a','b'], deckB=['c','d'], lifeA=['la'], lifeB=['lb'], turnCountA=2, turnCountB=2 } = {}) {
  return { phase:'main', turnPlayer:0, firstPlayer:0, winner:null, gameResult:null, log:[], battle:null, players:[
    { id:'A', index:0, turnCount:turnCountA, leader:{id:'LA',power:5000,rested:false}, deck:[...deckA], hand:[], life:[...lifeA], trash:[], characters:[], donAttached:[] },
    { id:'B', index:1, turnCount:turnCountB, leader:{id:'LB',power:5000,rested:false}, deck:[...deckB], hand:[], life:[...lifeB], trash:[], characters:[], donAttached:[] }
  ]};
}
const toCounter = s => { advanceBattleStep(s); advanceBattleStep(s); };
const toDamage = s => { toCounter(s); advanceBattleStep(s); };
const throws = (fn, code) => assert.throws(fn, e => e instanceof BattleRuleError && e.code === code);

test('battle requires legal attacker/target and first-turn restriction is per player', () => {
  const s=game({turnCountA:1});
  throws(()=>declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'leader',id:'LB'}}),'FIRST_TURN_ATTACK');
  s.players[0].turnCount=2;
  s.players[1].characters=[{instanceId:'ready',power:4000,rested:false}];
  throws(()=>declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'character',id:'ready'}}),'ILLEGAL_TARGET');
});

test('normal successful leader battle moves one Life card to hand', () => {
  const s=game();
  declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'leader',id:'LB'}});
  toDamage(s);
  const r=resolveBattleDamage(s);
  assert.equal(r.status,'attack-won'); assert.equal(r.lifeCardsProcessed,1);
  assert.equal(s.players[1].life.length,0); assert.deepEqual(s.players[1].hand,['lb']);
  advanceBattleStep(s); finishBattle(s); assert.equal(s.phase,'main');
});

test('equal power is a successful attack; stronger defender stops it', () => {
  const s=game(); s.players[0].leader.power=5000; s.players[1].leader.power=6000;
  declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'leader',id:'LB'}});
  toDamage(s); assert.equal(resolveBattleDamage(s).status,'attack-lost'); assert.equal(s.players[1].life.length,1);
});

test('Blocker redirects attack, rests blocker, and cannot be used twice', () => {
  const s=game(); s.players[1].characters=[{instanceId:'block',power:4000,rested:false,blocker:true}];
  declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'leader',id:'LB'}});
  advanceBattleStep(s);
  activateBlocker(s,'block');
  assert.deepEqual(s.battle.target,{type:'character',id:'block'}); assert.equal(s.players[1].characters[0].rested,true);
  throws(()=>activateBlocker(s,'block'),'BLOCKER_ALREADY_USED');
  advanceBattleStep(s); advanceBattleStep(s); assert.equal(resolveBattleDamage(s).ko,true); assert.equal(s.players[1].characters.length,0);
});

test('Unblockable prevents blocker activation', () => {
  const s=game(); s.players[0].leader.unblockable=true; s.players[1].characters=[{instanceId:'block',power:4000,rested:false,blocker:true}];
  declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'leader',id:'LB'}});
  advanceBattleStep(s);
  throws(()=>activateBlocker(s,'block'),'UNBLOCKABLE');
});

test('counter power is added before damage', () => {
  const s=game(); s.players[0].leader.power=5000; s.players[1].leader.power=4000;
  declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'leader',id:'LB'}});
  toCounter(s); addBattleCounter(s,{amount:2000,cardId:'counter-1'}); advanceBattleStep(s);
  const r=resolveBattleDamage(s); assert.equal(r.status,'attack-lost'); assert.equal(r.defensePower,6000);
});

test('Double Attack resolves life one at a time and processes Trigger between damage instances', () => {
  const s=game({lifeB:[{id:'trigger-card',trigger:true},'second']}); s.players[0].leader.doubleAttack=true;
  declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'leader',id:'LB'}}); toDamage(s);
  const r=resolveBattleDamage(s,{resolveLifeTrigger:({state,defender,card})=>{defender.trash.push(card);state.log.push({type:'test-trigger-effect'});return true;}});
  assert.equal(r.lifeCardsProcessed,2); assert.deepEqual(s.players[1].trash,[{id:'trigger-card',trigger:true}]); assert.deepEqual(s.players[1].hand,['second']);
});

test('leader damage at zero Life loses; a Double Attack with one Life remaining loses on second damage', () => {
  const s=game({lifeB:['last']}); s.players[0].leader.doubleAttack=true;
  declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'leader',id:'LB'}}); toDamage(s);
  const r=resolveBattleDamage(s); assert.equal(r.lifeCardsProcessed,1); assert.equal(s.winner,'A'); assert.equal(s.gameResult.reason,'leader-damaged-at-zero-life');
});

test('simultaneous deck-out defeat checkpoint is a draw', () => {
  const s=game({deckA:[],deckB:[]});
  const r=processRuleCheckpoint(s); assert.equal(r.status,'draw'); assert.deepEqual(r.losers,['A','B']); assert.equal(s.winner,null);
});


test('Banish sends Life to Trash without resolving Trigger', () => {
  const s=game({lifeB:[{id:'trigger-card',trigger:true}]}); s.players[0].leader.banish=true;
  declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'leader',id:'LB'}}); toDamage(s);
  let called=false; const r=resolveBattleDamage(s,{resolveLifeTrigger:()=>{called=true;return true;}});
  assert.equal(r.lifeCardsProcessed,1); assert.equal(called,false); assert.deepEqual(s.players[1].trash,[{id:'trigger-card',trigger:true}]); assert.equal(s.players[1].hand.length,0);
});

test('attack-step callback removing target skips the remaining battle steps', () => {
  const s=game();
  declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'leader',id:'LB'},onAttack:({state})=>{state.players[1].leader=null;}});
  assert.equal(s.battle.step,'end');
});


test('Rush: Character permits a same-turn attack on a rested Character but not a Leader', () => {
  const s=game({turnCountA:2});
  const rushChar={instanceId:'rush-char',power:4000,rested:false,playedTurn:2,keywords:['Rush: Character']};
  s.players[0].characters=[rushChar]; s.players[1].characters=[{instanceId:'rested-target',power:3000,rested:true}];
  assert.throws(()=>declareBattle(s,{attackerPlayerIndex:0,attacker:rushChar,target:{type:'leader',id:'LB'}}),e=>e.code==='SUMMONING_SICKNESS');
  const battle=declareBattle(s,{attackerPlayerIndex:0,attacker:rushChar,target:{type:'character',id:'rested-target'}});
  assert.equal(battle.step,'attack');
});


test('attached DON!! contributes exactly +1000 power per DON in battle resolution', () => {
  const s = game();
  s.players[0].leader.attachedDon = 1;
  s.players[1].leader.power = 5500;
  declareBattle(s, { attackerPlayerIndex: 0, attacker: { type: 'leader', id: 'LA' }, target: { type: 'leader', id: 'LB' } });
  toDamage(s);
  const r = resolveBattleDamage(s);
  assert.equal(r.attackPower, 6000);
  assert.equal(r.defensePower, 5500);
  assert.equal(r.status, 'attack-won');
});

test('battle uses power modifiers emitted by the effect DSL', async () => {
  const { resolveEffectDsl } = await import('../src/effect-dsl.mjs');
  const s = game();
  s.players[0].leader.power = 5000;
  s.players[1].leader.power = 5500;
  resolveEffectDsl(s, { actions: [{ op: 'power-modifier', target: 'leader', amount: 1000 }] }, { controller: 0, effectId: 'battle-integration-test' });
  declareBattle(s, { attackerPlayerIndex: 0, attacker: { type: 'leader', id: 'LA' }, target: { type: 'leader', id: 'LB' } });
  toDamage(s);
  const r = resolveBattleDamage(s);
  assert.equal(r.attackPower, 6000);
  assert.equal(r.status, 'attack-won');
});
