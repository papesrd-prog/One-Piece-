import test from 'node:test';
import assert from 'node:assert/strict';
import { declareBattle, legalBattleTargets, advanceBattleStep, resolveBattleDamage, activateBlocker, finishBattle, addBattleCounter } from '../src/battle-engine.mjs';
import { processRuleCheckpoint } from '../src/rule-processing.mjs';

// Case fixtures are tied to the official Comprehensive Rules section numbers.
// Source baseline: Bandai Comprehensive Rules PDF (official site), revision currently
// cross-checked against the 1.2.1 searchable text mirror. Mirror is a navigation aid,
// not a substitute for rechecking Bandai's latest published PDF before release.
function state({ turnA=2, turnB=2, lifeA=['a-life'], lifeB=['b-life'], deckA=['a','b'], deckB=['c','d'] }={}) {
  return { phase:'main', turn:3, turnPlayer:0, firstPlayer:0, winner:null, gameResult:null, log:[], battle:null, players:[
    {id:'A',index:0,turnCount:turnA,leader:{id:'LA',power:5000,rested:false},deck:[...deckA],hand:[],life:[...lifeA],trash:[],characters:[],donAttached:[]},
    {id:'B',index:1,turnCount:turnB,leader:{id:'LB',power:5000,rested:false},deck:[...deckB],hand:[],life:[...lifeB],trash:[],characters:[],donAttached:[]}
  ]};
}
const toBlock = s => advanceBattleStep(s);
const toCounter = s => { advanceBattleStep(s); advanceBattleStep(s); };
const toDamage = s => { toCounter(s); advanceBattleStep(s); };


test('CR 6-5: only the turn player may declare a battle', () => {
  const s=state();
  assert.throws(()=>declareBattle(s,{attackerPlayerIndex:1,attacker:{type:'leader',id:'LB'},target:{type:'leader',id:'LA'}}),e=>e.code==='NOT_TURN_PLAYER');
});

test('attack-prohibition effect prevents declaration without resting the card', () => {
  const s=state(); s.players[0].leader.cannotAttack=true;
  assert.throws(()=>declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'leader',id:'LB'}}),e=>e.code==='ATTACK_PROHIBITED');
  assert.equal(s.players[0].leader.rested,false); assert.equal(s.battle,null);
});

test('CR 6-5-6-1: no battle during a player’s first turn', () => {
  const s=state({turnA:1});
  assert.throws(()=>declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'leader',id:'LB'}}), e=>e.code==='FIRST_TURN_ATTACK');
});

test('CR 7: active Characters are not legal targets unless an effect grants permission', () => {
  const s=state(); const active={instanceId:'active',power:4000,rested:false}; s.players[1].characters=[active];
  assert.equal(legalBattleTargets(s,0).some(t=>t.id==='active'),false);
  assert.equal(legalBattleTargets(s,0,{canAttackActiveCharacters:true}).some(t=>t.id==='active'),true);
  assert.throws(()=>declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'character',id:'active'}}),e=>e.code==='ILLEGAL_TARGET');
  s.players[0].leader.canAttackActiveCharacters=true;
  assert.doesNotThrow(()=>declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'character',id:'active'}}));
});

test('CR 7-1: equal power succeeds, but a higher defending power prevents battle damage', () => {
  const s=state(); s.players[0].leader.power=5000; s.players[1].leader.power=5000;
  declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'leader',id:'LB'}}); toDamage(s);
  assert.equal(resolveBattleDamage(s).status,'attack-won');
  const t=state(); t.players[1].leader.power=6000;
  declareBattle(t,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'leader',id:'LB'}}); toDamage(t);
  assert.equal(resolveBattleDamage(t).status,'attack-lost'); assert.equal(t.players[1].life.length,1);
});

test('CR 7-1-2: Blocker redirects to itself and only one Blocker activation is allowed per battle', () => {
  const s=state(); s.players[1].characters=[{instanceId:'b1',power:4000,rested:false,blocker:true},{instanceId:'b2',power:4000,rested:false,blocker:true}];
  declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'leader',id:'LB'}}); toBlock(s);
  activateBlocker(s,'b1');
  assert.deepEqual(s.battle.target,{type:'character',id:'b1'});
  assert.throws(()=>activateBlocker(s,'b2'),e=>e.code==='BLOCKER_ALREADY_USED');
});

test('CR 7-1-3: counter power is applied before the battle power comparison', () => {
  const s=state(); s.players[0].leader.power=5000; s.players[1].leader.power=4000;
  declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'leader',id:'LB'}}); toCounter(s);
  addBattleCounter(s,{amount:2000,source:'test-counter'}); advanceBattleStep(s);
  const result=resolveBattleDamage(s); assert.equal(result.status,'attack-lost'); assert.equal(result.defensePower,6000);
});

test('CR 1-2 and 9: empty deck causes loss at rule processing; simultaneous losses draw', () => {
  const s=state({deckA:[]});
  assert.equal(processRuleCheckpoint(s).winner,'B');
  const t=state({deckA:[],deckB:[]});
  assert.equal(processRuleCheckpoint(t).status,'draw'); assert.equal(t.phase,'ended');
});

test('CR 4-6: Banish sends damaged Life to Trash and does not invoke Trigger resolution', () => {
  const s=state({lifeB:[{id:'trigger',trigger:true}]}); s.players[0].leader.banish=true;
  declareBattle(s,{attackerPlayerIndex:0,attacker:{type:'leader',id:'LA'},target:{type:'leader',id:'LB'}}); toDamage(s);
  let triggerCalled=false; resolveBattleDamage(s,{resolveLifeTrigger:()=>{triggerCalled=true;return true;}});
  assert.equal(triggerCalled,false); assert.equal(s.players[1].trash[0].id,'trigger'); assert.equal(s.players[1].hand.length,0);
  advanceBattleStep(s); finishBattle(s);
});
