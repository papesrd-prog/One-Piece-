import test from 'node:test';
import assert from 'node:assert/strict';
import { createMatchState, runMatch, runMatchSeries, seededRandom } from '../src/match-runner.mjs';

const leaderA = { id: 'LA', category: 'Leader', power: 5000, name: 'Leader A' };
const leaderB = { id: 'LB', category: 'Leader', power: 5000, name: 'Leader B' };
const chars = {
  C1: { id: 'C1', category: 'Character', cost: 1, power: 5000, name: 'Unit One' },
  C2: { id: 'C2', category: 'Character', cost: 2, power: 6000, name: 'Unit Two' },
  C3: { id: 'C3', category: 'Character', cost: 3, power: 7000, name: 'Unit Three' }
};
const cardsById = { ...chars };
const deck = () => Array.from({ length: 50 }, (_, i) => ['C1', 'C2', 'C3'][i % 3]);
const config = { players: [{ id: 'Brook', leader: leaderA, deck: deck() }, { id: 'Meta', leader: leaderB, deck: deck() }], cardsById };

test('seeded random produces repeatable values', () => {
  const a = seededRandom(42), b = seededRandom(42);
  assert.deepEqual(Array.from({ length: 8 }, a), Array.from({ length: 8 }, b));
});

test('match state deals five cards and five Life to each player', () => {
  const state = createMatchState({ ...config, seed: 5 });
  for (const player of state.players) {
    assert.equal(player.hand.length, 5);
    assert.equal(player.life.length, 5);
    assert.equal(player.deck.length, 40);
    assert.equal(player.donDeck, 10);
  }
});

test('same seed and configuration reproduce the same result and action trace', () => {
  const a = runMatch({ ...config, seed: 77, maxTurns: 6 });
  const b = runMatch({ ...config, seed: 77, maxTurns: 6 });
  assert.equal(a.status, b.status);
  assert.equal(a.winner, b.winner);
  assert.equal(a.actionCount, b.actionCount);
  assert.deepEqual(a.players, b.players);
  assert.deepEqual(a.log, b.log);
});

test('match runner uses the unified action interface and respects turn cap', () => {
  const result = runMatch({ ...config, seed: 10, maxTurns: 4 });
  assert.equal(result.turnsRun, 4);
  assert.ok(result.actionCount > 0);
  assert.equal(result.error, null);
  assert.ok(['turn-limit', 'win', 'draw'].includes(result.status));
});

test('series alternates first player and reports transparent sample counts', () => {
  const result = runMatchSeries({ ...config, games: 4, seed: 100, maxTurns: 3 });
  assert.equal(result.games, 4);
  assert.equal(result.results.length, 4);
  assert.equal(result.results[0].firstPlayer, 0);
  assert.equal(result.results[1].firstPlayer, 1);
  assert.equal(result.counts.winsP1 + result.counts.winsP2 + result.counts.draws + result.counts.turnLimits + result.counts.invalidMatches, 4);
});

test('missing card data fails clearly instead of silently substituting a card', () => {
  assert.throws(() => createMatchState({ players: [{ leader: leaderA, deck: ['UNKNOWN'] }, { leader: leaderB, deck: deck() }], cardsById }), /Missing card data for UNKNOWN/);
});
