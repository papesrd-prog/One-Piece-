import test from 'node:test';
import assert from 'node:assert/strict';
import {createOpponentState,playOpponentTurn,resolveAttacksAgainstOpponent,estimateDeckActions} from '../src/opponent-policy.mjs';
const db=new Map([
 ['LEAD',{cardId:'LEAD',name:'Leader',category:'Leader',power:5000,cost:5}],
 ['CHAR',{cardId:'CHAR',name:'Test Character',category:'Character',power:6000,cost:4,counter:0,effectText:''}],
 ['LOW',{cardId:'LOW',name:'Small Character',category:'Character',power:3000,cost:1,counter:0,effectText:''}],
 ['COUNTER',{cardId:'COUNTER',name:'Counter Card',category:'Character',power:2000,cost:2,counter:2000,effectText:''}],
 ['EVENT',{cardId:'EVENT',name:'KO Event',category:'Event',power:0,cost:2,counter:null,effectText:'KO up to 1 of your opponent characters with a cost of 3 or less.'}]
]);
const rand=()=>0.37;
test('creates persistent opponent state from exact 50-card composition',()=>{
 const deck={id:'test',leaderId:'LEAD',mainDeck:[...Array(10).fill('CHAR'),...Array(10).fill('LOW'),...Array(10).fill('COUNTER'),...Array(10).fill('EVENT'),...Array(10).fill('LOW')]};
 const s=createOpponentState(deck,db,rand);assert.equal(s.deck.length+s.hand.length+s.life.length,50);assert.equal(s.hand.length,5);assert.equal(s.life.length,5);assert.equal(s.deckId,'test');
});
test('opponent turn plays affordable cards and attacks from its board',()=>{
 const deck={id:'test',leaderId:'LEAD',mainDeck:[...Array(10).fill('CHAR'),...Array(10).fill('LOW'),...Array(10).fill('COUNTER'),...Array(10).fill('EVENT'),...Array(10).fill('LOW')]};
 const s=createOpponentState(deck,db,rand);s.hand=['CHAR','LOW','LOW','COUNTER','EVENT'];s.deck=[];s.don=4;
 const life=['COUNTER','COUNTER'];const hand=[];const board=[];
 const result=playOpponentTurn(s,{turn:2,opponentStartsFirst:false,brookLife:life,brookHand:hand,brookBoard:board,random:rand});
 assert.ok(result.plays>=1);assert.ok(result.attacks>=1);assert.ok(result.log.some(x=>x.startsWith('Play')));assert.ok(result.availableDON<=s.don);
});
test('deck action estimate reports actual card types and unknowns',()=>{
 const d={id:'t',mainDeck:['CHAR','EVENT','missing']};const e=estimateDeckActions(d,db);assert.equal(e.mainDeckCount,2);assert.equal(e.characterOrStageCount,1);assert.equal(e.eventCount,1);assert.equal(e.unknownCards,1);
});
test('Brook attacks resolve against opponent life and real counter values',()=>{
 const deck={id:'test',leaderId:'LEAD',mainDeck:[...Array(10).fill('CHAR'),...Array(10).fill('LOW'),...Array(10).fill('COUNTER'),...Array(10).fill('EVENT'),...Array(10).fill('LOW')]};
 const s=createOpponentState(deck,db,rand);s.hand=['COUNTER'];s.life=['LOW'];
 const result=resolveAttacksAgainstOpponent(s,[{name:'Brook',power:5000}],rand);
 assert.equal(result.hits,0);assert.equal(result.countersUsed,1);assert.equal(result.opponentLife,1);assert.equal(s.hand.length,0);
});
test('attack on empty opponent life is reported as a loss condition',()=>{
 const deck={id:'test',leaderId:'LEAD',mainDeck:[...Array(10).fill('CHAR'),...Array(10).fill('LOW'),...Array(10).fill('COUNTER'),...Array(10).fill('EVENT'),...Array(10).fill('LOW')]};
 const s=createOpponentState(deck,db,rand);s.hand=[];s.life=[];
 const result=resolveAttacksAgainstOpponent(s,[{name:'Brook',power:5000}],rand);
 assert.equal(result.loss,true);assert.equal(result.noLifeHits,1);
});
