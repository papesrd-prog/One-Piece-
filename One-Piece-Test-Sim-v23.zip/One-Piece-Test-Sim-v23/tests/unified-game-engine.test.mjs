import test from 'node:test';
import assert from 'node:assert/strict';
import { createRuntimeState, currentEntityPower } from '../src/rules-runtime.mjs';
import { executeUnifiedAction, UNIFIED_ACTION_TYPES, UnifiedActionError } from '../src/unified-game-engine.mjs';

const makeState = ({ deckA = ['a1', 'a2', 'a3'], deckB = ['b1', 'b2', 'b3'], lifeA = ['la'], lifeB = ['lb'] } = {}) => createRuntimeState([
  { id: 'A', leader: { id: 'LA', power: 5000 }, deck: [...deckA], hand: [], life: [...lifeA], donDeck: 10 },
  { id: 'B', leader: { id: 'LB', power: 5500 }, deck: [...deckB], hand: [], life: [...lifeB], donDeck: 10 }
], 0);

function runTurnToEnd(state) {
  executeUnifiedAction(state, { type: 'begin-turn' });
  for (let i = 0; i < 4; i++) executeUnifiedAction(state, { type: 'advance-phase' });
  assert.equal(state.phase, 'end');
  executeUnifiedAction(state, { type: 'end-turn' });
}

test('unified facade exposes one documented action vocabulary', () => {
  assert.ok(UNIFIED_ACTION_TYPES.includes('resolve-card-effect'));
  assert.ok(UNIFIED_ACTION_TYPES.includes('resolve-battle-damage'));
});

test('cannot begin a second turn while the current turn is still active', () => {
  const state = makeState();
  executeUnifiedAction(state, { type: 'begin-turn' });
  const before = structuredClone(state);
  assert.throws(() => executeUnifiedAction(state, { type: 'begin-turn' }), e => e.code === 'TURN_ALREADY_ACTIVE');
  assert.deepEqual(state, before);
});

test('invalid DON payment is atomic and leaves canonical state unchanged', () => {
  const state = makeState();
  executeUnifiedAction(state, { type: 'begin-turn' });
  executeUnifiedAction(state, { type: 'advance-phase' });
  executeUnifiedAction(state, { type: 'advance-phase' });
  executeUnifiedAction(state, { type: 'advance-phase' });
  const before = structuredClone(state);
  assert.throws(() => executeUnifiedAction(state, { type: 'pay-don', amount: 99 }), e => e.code === 'INSUFFICIENT_DON');
  assert.deepEqual(state, before);
});

test('unified action pipeline completes two turns then resolves DON-boosted battle', () => {
  const state = makeState();
  runTurnToEnd(state); // Player A turn 1.
  runTurnToEnd(state); // Player B turn 1.
  executeUnifiedAction(state, { type: 'begin-turn' }); // Player A turn 2.
  for (let i = 0; i < 3; i++) executeUnifiedAction(state, { type: 'advance-phase' });
  assert.equal(state.phase, 'main');
  assert.equal(state.turnPlayer, 0);

  executeUnifiedAction(state, { type: 'attach-don', target: { type: 'leader', id: 'LA' }, count: 1 });
  assert.equal(currentEntityPower(state.players[0].leader), 6000);
  executeUnifiedAction(state, { type: 'declare-attack', attacker: { type: 'leader', id: 'LA' }, target: { type: 'leader', id: 'LB' } });
  executeUnifiedAction(state, { type: 'battle-step' }); // block
  executeUnifiedAction(state, { type: 'battle-step' }); // counter
  executeUnifiedAction(state, { type: 'battle-step' }); // damage
  const result = executeUnifiedAction(state, { type: 'resolve-battle-damage' });
  assert.equal(result.status, 'attack-won');
  assert.equal(result.attackPower, 6000);
  assert.ok(state.players[1].hand.includes('lb'));
  assert.equal(state.players[1].life.length, 0);
  executeUnifiedAction(state, { type: 'battle-step' }); // end
  executeUnifiedAction(state, { type: 'finish-battle' });
  assert.equal(state.phase, 'main');
});

test('a multi-action DSL failure rolls back earlier mutations in the same action', () => {
  const state = makeState();
  const before = structuredClone(state);
  assert.throws(() => executeUnifiedAction(state, {
    type: 'resolve-dsl-effect',
    controller: 0,
    effectId: 'atomicity-test',
    program: { actions: [
      { op: 'power-modifier', target: 'leader', amount: 2000 },
      { op: 'ko', targetId: 'missing-character' }
    ] }
  }), e => e.code === 'TARGET_NOT_FOUND');
  assert.deepEqual(state, before);
});

test('compiled card draw effect uses shared deck-out checkpoint and winner state', () => {
  const state = makeState({ deckA: ['last'], deckB: ['b1'] });
  const result = executeUnifiedAction(state, { type: 'resolve-card-effect', playerIndex: 0, cardId: 'OP04-045', timing: 'on-play' });
  assert.equal(result.status, 'deck-out');
  assert.equal(result.drawn, 1);
  assert.equal(state.winner, 'B');
  assert.equal(state.phase, 'ended');
});

test('unknown unified actions fail closed without mutating state', () => {
  const state = makeState();
  const before = structuredClone(state);
  assert.throws(() => executeUnifiedAction(state, { type: 'invented-action' }), e => e instanceof UnifiedActionError && e.code === 'UNSUPPORTED_ACTION');
  assert.deepEqual(state, before);
});

test('unified play-character action pays DON!! once and moves a card into the Character area', () => {
  const state = makeState();
  state.phase = 'main';
  state.players[0].turnCount = 2;
  state.players[0].donActive = 3;
  state.players[0].hand = [{ id: 'C-TEST', cardId: 'C-TEST', category: 'Character', cost: 2, power: 5000, instanceId: 'C-TEST-1' }];
  const result = executeUnifiedAction(state, { type: 'play-character', playerIndex: 0, cardId: 'C-TEST' });
  assert.equal(result.played, true);
  assert.equal(state.players[0].hand.length, 0);
  assert.equal(state.players[0].characters.length, 1);
  assert.equal(state.players[0].donActive, 1);
  assert.equal(state.players[0].donRested, 2);
  assert.equal(state.players[0].characters[0].playedTurn, 2);
});

test('illegal Character play rolls back DON!! and card zones', () => {
  const state = makeState();
  state.phase = 'main';
  state.players[0].donActive = 0;
  state.players[0].hand = [{ id: 'C-TEST', cardId: 'C-TEST', category: 'Character', cost: 2, power: 5000, instanceId: 'C-TEST-1' }];
  const before = structuredClone(state);
  assert.throws(() => executeUnifiedAction(state, { type: 'play-character', playerIndex: 0, cardId: 'C-TEST' }), e => e.code === 'INSUFFICIENT_DON');
  assert.deepEqual(state, before);
});
