# v21 — shared battle power calculation

Battle resolution now delegates power calculation to `currentEntityPower` in `rules-runtime.mjs`. That helper applies base power, ordered set/add/multiply power modifiers, and +1000 per attached DON!!. The battle engine no longer adds attached DON!! separately, avoiding double counting.

The effect DSL's `power-modifier` action now writes to `powerModifiers`, which is read by battle resolution, and keeps a parallel descriptive `modifiers` ledger for debugging/UI compatibility. Its default duration is `until-end-of-turn`; explicit durations can be supplied by compiled effects. This does not automatically translate printed card text into DSL actions.
